import numpy as np

def selection(fitnesses):
    num_total_cases = len(fitnesses[0])
    pop_size = len(fitnesses)
    epsilon = 0.05  # small tolerance for near-best performance

    candidates = list(range(pop_size))
    cases = list(range(num_total_cases))
    np.random.shuffle(cases)

    for case in cases:
        case_errors = np.array([fitnesses[i][case] for i in candidates])
        best_error = np.min(case_errors)
        threshold = best_error + epsilon
        candidates = [candidates[i] for i, err in enumerate(case_errors) if err <= threshold]
        if len(candidates) == 1:
            return candidates[0]

    return np.random.choice(candidates)