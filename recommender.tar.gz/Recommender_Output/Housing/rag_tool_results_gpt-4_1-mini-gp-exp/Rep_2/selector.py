import numpy as np

def selection(fitnesses):
    num_total_cases = len(fitnesses[0])
    pop_size = len(fitnesses)
    candidates = list(range(pop_size))
    cases = list(range(num_total_cases))
    np.random.shuffle(cases)
    for case in cases:
        errors = [fitnesses[i][case] for i in candidates]
        min_error = min(errors)
        # Filter candidates within a threshold of the minimum error
        threshold = min_error + 1e-10
        candidates = [c for c in candidates if fitnesses[c][case] <= threshold]
        if len(candidates) == 1:
            return candidates[0]
    # If multiple candidates remain, select one randomly
    return np.random.choice(candidates)