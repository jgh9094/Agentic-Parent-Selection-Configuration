import numpy as np

def selection(fitnesses):
    num_total_cases = len(fitnesses[0])
    pop_size = len(fitnesses)
    errors = np.array(fitnesses)  # shape (pop_size, num_total_cases)
    # Calculate epsilon for each case as median absolute deviation
    medians = np.median(errors, axis=0)
    abs_devs = np.abs(errors - medians)
    epsilons = np.median(abs_devs, axis=0)
    # Start with all individuals
    candidates = np.arange(pop_size)
    # Random order of cases
    case_order = np.random.permutation(num_total_cases)
    for case in case_order:
        if len(candidates) == 1:
            break
        case_errors = errors[candidates, case]
        best_error = np.min(case_errors)
        threshold = best_error + epsilons[case]
        candidates = candidates[case_errors <= threshold]
    # If multiple candidates remain, pick one at random
    if len(candidates) > 1:
        return int(np.random.choice(candidates))
    else:
        return int(candidates[0])