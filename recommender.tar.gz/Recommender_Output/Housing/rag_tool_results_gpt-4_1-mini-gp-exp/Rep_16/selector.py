import numpy as np

def selection(fitnesses):
    num_total_cases = len(fitnesses[0])
    pop_size = len(fitnesses)
    candidates = list(range(pop_size))
    cases = list(range(num_total_cases))
    np.random.shuffle(cases)
    while len(candidates) > 1 and cases:
        case = cases.pop(0)
        case_errors = np.array([fitnesses[i][case] for i in candidates])
        best_error = np.min(case_errors)
        epsilon = np.std(case_errors) * 0.1  # epsilon threshold as 10% of std deviation
        candidates = [candidates[i] for i, err in enumerate(case_errors) if err <= best_error + epsilon]
    if not candidates:
        return np.random.randint(0, pop_size)
    return np.random.choice(candidates)