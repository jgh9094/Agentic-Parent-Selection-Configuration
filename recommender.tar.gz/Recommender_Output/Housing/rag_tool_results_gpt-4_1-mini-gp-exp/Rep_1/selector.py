import numpy as np

def selection(fitnesses):
    num_total_cases = len(fitnesses[0])
    pop_size = len(fitnesses)
    
    # Convert fitnesses to numpy array for easier manipulation
    errors = np.array(fitnesses)  # shape: (pop_size, num_total_cases)
    
    # Initialize candidate pool as all individuals
    candidates = np.arange(pop_size)
    
    # Randomize order of cases
    cases_order = np.random.permutation(num_total_cases)
    
    for case in cases_order:
        # Get errors of candidates on this case
        case_errors = errors[candidates, case]
        
        # Determine epsilon threshold as median absolute deviation
        best_error = np.min(case_errors)
        eps = np.median(np.abs(case_errors - best_error))
        
        # Select candidates within epsilon of best error
        pass_mask = case_errors <= best_error + eps
        candidates = candidates[pass_mask]
        
        # If only one candidate remains, select it
        if len(candidates) == 1:
            return candidates[0]
    
    # If multiple candidates remain after all cases, select one at random
    return np.random.choice(candidates)