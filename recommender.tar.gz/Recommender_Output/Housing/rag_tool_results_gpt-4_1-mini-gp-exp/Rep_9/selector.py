import numpy as np

def selection(fitnesses):
    num_total_cases = len(fitnesses[0])
    pop_size = len(fitnesses)
    epsilon = 1e-6  # small epsilon for relaxed comparison
    downsample_size = max(1, int(0.5 * num_total_cases))  # 50% down-sampling
    cases = np.random.choice(num_total_cases, downsample_size, replace=False)

    candidates = list(range(pop_size))
    for case in cases:
        case_errors = np.array([fitnesses[i][case] for i in candidates])
        min_error = np.min(case_errors)
        threshold = min_error + epsilon
        candidates = [candidates[i] for i, err in enumerate(case_errors) if err <= threshold]
        if len(candidates) == 1:
            break

    if len(candidates) > 1:
        return np.random.choice(candidates)
    else:
        return candidates[0]