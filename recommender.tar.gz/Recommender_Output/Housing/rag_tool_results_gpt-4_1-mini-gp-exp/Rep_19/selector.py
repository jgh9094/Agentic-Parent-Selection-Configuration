import numpy as np

def selection(fitnesses):
    num_total_cases = len(fitnesses[0])
    pop_size = len(fitnesses)
    epsilon = 1e-6  # small threshold for epsilon-lexicase
    cases = list(range(num_total_cases))
    candidates = list(range(pop_size))
    np.random.shuffle(cases)  # randomize order of cases
    # Down-sampling: sample a subset of cases (e.g., half)
    sample_size = max(1, num_total_cases // 2)
    sampled_cases = np.random.choice(cases, sample_size, replace=False)
    for case in sampled_cases:
        errors = np.array([fitnesses[i][case] for i in candidates])
        min_error = np.min(errors)
        threshold = min_error + epsilon
        candidates = [candidates[i] for i, e in enumerate(errors) if e <= threshold]
        if len(candidates) == 1:
            return candidates[0]
    if len(candidates) > 0:
        return np.random.choice(candidates)
    else:
        return np.random.randint(pop_size)