import numpy as np

def selection(fitnesses):
    num_total_cases = len(fitnesses[0])
    pop_size = len(fitnesses)
    candidates = list(range(pop_size))
    cases = list(range(num_total_cases))
    np.random.shuffle(cases)
    for case in cases:
        # Find the minimum error on this case among candidates
        errors = [fitnesses[i][case] for i in candidates]
        min_error = min(errors)
        # Filter candidates to those within a threshold of the minimum error
        threshold = min_error + 1e-8  # small epsilon to allow near-best
        candidates = [candidates[i] for i, e in enumerate(errors) if e <= threshold]
        if len(candidates) == 1:
            return candidates[0]
    # If multiple candidates remain, select one at random
    return np.random.choice(candidates)