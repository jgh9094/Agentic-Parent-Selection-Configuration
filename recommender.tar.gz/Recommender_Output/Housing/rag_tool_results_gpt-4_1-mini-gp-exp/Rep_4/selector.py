import numpy as np

def selection(fitnesses):
    num_total_cases = len(fitnesses[0])
    pop_size = len(fitnesses)
    errors = np.array(fitnesses)  # shape: (pop_size, num_total_cases)

    # Calculate epsilon for each test case as median absolute deviation
    median_errors = np.median(errors, axis=0)
    abs_deviation = np.abs(errors - median_errors)
    epsilon = np.median(abs_deviation, axis=0)

    # Initialize candidate indices
    candidates = list(range(pop_size))
    # Random order of test cases
    test_order = np.random.permutation(num_total_cases)

    for case in test_order:
        if len(candidates) == 1:
            break
        case_errors = errors[candidates, case]
        best_error = np.min(case_errors)
        threshold = best_error + epsilon[case]
        # Filter candidates within epsilon threshold
        candidates = [candidates[i] for i, err in enumerate(case_errors) if err <= threshold]

    # If multiple candidates remain, pick one at random
    if len(candidates) > 1:
        return np.random.choice(candidates)
    else:
        return candidates[0]