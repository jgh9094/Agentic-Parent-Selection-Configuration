import numpy as np

def selection(fitnesses):
    num_total_cases = len(fitnesses[0])
    pop_size = len(fitnesses)
    
    # Convert fitnesses to numpy array for efficient operations
    fitness_array = np.array(fitnesses)
    
    # Initialize candidates as all individuals
    candidates = np.arange(pop_size)
    
    # Randomly shuffle the order of test cases
    cases_order = np.random.permutation(num_total_cases)
    
    # Define epsilon thresholds per case as median absolute error among candidates
    for case in cases_order:
        case_errors = fitness_array[candidates, case]
        epsilon = np.median(case_errors)
        # Filter candidates that have error <= epsilon for this case
        candidates = candidates[case_errors <= epsilon]
        # If only one candidate remains, select it
        if len(candidates) == 1:
            return candidates[0]
    
    # If multiple candidates remain, select one at random
    return np.random.choice(candidates)