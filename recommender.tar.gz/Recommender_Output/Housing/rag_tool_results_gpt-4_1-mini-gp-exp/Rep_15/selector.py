import numpy as np

def selection(fitnesses):
    num_total_cases = len(fitnesses[0])
    pop_size = len(fitnesses)
    
    # Convert errors to numpy array for efficient processing
    errors = np.array(fitnesses)
    
    # Calculate epsilon thresholds for each test case as median absolute deviation
    medians = np.median(errors, axis=0)
    abs_devs = np.abs(errors - medians)
    epsilons = np.median(abs_devs, axis=0)
    
    # Initialize candidate indices
    candidates = np.arange(pop_size)
    # Randomly shuffle order of test cases
    case_order = np.random.permutation(num_total_cases)
    
    for case in case_order:
        if len(candidates) == 1:
            break
        # Find best error among candidates for this case
        best_error = np.min(errors[candidates, case])
        # Select candidates within epsilon of best error
        pass_mask = errors[candidates, case] <= best_error + epsilons[case]
        candidates = candidates[pass_mask]
        if len(candidates) == 0:
            # If no candidates pass, revert to previous candidates and break
            candidates = np.arange(pop_size)
            break
    
    # If multiple candidates remain, select one at random
    selected = np.random.choice(candidates)
    return int(selected)