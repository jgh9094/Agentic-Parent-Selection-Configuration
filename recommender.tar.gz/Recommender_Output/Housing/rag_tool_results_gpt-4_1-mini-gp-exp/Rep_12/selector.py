import numpy as np

def selection(fitnesses):
    num_total_cases = len(fitnesses[0])
    pop_size = len(fitnesses)
    
    # Convert fitnesses to numpy array for easier manipulation
    fitness_array = np.array(fitnesses)
    
    # Initialize candidate indices to all individuals
    candidates = np.arange(pop_size)
    
    # Randomly shuffle the order of cases
    cases_order = np.random.permutation(num_total_cases)
    
    for case in cases_order:
        # Extract errors for the current case for all candidates
        case_errors = fitness_array[candidates, case]
        
        # Determine epsilon threshold as median absolute deviation
        median_error = np.median(case_errors)
        abs_deviation = np.abs(case_errors - median_error)
        epsilon = np.median(abs_deviation)
        
        # Filter candidates that are within epsilon of best error
        best_error = np.min(case_errors)
        pass_threshold = best_error + epsilon
        candidates = candidates[case_errors <= pass_threshold]
        
        # If only one candidate remains, select it
        if len(candidates) == 1:
            return candidates[0]
    
    # If multiple candidates remain, select one at random
    return np.random.choice(candidates)