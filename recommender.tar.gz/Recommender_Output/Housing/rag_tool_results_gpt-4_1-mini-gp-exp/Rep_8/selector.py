import numpy as np

def selection(fitnesses):
    num_total_cases = len(fitnesses[0])
    pop_size = len(fitnesses)
    candidates = list(range(pop_size))
    cases = list(range(num_total_cases))
    np.random.shuffle(cases)
    for case in cases:
        errors = np.array([fitnesses[i][case] for i in candidates])
        min_error = np.min(errors)
        threshold = min_error + np.std(errors) * 0.5  # U parameter set to 0.5 as a hyperparameter
        candidates = [candidates[i] for i, e in enumerate(errors) if e <= threshold]
        if len(candidates) == 1:
            return candidates[0]
    return np.random.choice(candidates)