import numpy as np

def selection(fitnesses):
    num_total_cases = len(fitnesses[0])
    pop_size = len(fitnesses)
    errors = np.array(fitnesses)
    epsilon = np.median(np.abs(errors - np.median(errors, axis=0)), axis=0)  # Median absolute deviation per case
    candidates = np.arange(pop_size)
    cases = np.random.permutation(num_total_cases)
    for case in cases:
        case_errors = errors[candidates, case]
        min_error = np.min(case_errors)
        threshold = min_error + epsilon[case]
        candidates = candidates[case_errors <= threshold]
        if len(candidates) == 1:
            return candidates[0]
    return np.random.choice(candidates)