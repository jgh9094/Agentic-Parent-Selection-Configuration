import numpy as np

def selection(fitnesses):
    num_total_cases = len(fitnesses[0])
    pop_size = len(fitnesses)
    # Initialize candidate indices
    candidates = list(range(pop_size))
    # Random order of test cases
    cases_order = list(range(num_total_cases))
    np.random.shuffle(cases_order)
    for case in cases_order:
        # Find minimum error on this case among candidates
        errors = np.array([fitnesses[i][case] for i in candidates])
        min_error = np.min(errors)
        # Filter candidates probabilistically based on error difference
        filtered = []
        for i, idx in enumerate(candidates):
            error_diff = errors[i] - min_error
            # Probability decreases with error difference
            prob = np.exp(-error_diff)
            if np.random.rand() < prob:
                filtered.append(idx)
        if filtered:
            candidates = filtered
        if len(candidates) == 1:
            break
    # If multiple candidates remain, select one at random
    if len(candidates) > 1:
        return np.random.choice(candidates)
    else:
        return candidates[0]