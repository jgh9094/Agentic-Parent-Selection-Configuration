import numpy as np

def selection(fitnesses):
    num_total_cases = len(fitnesses[0])
    pop_size = len(fitnesses)
    # Calculate the median absolute error per test case to define epsilon
    errors = np.array(fitnesses)
    medians = np.median(errors, axis=0)
    epsilons = 0.1 * medians  # epsilon threshold as 10% of median error per case
    # Initialize candidate pool with all individuals
    candidates = list(range(pop_size))
    # Randomly shuffle test cases order
    cases_order = np.random.permutation(num_total_cases)
    for case in cases_order:
        if len(candidates) == 1:
            break
        case_errors = errors[candidates, case]
        best_error = np.min(case_errors)
        threshold = best_error + epsilons[case]
        # Filter candidates passing epsilon threshold
        candidates = [c for c in candidates if errors[c, case] <= threshold]
    # If multiple candidates remain, select one randomly
    if len(candidates) > 1:
        return np.random.choice(candidates)
    else:
        return candidates[0]