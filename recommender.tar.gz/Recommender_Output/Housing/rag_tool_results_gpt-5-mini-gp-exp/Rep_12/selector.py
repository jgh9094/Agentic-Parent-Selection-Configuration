def selection(fitnesses):
    import numpy as np

    # Step (1) and (2) per specification
    num_total_cases = len(fitnesses[0])
    pop_size = len(fitnesses)

    # Convert to numpy array: shape (pop_size, num_total_cases)
    arr = np.array(fitnesses, dtype=float)

    # Compute per-case epsilons using median absolute deviation (MAD)
    # epsilon_j = max(MAD(errors_j), tiny) to avoid zero thresholds
    epsilons = np.zeros(num_total_cases, dtype=float)
    tiny = 1e-12
    for j in range(num_total_cases):
        col = arr[:, j]
        med = np.median(col)
        mad = np.median(np.abs(col - med))
        epsilons[j] = max(mad, tiny)

    # Randomize case order
    case_order = np.random.permutation(num_total_cases)

    # Initialize candidate set to all individuals
    candidates = np.arange(pop_size)

    # Sequentially filter candidates by cases
    for case_idx in case_order:
        if candidates.size <= 1:
            break
        errors = arr[candidates, case_idx]
        best = errors.min()
        eps = epsilons[case_idx]
        keep_mask = errors <= (best + eps)
        candidates = candidates[keep_mask]

    # If multiple remain, choose uniformly at random among them
    if candidates.size == 0:
        # Fallback: choose global best by total error
        totals = arr.sum(axis=1)
        return int(np.argmin(totals))
    if candidates.size == 1:
        return int(candidates[0])
    return int(np.random.choice(candidates))