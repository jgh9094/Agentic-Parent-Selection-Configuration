import numpy as np

def selection(fitnesses):
    # 1) Calculate num_total_cases
    num_total_cases = len(fitnesses[0])
    # 2) Calculate pop_size
    pop_size = len(fitnesses)

    arr = np.array(fitnesses, dtype=float)  # shape: (pop_size, num_total_cases)

    # Precompute per-case epsilon using median absolute deviation (MAD)
    # This is robust to outliers and commonly used in ϵ-lexicase implementations
    med = np.median(arr, axis=0)
    mad = np.median(np.abs(arr - med), axis=0)
    eps = mad.copy()
    # ensure strictly positive epsilons to allow tolerant passing
    eps[eps == 0] = 1e-12

    # Randomize case order for this selection event
    case_order = np.random.permutation(num_total_cases)

    # Candidate pool: indices of individuals still in contention
    candidates = np.arange(pop_size)

    for case in case_order:
        if candidates.size <= 1:
            break
        errors = arr[candidates, case]
        best = np.min(errors)
        threshold = best + eps[case]
        mask = errors <= threshold
        # Filter candidates to those who pass this case
        candidates = candidates[mask]
        # If no candidates remain (unlikely because best always passes), fallback
        if candidates.size == 0:
            candidates = np.arange(pop_size)
            break

    # If multiple remain, choose uniformly at random among them
    if candidates.size == 0:
        return int(np.random.randint(0, pop_size))
    if candidates.size == 1:
        return int(candidates[0])
    return int(np.random.choice(candidates))