import numpy as np

def selection(fitnesses):
    import numpy as np
    # (1) num_total_cases as len(fitnesses[0])
    num_total_cases = len(fitnesses[0])
    # (2) pop_size as len(fitnesses)
    pop_size = len(fitnesses)

    arr = np.asarray(fitnesses, dtype=float)
    if arr.ndim != 2 or arr.shape[0] != pop_size or arr.shape[1] != num_total_cases:
        # fall back to safe conversion
        arr = arr.reshape((pop_size, num_total_cases))

    # compute per-case epsilons: median distance from best, with tiny floor
    eps = np.empty(num_total_cases, dtype=float)
    for j in range(num_total_cases):
        col = arr[:, j]
        best = np.min(col)
        diffs = np.abs(col - best)
        eps_j = np.median(diffs)
        if not np.isfinite(eps_j) or eps_j <= 0.0:
            eps_j = 1e-8
        eps[j] = eps_j

    # start with all individuals as candidates
    candidates = np.arange(pop_size)
    # randomize case ordering
    case_order = np.random.permutation(num_total_cases)

    for j in case_order:
        col = arr[candidates, j]
        best_among = np.min(col)
        thresh = best_among + eps[j]
        keep_mask = col <= thresh
        new_candidates = candidates[keep_mask]
        if new_candidates.size == 0:
            # if filtering removes all, ignore this case
            continue
        candidates = new_candidates
        if candidates.size == 1:
            return int(candidates[0])

    # if multiple remain (or none singled out), pick one uniformly at random
    if candidates.size == 0:
        # fallback to uniform over population
        return int(np.random.randint(0, pop_size))
    return int(np.random.choice(candidates))