def selection(fitnesses):
    import numpy as np
    # Required quantities
    num_total_cases = len(fitnesses[0])
    pop_size = len(fitnesses)

    # Convert to numpy array for vectorized ops
    arr = np.array(fitnesses, dtype=float)

    # Down-sample fraction (empirically effective trade-off)
    sample_frac = 0.5
    sample_size = max(1, int(round(sample_frac * num_total_cases)))

    # Select a random subset of cases and randomize their order
    cases = np.random.choice(num_total_cases, size=sample_size, replace=False)
    np.random.shuffle(cases)

    # Start with all candidates
    candidates = np.arange(pop_size)

    # Epsilon-lexicase filtering over sampled cases
    for c in cases:
        errors = arr[candidates, c]
        best = np.min(errors)
        # epsilon: median absolute deviation from the best (robust measure)
        eps = np.median(np.abs(errors - best))
        if eps <= 0:
            eps = 1e-8
        # Keep candidates whose error is within best + eps
        mask = errors <= (best + eps)
        candidates = candidates[mask]
        if candidates.size == 1:
            return int(candidates[0])

    # If no candidates survive (edge case), fall back to aggregate-best
    if candidates.size == 0:
        agg = np.mean(arr, axis=1)
        return int(np.argmin(agg))

    # Otherwise select uniformly at random among remaining candidates
    return int(np.random.choice(candidates))