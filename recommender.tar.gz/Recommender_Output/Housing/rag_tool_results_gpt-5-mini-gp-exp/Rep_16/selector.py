def selection(fitnesses):
    import numpy as np

    # Required diagnostics
    num_total_cases = len(fitnesses[0])
    pop_size = len(fitnesses)

    # Convert to numpy array: shape (pop_size, num_total_cases)
    fitness_arr = np.asarray(fitnesses, dtype=float)

    # Compute per-case epsilon as the median absolute deviation (MAD)
    medians = np.median(fitness_arr, axis=0)
    mads = np.median(np.abs(fitness_arr - medians), axis=0)
    # Avoid zero epsilons which would be too strict
    eps = mads.copy()
    eps[eps == 0.0] = 1e-8

    # Start with all individuals as candidates
    candidates = np.arange(pop_size)

    # Randomize order of cases for lexicase
    case_order = np.random.permutation(num_total_cases)

    for c in case_order:
        if candidates.size <= 1:
            break
        prev_candidates = candidates.copy()
        # Errors for current candidates on case c
        errors_c = fitness_arr[candidates, c]
        best = np.min(errors_c)
        threshold = best + eps[c]
        # Keep candidates within epsilon of best
        candidates = candidates[errors_c <= threshold]
        # If filtering removed everyone, revert to previous set and stop
        if candidates.size == 0:
            candidates = prev_candidates
            break

    # If multiple remain, pick uniformly at random
    chosen = int(np.random.choice(candidates))
    return chosen