def selection(fitnesses):
    import numpy as np
    num_total_cases = len(fitnesses[0])
    pop_size = len(fitnesses)
    arr = np.asarray(fitnesses, dtype=float)
    cases = np.arange(num_total_cases)
    np.random.shuffle(cases)
    candidates = np.arange(pop_size)
    for case in cases:
        if candidates.size <= 1:
            break
        errors = arr[candidates, case]
        best = errors.min()
        med = np.median(errors)
        epsilon = np.median(np.abs(errors - med))
        if epsilon <= 0:
            survivors = candidates[errors <= best + 1e-12]
        else:
            survivors = candidates[errors <= best + epsilon + 1e-12]
        if survivors.size == 0:
            break
        candidates = survivors
    if candidates.size == 0:
        return int(np.random.randint(0, pop_size))
    return int(np.random.choice(candidates))