def selection(fitnesses):
    import numpy as np
    # (1) number of test cases
    num_total_cases = len(fitnesses[0])
    # (2) population size
    pop_size = len(fitnesses)

    arr = np.array(fitnesses, dtype=float)  # shape: (pop_size, num_total_cases)

    # Compute per-case epsilons using median absolute deviation (MAD)
    med = np.median(arr, axis=0)
    mad = np.median(np.abs(arr - med), axis=0)
    eps = np.maximum(mad, 1e-8)  # avoid zero epsilon

    cases = np.arange(num_total_cases)
    order = np.random.permutation(cases)

    candidates = list(range(pop_size))

    for c in order:
        prev_candidates = candidates.copy()
        # errors for current candidates on case c
        errors = arr[candidates, c] if len(candidates) > 0 else arr[:, c]
        best = np.min(errors)
        threshold = best + eps[c]
        # keep candidates within best + epsilon
        candidates = [i for i in candidates if arr[i, c] <= threshold]
        if len(candidates) == 1:
            return int(candidates[0])
        if len(candidates) == 0:
            # revert to previous set and stop filtering
            candidates = prev_candidates
            break

    if len(candidates) == 0:
        # fallback to random choice from full population
        return int(np.random.randint(0, pop_size))

    # if multiple candidates remain, choose uniformly at random
    return int(np.random.choice(candidates))