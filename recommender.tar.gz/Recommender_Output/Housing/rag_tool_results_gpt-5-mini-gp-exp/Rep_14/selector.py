import numpy as np

def selection(fitnesses):
    num_total_cases = len(fitnesses[0])
    pop_size = len(fitnesses)
    arr = np.array(fitnesses, dtype=float)

    # Down-sample a random subset of cases (50% of cases, at least 1)
    sample_size = max(1, int(np.ceil(0.5 * num_total_cases)))
    case_indices = np.random.choice(num_total_cases, size=sample_size, replace=False)
    np.random.shuffle(case_indices)

    candidates = np.arange(pop_size)

    for c in case_indices:
        vals = arr[candidates, c]
        # dynamic epsilon: median absolute deviation on current candidates
        med = np.median(vals)
        mad = np.median(np.abs(vals - med))
        eps = mad
        if not np.isfinite(eps) or eps == 0:
            # fallback small epsilon scaled to data magnitude
            eps = 1e-8 + 1e-6 * (np.abs(med) + 1.0)
        best = np.min(vals)
        threshold = best + eps
        keep_mask = vals <= threshold
        candidates = candidates[keep_mask]
        if candidates.size == 1:
            return int(candidates[0])
        if candidates.size == 0:
            break

    if candidates.size == 0:
        return int(np.random.randint(0, pop_size))
    return int(np.random.choice(candidates))