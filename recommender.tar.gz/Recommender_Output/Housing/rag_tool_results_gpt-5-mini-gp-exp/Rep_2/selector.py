def selection(fitnesses):
    import numpy as np

    # required summaries
    num_total_cases = len(fitnesses[0])
    pop_size = len(fitnesses)

    # convert to numpy array (pop_size x num_total_cases)
    arr = np.array(fitnesses, dtype=float)

    # Down-sample fraction: use 20% of cases (at least 1)
    sample_size = max(1, int(np.ceil(0.2 * num_total_cases)))
    if sample_size > num_total_cases:
        sample_size = num_total_cases

    # sample a subset of cases without replacement and randomize their order
    cases = np.random.choice(num_total_cases, size=sample_size, replace=False)
    ordering = np.random.permutation(cases)

    # initial candidate pool: all individuals
    pool = np.arange(pop_size)

    for case in ordering:
        if pool.size <= 1:
            break

        # compute ε for this case across the whole population (MAD around median)
        case_errors_all = arr[:, case]
        med = np.median(case_errors_all)
        eps = np.median(np.abs(case_errors_all - med))
        if eps <= 0.0:
            eps = 1e-12

        # errors for individuals currently in the pool on this case
        errors = arr[pool, case]
        best = errors.min()

        # keep individuals whose error is within best + eps
        pass_mask = errors <= (best + eps)
        pool = pool[pass_mask]

        # if only one remains, return it
        if pool.size == 1:
            return int(pool[0])

    # if multiple remain, pick one uniformly at random; if none, pick random individual
    if pool.size == 0:
        return int(np.random.randint(pop_size))
    return int(np.random.choice(pool))