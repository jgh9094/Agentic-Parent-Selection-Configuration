import numpy as np

def selection(fitnesses):
    import numpy as np
    arr = np.asarray(fitnesses, dtype=float)
    num_total_cases = len(fitnesses[0])
    pop_size = len(fitnesses)

    candidates = np.arange(pop_size)
    case_order = np.random.permutation(num_total_cases)

    for c in case_order:
        # column of errors for case c across entire population
        case_col = arr[:, c]
        # epsilon: median absolute deviation (robust scale)
        eps = np.median(np.abs(case_col - np.median(case_col)))
        # errors of current candidates on this case
        cand_errors = arr[candidates, c]
        best = np.min(cand_errors)
        threshold = best + eps
        # keep candidates with error <= best + eps
        keep_mask = cand_errors <= threshold + 1e-12
        candidates = candidates[keep_mask]
        if candidates.size == 1:
            return int(candidates[0])
        if candidates.size == 0:
            # safety fallback: reset to full population
            candidates = np.arange(pop_size)

    # if multiple remain, choose uniformly at random
    if candidates.size == 0:
        return int(np.random.randint(pop_size))
    return int(np.random.choice(candidates))