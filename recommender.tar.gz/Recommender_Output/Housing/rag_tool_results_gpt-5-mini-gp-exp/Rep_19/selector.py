def selection(fitnesses):
    import numpy as np
    # number of test cases and population size (as required)
    num_total_cases = len(fitnesses[0])
    pop_size = len(fitnesses)

    # convert to numpy array: shape (pop_size, num_total_cases)
    arr = np.array(fitnesses, dtype=float)

    # start with all individuals as candidates
    candidates = np.arange(pop_size)

    # randomize case order for lexicase filtering
    case_order = np.random.permutation(num_total_cases)

    for case in case_order:
        # errors for current candidates on this case
        errs = arr[candidates, case]
        # median and median absolute deviation (MAD)
        med = np.median(errs)
        mad = np.median(np.abs(errs - med))
        # dynamic epsilon: use MAD if positive, otherwise small tolerance
        eps = mad if mad > 0.0 else 1e-8
        # find best error among candidates
        best = np.min(errs)
        # keep candidates within best + eps
        keep_mask = errs <= (best + eps)
        candidates = candidates[keep_mask]
        # if a single candidate remains, select it
        if candidates.size == 1:
            return int(candidates[0])
    # if multiple remain after all cases, pick uniformly at random
    if candidates.size > 1:
        return int(np.random.choice(candidates))
    # fallback (should not occur): pick random individual
    return int(np.random.randint(0, pop_size))