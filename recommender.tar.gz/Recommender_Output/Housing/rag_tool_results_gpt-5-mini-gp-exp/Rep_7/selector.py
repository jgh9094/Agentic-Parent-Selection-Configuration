def selection(fitnesses):
    import numpy as np

    # Required diagnostics
    num_total_cases = len(fitnesses[0])
    pop_size = len(fitnesses)

    # Convert to numpy array: shape (pop_size, num_total_cases)
    arr = np.array(fitnesses, dtype=float)

    # Initialize candidate pool (indices into population)
    candidates = np.arange(pop_size)

    # Randomize case order for this selection event
    case_indices = np.arange(num_total_cases)
    np.random.shuffle(case_indices)

    # Epsilon-lexicase filtering loop (dynamic epsilon from current candidate pool)
    for t in case_indices:
        errs = arr[candidates, t]
        # median absolute deviation as dynamic epsilon (robust to outliers)
        med = np.median(errs)
        eps = np.median(np.abs(errs - med))
        best = np.min(errs)
        threshold = best + eps

        # Filter candidates whose error on case t is within best + eps
        survivors_mask = errs <= (threshold + 1e-12)
        new_candidates = candidates[survivors_mask]

        # If filtering would remove all, ignore this case (continue)
        if new_candidates.size == 0:
            continue

        candidates = new_candidates

        # If only one candidate remains, select it
        if candidates.size == 1:
            return int(candidates[0])

    # If multiple candidates remain, choose uniformly at random among them
    if candidates.size == 0:
        # Fallback: choose uniformly from entire population
        return int(np.random.randint(pop_size))
    return int(np.random.choice(candidates))