def selection(fitnesses):
    import numpy as np

    num_total_cases = len(fitnesses[0])
    pop_size = len(fitnesses)

    # Convert to numpy array for efficient indexing: shape (pop_size, num_total_cases)
    arr = np.asarray(fitnesses, dtype=float)

    # Initial candidate set: all individual indices
    candidates = np.arange(pop_size)

    # Randomize case order for lexicase behavior
    case_order = np.random.permutation(num_total_cases)

    for t in case_order:
        # Errors of current candidates on case t
        errors = arr[candidates, t]

        # Compute median absolute deviation (MAD) as dynamic epsilon
        med = np.median(errors)
        mad = np.median(np.abs(errors - med))
        eps = mad

        # Find minimum error among candidates on this case
        min_e = np.min(errors)

        # Keep candidates within min + eps (allowing near-optimal specialists)
        keep_mask = errors <= (min_e + eps)
        candidates = candidates[keep_mask]

        # If only one candidate remains, select it
        if candidates.size == 1:
            return int(candidates[0])

    # If multiple candidates remain after all cases, pick one uniformly at random
    if candidates.size > 0:
        return int(np.random.choice(candidates))

    # Fallback: random individual (should not normally occur)
    return int(np.random.randint(0, pop_size))