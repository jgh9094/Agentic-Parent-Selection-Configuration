def selection(fitnesses):
    import numpy as np

    # 1) Calculate required meta values exactly as specified
    num_total_cases = len(fitnesses[0])
    pop_size = len(fitnesses)

    # Convert to numpy array: shape (pop_size, num_total_cases)
    arr = np.asarray(fitnesses, dtype=float)

    # If degenerate cases, fallback to uniform random
    if pop_size == 0 or num_total_cases == 0:
        return 0

    # Down-sample a subset of cases to reduce evaluation cost (20% of cases, at least 1)
    sample_size = min(num_total_cases, max(1, int(round(0.2 * num_total_cases))))
    sample_idx = np.random.choice(num_total_cases, size=sample_size, replace=False)

    # Compute per-case epsilon using median absolute deviation across the whole population
    sampled_errors = arr[:, sample_idx]  # shape (pop_size, sample_size)
    medians = np.median(sampled_errors, axis=0)
    mad = np.median(np.abs(sampled_errors - medians), axis=0)
    eps = np.where(mad > 0, mad, 1e-8)

    # Lexicase selection over the sampled cases in random order
    candidates = np.arange(pop_size)
    order = np.random.permutation(sample_size)
    for k in order:
        case_pos = k  # index into sampled arrays
        case_idx = sample_idx[case_pos]
        case_errors = arr[candidates, case_idx]
        best = np.min(case_errors)
        threshold = best + eps[case_pos]
        keep_mask = case_errors <= threshold
        candidates = candidates[keep_mask]
        if candidates.size == 1:
            return int(candidates[0])
        if candidates.size == 0:
            # if no candidate survives, fallback to random choice from full population
            return int(np.random.randint(0, pop_size))

    # If multiple candidates remain after all cases, choose uniformly among them
    return int(np.random.choice(candidates))