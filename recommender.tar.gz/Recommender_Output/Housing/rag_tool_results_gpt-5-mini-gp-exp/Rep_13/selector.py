def selection(fitnesses):
    import numpy as np

    # Calculate required sizes
    num_total_cases = len(fitnesses[0])
    pop_size = len(fitnesses)

    # Quick sanity
    if pop_size == 1:
        return 0

    # Convert to numpy array of shape (pop_size, num_cases)
    mat = np.array(fitnesses, dtype=float)

    # Initialize candidate indices
    candidates = np.arange(pop_size)

    # Randomize order of cases for this selection event
    cases = np.arange(num_total_cases)
    np.random.shuffle(cases)

    for case in cases:
        # Errors for current candidates on this case
        errs = mat[candidates, case]

        # Compute epsilon as median absolute deviation (dynamic: based on current candidates)
        med = np.median(errs)
        eps = np.median(np.abs(errs - med))
        if eps == 0 or np.isnan(eps):
            eps = 1e-8

        # Determine threshold: allow those within (min_err + eps)
        min_err = errs.min()
        pass_mask = errs <= (min_err + eps)

        # Filter candidates
        candidates = candidates[pass_mask]

        # If only one candidate remains, return it
        if candidates.size == 1:
            return int(candidates[0])

        # If no candidates remain (should be rare), break to fallback
        if candidates.size == 0:
            break

    # Fallback: if multiple candidates remain, pick one uniformly at random
    if candidates.size > 0:
        return int(np.random.choice(candidates))

    # If filtering removed all candidates, choose uniformly from entire population
    return int(np.random.randint(0, pop_size))