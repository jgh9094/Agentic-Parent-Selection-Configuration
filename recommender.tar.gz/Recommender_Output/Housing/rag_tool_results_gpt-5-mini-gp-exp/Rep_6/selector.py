def selection(fitnesses):
    import numpy as np
    # (1) num_total_cases
    num_total_cases = len(fitnesses[0])
    # (2) pop_size
    pop_size = len(fitnesses)
    # Convert to numpy array: shape (pop_size, num_total_cases)
    arr = np.array(fitnesses, dtype=float)
    # Compute per-case epsilon using median absolute deviation (robust to outliers)
    med = np.median(arr, axis=0)
    mad = np.median(np.abs(arr - med), axis=0)
    eps = mad.copy()
    # Avoid zero epsilons
    eps[eps == 0] = 1e-8
    # Down-sample cases: choose sqrt(T) cases (at least 1), randomized order
    sample_size = min(num_total_cases, max(1, int(round(np.sqrt(float(num_total_cases))))))
    cases = np.random.permutation(num_total_cases)[:sample_size]
    # Start with all individuals as candidates
    candidates = np.arange(pop_size)
    # Epsilon-lexicase filtering over the sampled cases
    for t in cases:
        if candidates.size <= 1:
            break
        errors_t = arr[candidates, t]
        best = errors_t.min()
        thresh = best + eps[t]
        keep_mask = errors_t <= thresh
        candidates = candidates[keep_mask]
    # Fallbacks
    if candidates.size == 0:
        # If none survive (unlikely), pick global best by mean error (MSE proxy)
        mean_errors = arr.mean(axis=1)
        return int(np.argmin(mean_errors))
    if candidates.size == 1:
        return int(candidates[0])
    # If multiple remain, choose uniformly at random among them
    return int(np.random.choice(candidates))