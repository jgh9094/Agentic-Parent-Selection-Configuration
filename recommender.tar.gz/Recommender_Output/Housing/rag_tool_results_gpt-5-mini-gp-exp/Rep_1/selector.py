def selection(fitnesses):
    import numpy as np

    num_total_cases = len(fitnesses[0])
    pop_size = len(fitnesses)

    errs = np.asarray(fitnesses, dtype=float)
    # Compute per-case epsilon using median absolute deviation (MAD)
    med = np.median(errs, axis=0)
    mad = np.median(np.abs(errs - med), axis=0)
    eps = mad

    candidates = np.arange(pop_size)
    case_indices = np.random.permutation(num_total_cases)

    for case in case_indices:
        case_errors = errs[candidates, case]
        best = case_errors.min()
        threshold = best + eps[case]
        # Keep candidates that are within best + eps for this case
        mask = case_errors <= threshold + 1e-12
        candidates = candidates[mask]
        if candidates.size == 1:
            return int(candidates[0])

    if candidates.size == 0:
        # Fallback: choose individual with lowest total error
        totals = errs.sum(axis=1)
        return int(np.argmin(totals))

    return int(np.random.choice(candidates))