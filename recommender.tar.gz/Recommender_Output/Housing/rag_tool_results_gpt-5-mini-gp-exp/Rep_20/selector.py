def selection(fitnesses):
    import numpy as np
    # 1) Calculate num_total_cases
    num_total_cases = len(fitnesses[0])
    # 2) Calculate pop_size
    pop_size = len(fitnesses)
    # Convert to numpy array (shape: pop_size x num_total_cases)
    arr = np.array(fitnesses, dtype=float)
    # Compute per-case epsilon using median absolute deviation (MAD)
    med = np.median(arr, axis=0)
    mad = np.median(np.abs(arr - med), axis=0)
    eps = np.maximum(mad, 1e-8)
    # Down-sample cases (use 50% of cases, at least 1)
    sample_frac = 0.5
    sample_size = max(1, int(np.ceil(num_total_cases * sample_frac)))
    sampled = np.random.choice(num_total_cases, size=sample_size, replace=False)
    # Randomize order of sampled cases
    order = np.random.permutation(sampled)
    # Start with all individuals as candidates
    candidates = np.arange(pop_size)
    for case in order:
        # Get errors of current candidates on this case
        case_errors = arr[candidates, case]
        best = np.min(case_errors)
        threshold = best + eps[case]
        # Keep candidates that are within threshold
        mask = case_errors <= threshold
        candidates = candidates[mask]
        if candidates.size == 1:
            return int(candidates[0])
        if candidates.size == 0:
            break
    # Fallbacks: if no candidates remain, pick random individual
    if candidates.size == 0:
        return int(np.random.randint(pop_size))
    # If multiple candidates remain, choose one uniformly at random
    return int(np.random.choice(candidates))