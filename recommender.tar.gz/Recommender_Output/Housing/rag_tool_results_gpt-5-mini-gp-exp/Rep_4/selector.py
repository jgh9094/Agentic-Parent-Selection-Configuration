def selection(fitnesses):
    import numpy as np
    # Ensure input shape and compute required quantities per specification
    num_total_cases = len(fitnesses[0])
    pop_size = len(fitnesses)

    # Convert to numpy array for efficient operations
    arr = np.array(fitnesses, dtype=float)

    # Compute per-case epsilon using median absolute deviation (MAD)
    # epsilon_c = max(MAD_c, small_constant) to avoid zero thresholds
    medians = np.median(arr, axis=0)
    mad = np.median(np.abs(arr - medians), axis=0)
    eps = np.maximum(mad, 1e-12)

    # Epsilon-lexicase selection: shuffle cases, filter pool by threshold best+epsilon
    case_indices = np.arange(num_total_cases)
    np.random.shuffle(case_indices)

    pool = np.arange(pop_size)
    for c in case_indices:
        if pool.size <= 1:
            break
        errors_c = arr[pool, c]
        best = np.min(errors_c)
        threshold = best + eps[c]
        mask = errors_c <= threshold
        pool = pool[mask]

    # If filtering leaves no one (unlikely), fallback to uniform random; otherwise pick randomly from remaining pool
    if pool.size == 0:
        return int(np.random.randint(pop_size))
    return int(np.random.choice(pool))