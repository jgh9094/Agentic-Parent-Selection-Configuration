import numpy as np

def selection(fitnesses):
    num_total_cases = len(fitnesses[0])
    pop_size = len(fitnesses)

    # Tournament size (adjustable, typically 2-7 for GP)
    tournament_size = 3

    # Randomly select individuals for the tournament
    tournament_indices = np.random.choice(pop_size, tournament_size, replace=False)

    # Calculate fitness as the mean squared error for each individual in the tournament
    tournament_fitness = [np.mean(fitnesses[i]) for i in tournament_indices]

    # Select the index of the individual with the lowest fitness (minimizing error)
    winner_index = tournament_indices[np.argmin(tournament_fitness)]

    return winner_index