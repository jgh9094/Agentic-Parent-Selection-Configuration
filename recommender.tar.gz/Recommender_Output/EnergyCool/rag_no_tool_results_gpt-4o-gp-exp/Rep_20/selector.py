import numpy as np

def selection(fitnesses):
    num_total_cases = len(fitnesses[0])
    pop_size = len(fitnesses)

    # Tournament size (can be adjusted as needed)
    tournament_size = 3

    # Randomly select individuals for the tournament
    tournament_indices = np.random.choice(pop_size, tournament_size, replace=False)

    # Calculate mean error for each individual in the tournament
    mean_errors = [np.mean(fitnesses[i]) for i in tournament_indices]

    # Select the individual with the lowest mean error
    winner_index = tournament_indices[np.argmin(mean_errors)]

    return winner_index