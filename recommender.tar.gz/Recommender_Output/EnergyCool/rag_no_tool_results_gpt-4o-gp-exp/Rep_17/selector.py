import numpy as np

def selection(fitnesses):
    num_total_cases = len(fitnesses[0])
    pop_size = len(fitnesses)

    # Tournament size (can be adjusted as needed, here set to 3)
    tournament_size = 3

    # Randomly select tournament_size individuals
    selected_indices = np.random.choice(pop_size, tournament_size, replace=False)

    # Calculate total error for each selected individual
    total_errors = [sum(fitnesses[i]) for i in selected_indices]

    # Find the index of the individual with the minimum total error
    best_index = selected_indices[np.argmin(total_errors)]

    return best_index