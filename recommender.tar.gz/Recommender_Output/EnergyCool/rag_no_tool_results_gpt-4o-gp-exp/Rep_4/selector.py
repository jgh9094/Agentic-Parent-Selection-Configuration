import numpy as np

def selection(fitnesses):
    num_total_cases = len(fitnesses[0])
    pop_size = len(fitnesses)
    tournament_size = 3  # Size of the tournament

    # Randomly select tournament_size individuals
    tournament_indices = np.random.choice(pop_size, tournament_size, replace=False)

    # Calculate the mean error for each selected individual
    tournament_errors = [np.mean(fitnesses[i]) for i in tournament_indices]

    # Find the index of the individual with the lowest mean error
    winner_index = tournament_indices[np.argmin(tournament_errors)]

    return winner_index