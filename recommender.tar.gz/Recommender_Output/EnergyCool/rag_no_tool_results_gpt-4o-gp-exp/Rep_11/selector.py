import numpy as np

def selection(fitnesses):
    num_total_cases = len(fitnesses[0])
    pop_size = len(fitnesses)
    tournament_size = 3

    # Randomly select 'tournament_size' individuals from the population
    tournament_indices = np.random.choice(pop_size, tournament_size, replace=False)

    # Calculate the mean error for each selected individual
    mean_errors = [np.mean(fitnesses[i]) for i in tournament_indices]

    # Select the individual with the lowest mean error
    best_index = tournament_indices[np.argmin(mean_errors)]

    return best_index