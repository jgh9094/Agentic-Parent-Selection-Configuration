import numpy as np

def selection(fitnesses):
    num_total_cases = len(fitnesses[0])
    pop_size = len(fitnesses)
    tournament_size = 3

    # Randomly select tournament_size individuals
    tournament_indices = np.random.choice(pop_size, tournament_size, replace=False)
    
    # Calculate fitness (mean error) for each selected individual
    tournament_fitness = [np.mean(fitnesses[i]) for i in tournament_indices]

    # Find the index of the individual with the lowest fitness (best individual)
    best_index = tournament_indices[np.argmin(tournament_fitness)]

    return best_index