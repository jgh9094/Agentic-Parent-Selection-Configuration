import numpy as np

def selection(fitnesses):
    num_total_cases = len(fitnesses[0])
    pop_size = len(fitnesses)
    tournament_size = 3

    # Randomly select tournament_size individuals
    tournament_indices = np.random.choice(pop_size, tournament_size, replace=False)
    
    # Calculate fitness for each individual in the tournament (sum of errors)
    tournament_fitnesses = [sum(fitnesses[i]) for i in tournament_indices]

    # Find the index of the individual with the lowest fitness (minimum error)
    best_index_in_tournament = np.argmin(tournament_fitnesses)

    # Return the index of the selected individual in the original population
    return tournament_indices[best_index_in_tournament]