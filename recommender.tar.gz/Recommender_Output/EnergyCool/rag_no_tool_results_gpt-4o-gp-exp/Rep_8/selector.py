import numpy as np

def selection(fitnesses):
    num_total_cases = len(fitnesses[0])
    pop_size = len(fitnesses)

    # Tournament size (can be adjusted as needed, here set to 3)
    tournament_size = 3

    # Randomly select 'tournament_size' individuals
    tournament_indices = np.random.choice(pop_size, tournament_size, replace=False)

    # Calculate fitness (mean error) for each individual in the tournament
    tournament_fitnesses = [np.mean(fitnesses[i]) for i in tournament_indices]

    # Select the individual with the lowest mean error
    winner_index = tournament_indices[np.argmin(tournament_fitnesses)]

    return winner_index