import numpy as np

def selection(fitnesses):
    num_total_cases = len(fitnesses[0])
    pop_size = len(fitnesses)
    tournament_size = 3

    # Randomly select 'tournament_size' individuals from the population
    tournament_indices = np.random.choice(pop_size, tournament_size, replace=False)

    # Calculate fitness as the mean squared error for each selected individual
    tournament_fitness = [np.mean(fitnesses[i]) for i in tournament_indices]

    # Find the index of the individual with the lowest fitness (best individual)
    best_index_in_tournament = np.argmin(tournament_fitness)

    # Return the index of the selected parent in the original population
    return tournament_indices[best_index_in_tournament]