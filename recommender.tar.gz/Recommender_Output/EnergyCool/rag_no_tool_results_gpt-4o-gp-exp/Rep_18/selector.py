import numpy as np

def selection(fitnesses):
    num_total_cases = len(fitnesses[0])
    pop_size = len(fitnesses)
    tournament_size = 3  # Typical value for tournament size

    # Randomly select 'tournament_size' individuals
    tournament_indices = np.random.choice(pop_size, tournament_size, replace=False)

    # Calculate the average error for each individual in the tournament
    tournament_errors = [np.mean(fitnesses[i]) for i in tournament_indices]

    # Find the index of the individual with the lowest average error
    winner_index = tournament_indices[np.argmin(tournament_errors)]

    return winner_index