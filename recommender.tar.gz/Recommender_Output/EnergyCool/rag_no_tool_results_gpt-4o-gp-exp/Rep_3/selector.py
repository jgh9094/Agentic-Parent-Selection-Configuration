import numpy as np

def selection(fitnesses):
    num_total_cases = len(fitnesses[0])
    pop_size = len(fitnesses)

    # Calculate fitness as the mean of squared errors (lower is better)
    fitness_values = [np.mean(individual) for individual in fitnesses]

    # Tournament size (commonly 2 or 3)
    tournament_size = 3

    # Randomly select individuals for the tournament
    tournament_indices = np.random.choice(pop_size, tournament_size, replace=False)

    # Find the individual with the best (lowest) fitness in the tournament
    best_index = min(tournament_indices, key=lambda idx: fitness_values[idx])

    return best_index