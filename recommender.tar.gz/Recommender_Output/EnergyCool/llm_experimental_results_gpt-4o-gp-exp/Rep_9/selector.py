import numpy as np

def selection(fitnesses):
    num_total_cases = len(fitnesses[0])
    pop_size = len(fitnesses)
    tournament_size = 3

    # Randomly select tournament_size individuals
    tournament_indices = np.random.choice(pop_size, tournament_size, replace=False)
    
    # Calculate fitness for each individual in the tournament (sum of errors)
    tournament_fitness = [sum(fitnesses[i]) for i in tournament_indices]

    # Select the individual with the lowest fitness (minimizing error)
    winner_index = tournament_indices[np.argmin(tournament_fitness)]

    return winner_index