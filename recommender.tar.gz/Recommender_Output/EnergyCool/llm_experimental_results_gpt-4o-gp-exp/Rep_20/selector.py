import numpy as np

def selection(fitnesses):
    num_total_cases = len(fitnesses[0])
    pop_size = len(fitnesses)
    tournament_size = 3
    tournament_indices = np.random.choice(pop_size, tournament_size, replace=False)
    tournament_fitnesses = [np.mean(fitnesses[i]) for i in tournament_indices]
    best_index = tournament_indices[np.argmin(tournament_fitnesses)]
    return best_index