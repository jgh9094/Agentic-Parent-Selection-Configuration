import numpy as np

def selection(fitnesses):
    num_total_cases = len(fitnesses[0])
    pop_size = len(fitnesses)
    tournament_size = 3

    # Randomly select individuals for the tournament
    tournament_indices = np.random.choice(pop_size, tournament_size, replace=False)

    # Calculate fitness for each individual in the tournament (sum of errors)
    tournament_fitnesses = [sum(fitnesses[i]) for i in tournament_indices]

    # Select the individual with the lowest fitness (minimizing error)
    winner_index = tournament_indices[np.argmin(tournament_fitnesses)]

    return winner_index