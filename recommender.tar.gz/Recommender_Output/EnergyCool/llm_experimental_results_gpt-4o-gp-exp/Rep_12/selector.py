import numpy as np

def selection(fitnesses):
    num_total_cases = len(fitnesses[0])
    pop_size = len(fitnesses)

    # Calculate fitness as the mean squared error (lower is better)
    fitness_values = [np.mean(individual) for individual in fitnesses]

    # Tournament size
    tournament_size = 3

    # Randomly select tournament participants
    participants = np.random.choice(pop_size, tournament_size, replace=False)

    # Find the participant with the best (lowest) fitness
    best_index = participants[0]
    best_fitness = fitness_values[best_index]

    for participant in participants[1:]:
        if fitness_values[participant] < best_fitness:
            best_index = participant
            best_fitness = fitness_values[participant]

    return best_index