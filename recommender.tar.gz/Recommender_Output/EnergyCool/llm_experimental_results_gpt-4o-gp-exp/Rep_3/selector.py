import numpy as np

def selection(fitnesses):
    num_total_cases = len(fitnesses[0])
    pop_size = len(fitnesses)
    tournament_size = 3

    # Randomly select tournament_size individuals
    indices = np.random.choice(pop_size, tournament_size, replace=False)
    tournament_fitnesses = [np.mean(fitnesses[i]) for i in indices]

    # Select the individual with the lowest average error
    winner_index = indices[np.argmin(tournament_fitnesses)]

    return winner_index