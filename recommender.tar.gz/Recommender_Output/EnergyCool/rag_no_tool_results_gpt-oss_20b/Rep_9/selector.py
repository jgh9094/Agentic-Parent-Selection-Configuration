import numpy as np

def selection(fitnesses):
    pop_size = len(fitnesses)
    total_errors = np.array([sum(ind) for ind in fitnesses])
    tsize = 3
    if pop_size < tsize:
        tsize = pop_size
    indices = np.random.choice(pop_size, size=tsize, replace=False)
    best_idx = indices[np.argmin(total_errors[indices])]
    return int(best_idx)