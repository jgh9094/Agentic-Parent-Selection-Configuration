import numpy as np

def selection(fitnesses):
    pop_size = len(fitnesses)
    total_errors = np.sum(fitnesses, axis=1)
    k = min(3, pop_size)
    tournament = np.random.choice(pop_size, size=k, replace=False)
    best = tournament[0]
    best_error = total_errors[best]
    for idx in tournament[1:]:
        if total_errors[idx] < best_error:
            best = idx
            best_error = total_errors[idx]
    return int(best)