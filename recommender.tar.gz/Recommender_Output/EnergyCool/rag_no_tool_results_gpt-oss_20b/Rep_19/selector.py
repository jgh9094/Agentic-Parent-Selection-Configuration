import numpy as np

def selection(fitnesses):
    pop_size = len(fitnesses)
    agg = np.array([sum(f) for f in fitnesses])
    k = 3
    candidates = np.random.choice(pop_size, size=k, replace=False)
    best = candidates[np.argmin(agg[candidates])]
    return int(best)