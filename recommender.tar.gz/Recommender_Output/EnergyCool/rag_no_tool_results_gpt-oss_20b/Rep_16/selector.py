import numpy as np


def selection(fitnesses):
    num_total_cases = len(fitnesses[0])
    pop_size = len(fitnesses)
    errors = np.sum(fitnesses, axis=1)
    k = 3
    candidates = np.random.randint(0, pop_size, size=k)
    best = candidates[np.argmin(errors[candidates])]
    return int(best)