def selection(fitnesses):
    import numpy as np
    pop_size = len(fitnesses)
    num_total_cases = len(fitnesses[0]) if pop_size > 0 else 0
    errors = np.array([sum(f) for f in fitnesses])
    k = 3
    if pop_size < k:
        k = pop_size
    idxs = np.random.choice(pop_size, size=k, replace=False)
    best_idx = idxs[np.argmin(errors[idxs])]
    return int(best_idx)