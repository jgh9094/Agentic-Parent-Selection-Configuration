import numpy as np

def selection(fitnesses):
    num_total_cases = len(fitnesses[0])
    pop_size = len(fitnesses)
    errors = np.sum(fitnesses, axis=1)
    k = 3
    tournament_indices = np.random.choice(pop_size, k, replace=False)
    best_idx = tournament_indices[np.argmin(errors[tournament_indices])]
    return int(best_idx)