def selection(fitnesses):
    import numpy as np
    pop_size = len(fitnesses)
    errors = np.array([sum(f) for f in fitnesses])
    k = 3
    idxs = np.random.choice(pop_size, size=k, replace=False)
    best_idx = idxs[np.argmin(errors[idxs])]
    return int(best_idx)