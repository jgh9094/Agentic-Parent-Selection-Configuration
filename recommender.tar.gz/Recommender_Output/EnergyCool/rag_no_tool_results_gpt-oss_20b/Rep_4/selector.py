import numpy as np

def selection(fitnesses):
    num_total_cases = len(fitnesses[0])
    pop_size = len(fitnesses)
    errors = np.array(fitnesses)
    total_errors = errors.sum(axis=1)
    tsize = 3
    if pop_size < tsize:
        tsize = pop_size
    indices = np.random.choice(pop_size, size=tsize, replace=False)
    best_idx = indices[np.argmin(total_errors[indices])]
    return int(best_idx)