import numpy as np

def selection(fitnesses):
    num_total_cases = len(fitnesses[0])
    pop_size = len(fitnesses)
    totals = np.array([sum(f) for f in fitnesses])
    k = 3
    if pop_size < k:
        k = pop_size
    indices = np.random.choice(pop_size, k, replace=False)
    best_idx = indices[np.argmin(totals[indices])]
    return int(best_idx)