import numpy as np

def selection(fitnesses):
    num_total_cases = len(fitnesses[0])
    pop_size = len(fitnesses)
    errors = np.array([sum(f) for f in fitnesses])
    k = 3
    candidates = np.random.choice(pop_size, size=k, replace=False)
    best = candidates[np.argmin(errors[candidates])]
    return int(best)