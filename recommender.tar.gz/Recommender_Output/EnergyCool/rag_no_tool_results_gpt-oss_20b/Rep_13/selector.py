import numpy as np

def selection(fitnesses):
    num_total_cases = len(fitnesses[0])
    pop_size = len(fitnesses)
    if pop_size == 0:
        return None
    if pop_size == 1:
        return 0
    errors = np.sum(fitnesses, axis=1)
    tournament_size = 3
    best_idx = None
    best_error = np.inf
    for _ in range(tournament_size):
        idx = np.random.randint(0, pop_size)
        if errors[idx] < best_error:
            best_error = errors[idx]
            best_idx = idx
    return int(best_idx)