import numpy as np

def selection(fitnesses):
    num_total_cases = len(fitnesses[0])
    pop_size = len(fitnesses)
    total_errors = [sum(fitnesses[i]) for i in range(pop_size)]
    tournament_size = 3 if pop_size >= 3 else pop_size
    indices = np.random.choice(pop_size, size=tournament_size, replace=False)
    best_index = min(indices, key=lambda idx: total_errors[idx])
    return best_index