def selection(fitnesses):
    import numpy as np
    num_total_cases = len(fitnesses[0])
    pop_size = len(fitnesses)
    errors = np.sum(np.array(fitnesses), axis=1)
    tournament_size = 3 if pop_size >= 3 else pop_size
    participants = np.random.randint(0, pop_size, size=tournament_size)
    best = participants[0]
    best_error = errors[best]
    for idx in participants[1:]:
        if errors[idx] < best_error:
            best = idx
            best_error = errors[idx]
    return int(best)