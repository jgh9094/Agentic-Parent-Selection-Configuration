import numpy as np

def selection(fitnesses):
    num_total_cases = len(fitnesses[0])
    pop_size = len(fitnesses)
    k = 3
    if pop_size < k:
        k = pop_size
    indices = np.random.choice(pop_size, size=k, replace=False)
    errors = [sum(fitnesses[i]) for i in indices]
    best_idx = indices[np.argmin(errors)]
    return int(best_idx)