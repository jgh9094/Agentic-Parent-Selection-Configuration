import numpy as np

def selection(fitnesses):
    num_total_cases = len(fitnesses[0])
    pop_size = len(fitnesses)
    total_errors = np.array([sum(errors) for errors in fitnesses])
    k = 3
    indices = np.random.choice(pop_size, size=k, replace=False)
    best_idx = indices[np.argmin(total_errors[indices])]
    return int(best_idx)