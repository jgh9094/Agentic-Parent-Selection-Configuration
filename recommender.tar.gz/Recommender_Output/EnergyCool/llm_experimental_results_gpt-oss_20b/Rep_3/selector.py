def selection(fitnesses):
    import numpy as np
    num_total_cases = len(fitnesses[0])
    pop_size = len(fitnesses)
    tournament_size = 3
    indices = np.random.choice(pop_size, tournament_size, replace=False)
    best_idx = indices[0]
    best_error = sum(fitnesses[best_idx]) / num_total_cases
    for idx in indices[1:]:
        error = sum(fitnesses[idx]) / num_total_cases
        if error < best_error:
            best_error = error
            best_idx = idx
    return best_idx