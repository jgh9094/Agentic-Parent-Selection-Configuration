import numpy as np

def selection(fitnesses):
    num_total_cases = len(fitnesses[0])
    pop_size = len(fitnesses)
    # Compute total error per individual
    fitness = np.sum(fitnesses, axis=1)
    if pop_size <= 3:
        return int(np.argmin(fitness))
    # Tournament size of 3
    tournament_indices = np.random.choice(pop_size, size=3, replace=False)
    best_index = tournament_indices[np.argmin(fitness[tournament_indices])]
    return int(best_index)