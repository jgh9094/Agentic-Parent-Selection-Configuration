import numpy as np

def selection(fitnesses):
    num_total_cases = len(fitnesses[0])
    pop_size = len(fitnesses)
    total_errors = np.array([sum(f) for f in fitnesses])
    tsize = 3
    candidates = np.random.choice(pop_size, size=tsize, replace=False)
    best = candidates[0]
    best_error = total_errors[best]
    for idx in candidates[1:]:
        if total_errors[idx] < best_error:
            best = idx
            best_error = total_errors[idx]
    return best