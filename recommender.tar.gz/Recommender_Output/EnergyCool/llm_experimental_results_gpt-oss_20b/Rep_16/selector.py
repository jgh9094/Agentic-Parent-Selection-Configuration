import numpy as np

def selection(fitnesses):
    num_total_cases = len(fitnesses[0])
    pop_size = len(fitnesses)
    fitness = -np.sum(fitnesses, axis=1)
    tournament_size = 3
    if pop_size < tournament_size:
        tournament_size = pop_size
    indices = np.random.choice(pop_size, size=tournament_size, replace=False)
    best_idx = indices[np.argmax(fitness[indices])]
    return int(best_idx)