import numpy as np

def selection(fitnesses):
    num_total_cases = len(fitnesses[0])
    pop_size = len(fitnesses)
    errors = np.array([sum(f) for f in fitnesses])
    k = 3
    idxs = np.random.randint(0, pop_size, size=k)
    best_idx = idxs[np.argmin(errors[idxs])]
    return int(best_idx)