import numpy as np

def selection(fitnesses):
    num_total_cases = len(fitnesses[0])
    pop_size = len(fitnesses)
    fitness_array = np.sum(fitnesses, axis=1)
    k = 3
    indices = np.random.choice(pop_size, size=k, replace=False)
    best_idx = indices[np.argmin(fitness_array[indices])]
    return int(best_idx)