import numpy as np

def selection(fitnesses):
    num_total_cases = len(fitnesses[0])
    pop_size = len(fitnesses)
    fitness = np.array([sum(f) for f in fitnesses])
    tournament_size = 3
    if pop_size < tournament_size:
        tournament_size = pop_size
    participants = np.random.choice(pop_size, size=tournament_size, replace=False)
    best = participants[np.argmin(fitness[participants])]
    return int(best)