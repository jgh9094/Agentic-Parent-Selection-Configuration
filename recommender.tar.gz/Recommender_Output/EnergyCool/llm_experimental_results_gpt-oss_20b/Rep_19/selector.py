def selection(fitnesses):
    import numpy as np
    pop_size = len(fitnesses)
    fitness_array = np.sum(fitnesses, axis=1)
    idx1, idx2 = np.random.randint(0, pop_size, size=2)
    if fitness_array[idx1] < fitness_array[idx2]:
        return idx1
    else:
        return idx2