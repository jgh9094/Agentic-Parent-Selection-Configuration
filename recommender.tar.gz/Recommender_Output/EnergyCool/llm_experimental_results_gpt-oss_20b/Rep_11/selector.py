import numpy as np

def selection(fitnesses):
    # Compute total error for each individual
    errors = np.sum(fitnesses, axis=1)
    pop_size = len(fitnesses)
    # Tournament size (commonly 3)
    tournament_size = 3
    # Randomly sample indices without replacement
    indices = np.random.choice(pop_size, size=tournament_size, replace=False)
    # Find the index with the lowest error among the sampled
    best_local = np.argmin(errors[indices])
    return int(indices[best_local])