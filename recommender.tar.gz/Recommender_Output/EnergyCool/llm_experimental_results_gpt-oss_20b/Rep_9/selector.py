def selection(fitnesses):
    import numpy as np
    pop_size = len(fitnesses)
    fitness = np.array([ -sum(f) for f in fitnesses ])
    tsize = 3
    indices = np.random.choice(pop_size, tsize, replace=False)
    best_idx = indices[np.argmax(fitness[indices])]
    return int(best_idx)