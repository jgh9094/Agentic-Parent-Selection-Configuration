import numpy as np

def selection(fitnesses):
    # fitnesses: list of lists (pop_size x num_total_cases), lower is better (errors)
    num_total_cases = len(fitnesses[0])
    pop_size = len(fitnesses)
    arr = np.array(fitnesses, dtype=float)  # shape: (pop_size, num_total_cases)

    # Compute per-case epsilon using median absolute deviation (robust to outliers)
    medians = np.median(arr, axis=0)
    epsilons = np.median(np.abs(arr - medians), axis=0)
    # avoid zero epsilons
    epsilons[epsilons == 0] = 1e-12

    # Down-sample a random subset of cases for this selection event
    sample_size = max(1, int(0.5 * num_total_cases))
    rng = np.random.default_rng()
    if sample_size >= num_total_cases:
        cases = rng.permutation(num_total_cases)
    else:
        cases = rng.choice(num_total_cases, size=sample_size, replace=False)

    candidates = np.arange(pop_size)
    for t in cases:
        best = np.min(arr[:, t])
        threshold = best + epsilons[t]
        # Keep candidates whose error on case t is within best + epsilon
        mask = arr[candidates, t] <= threshold
        candidates = candidates[mask]
        if candidates.size == 1:
            return int(candidates[0])

    # If multiple remain, choose uniformly at random; if none remain, fallback to random
    if candidates.size == 0:
        return int(rng.integers(0, pop_size))
    return int(rng.choice(candidates))