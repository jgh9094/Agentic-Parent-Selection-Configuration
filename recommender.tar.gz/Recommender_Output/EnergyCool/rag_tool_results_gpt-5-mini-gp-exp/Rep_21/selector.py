def selection(fitnesses):
    import numpy as np
    # 1) Calculate num_total_cases
    num_total_cases = len(fitnesses[0])
    # 2) Calculate pop_size
    pop_size = len(fitnesses)
    # Start with all individuals as candidates
    candidates = list(range(pop_size))
    # Randomize order of cases
    case_order = np.random.permutation(num_total_cases)
    for t in case_order:
        # gather errors for current candidates on case t
        e_t = np.array([fitnesses[i][t] for i in candidates], dtype=float)
        # compute median and median absolute deviation (MAD) for dynamic epsilon
        med = np.median(e_t)
        eps = np.median(np.abs(e_t - med))
        # determine best error among candidates and threshold
        best = e_t.min()
        thresh = best + eps
        # filter candidates whose error on case t is within best + eps
        survivors = [c for c, err in zip(candidates, e_t) if err <= thresh]
        if len(survivors) > 0:
            candidates = survivors
        # if reduced to one candidate, return it
        if len(candidates) == 1:
            return candidates[0]
    # if multiple candidates remain, pick uniformly at random
    return int(np.random.choice(candidates))