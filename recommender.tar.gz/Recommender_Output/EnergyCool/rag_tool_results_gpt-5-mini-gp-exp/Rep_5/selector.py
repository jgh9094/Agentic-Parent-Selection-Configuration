def selection(fitnesses):
    import numpy as np

    arr = np.asarray(fitnesses, dtype=float)
    if arr.ndim != 2:
        raise ValueError('fitnesses must be a 2D list-like: [pop_size][num_cases]')

    pop_size, num_total_cases = arr.shape
    if pop_size <= 0 or num_total_cases <= 0:
        raise ValueError('population size and number of cases must be > 0')

    # Down-sample fraction (50% of cases by default, at least 1)
    sample_size = max(1, int(0.5 * num_total_cases))
    case_indices = np.random.choice(num_total_cases, size=sample_size, replace=False)

    # Compute per-case epsilon using median absolute deviation (MAD)
    med = np.median(arr, axis=0)
    mad = np.median(np.abs(arr - med), axis=0)
    eps = mad
    # Floor small epsilons to avoid overly strict comparisons
    eps = np.where(eps <= 0.0, 1e-8, eps)

    candidates = np.arange(pop_size)
    for c in case_indices:
        # best error among remaining candidates on case c
        best = np.min(arr[candidates, c])
        thresh = best + eps[c]
        # keep candidates within epsilon of best
        mask = arr[candidates, c] <= thresh
        candidates = candidates[mask]
        if candidates.size == 1:
            return int(candidates[0])
    # If multiple remain, choose uniformly at random among them
    if candidates.size == 0:
        return int(np.random.randint(pop_size))
    return int(np.random.choice(candidates))