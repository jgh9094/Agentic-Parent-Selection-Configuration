def selection(fitnesses):
    import numpy as np
    # (1) number of test cases
    num_total_cases = len(fitnesses[0])
    # (2) population size
    pop_size = len(fitnesses)

    # Convert to numpy array for vectorized operations
    arr = np.array(fitnesses, dtype=float)  # shape: (pop_size, num_total_cases)

    # Candidate indices start as the whole population
    candidates = np.arange(pop_size)

    # Randomize order of cases for lexicase filtering
    case_order = np.arange(num_total_cases)
    np.random.shuffle(case_order)

    for case in case_order:
        # Errors for current candidates on this case
        errs = arr[candidates, case]
        # Best error among candidates
        min_err = np.min(errs)

        # Compute epsilon for this case using median absolute deviation (MAD) over the whole population
        pop_errs = arr[:, case]
        med = np.median(pop_errs)
        mad = np.median(np.abs(pop_errs - med))
        eps = mad if mad > 0 else 1e-8

        # Keep candidates within min_err + eps
        mask = errs <= (min_err + eps)
        candidates = candidates[mask]

        # If one candidate remains, return it
        if candidates.size == 1:
            return int(candidates[0])

        # If no candidates remain (should be rare), fall back to random choice from full population
        if candidates.size == 0:
            return int(np.random.randint(pop_size))

    # If multiple candidates remain after all cases, choose uniformly at random among them
    if candidates.size > 0:
        return int(np.random.choice(candidates))
    # Defensive fallback
    return int(np.random.randint(pop_size))