def selection(fitnesses):
    import numpy as np
    # Required size calculations
    num_total_cases = len(fitnesses[0])
    pop_size = len(fitnesses)

    # Convert to numpy array (pop_size x num_total_cases)
    arr = np.asarray(fitnesses, dtype=float)

    # Compute per-case median and median absolute deviation (MAD)
    medians = np.median(arr, axis=0)
    mad = np.median(np.abs(arr - medians), axis=0)
    # Ensure non-zero epsilons
    eps = mad.copy()
    eps[eps == 0] = 1e-8

    # Randomize case order and initialize candidate pool
    cases = np.random.permutation(num_total_cases)
    candidates = np.arange(pop_size)

    # Filter candidates by cases sequentially
    for c in cases:
        # Errors for current candidates on case c
        errs = arr[candidates, c]
        best = np.min(errs)
        pass_mask = errs <= (best + eps[c])
        candidates = candidates[pass_mask]
        if candidates.size <= 1:
            break

    # Fallbacks: if none pass, pick a random individual; otherwise choose randomly among remaining
    if candidates.size == 0:
        return int(np.random.randint(pop_size))
    return int(np.random.choice(candidates))