def selection(fitnesses):
    import numpy as np
    # 1) Calculate num_total_cases as len(fitnesses[0]).
    num_total_cases = len(fitnesses[0])
    # 2) Calculate pop_size as len(fitnesses).
    pop_size = len(fitnesses)

    arr = np.array(fitnesses, dtype=float)  # shape (pop_size, num_total_cases)
    # start with all individuals as candidates
    candidates = np.arange(pop_size)
    prev_candidates = candidates.copy()

    # random ordering of cases for lexicase-style selection
    case_order = np.random.permutation(num_total_cases)

    for c in case_order:
        prev_candidates = candidates.copy()
        case_errors = arr[candidates, c]

        # dynamic epsilon: median absolute deviation (MAD) among current candidates
        med = np.median(case_errors)
        mad = np.median(np.abs(case_errors - med))
        epsilon = mad
        # fallbacks if MAD is zero: use std or tiny constant
        if epsilon == 0.0:
            epsilon = np.std(case_errors)
        if epsilon == 0.0:
            epsilon = 1e-8

        best = np.min(case_errors)
        threshold = best + epsilon

        # keep candidates within best + epsilon
        mask = case_errors <= threshold
        candidates = candidates[mask]

        if candidates.size == 1:
            return int(candidates[0])
        if candidates.size == 0:
            # if filtering removed all, pick randomly from previous candidates
            return int(np.random.choice(prev_candidates))

    # if multiple remain after all cases, pick one at random
    return int(np.random.choice(candidates))