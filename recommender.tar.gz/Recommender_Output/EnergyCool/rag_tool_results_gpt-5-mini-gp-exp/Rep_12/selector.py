def selection(fitnesses):
    import numpy as np
    num_total_cases = len(fitnesses[0])
    pop_size = len(fitnesses)
    errors = np.asarray(fitnesses, dtype=float)
    if pop_size == 1:
        return 0
    if num_total_cases == 0:
        return int(np.random.randint(pop_size))
    # Down-sample a subset of cases (half of cases, at least one)
    sample_size = max(1, int(round(0.5 * num_total_cases)))
    cases = np.random.choice(num_total_cases, size=sample_size, replace=False)
    order = np.random.permutation(cases)
    survivors = np.arange(pop_size)
    # Compute per-case epsilon using median absolute deviation (MAD)
    med = np.median(errors, axis=0)
    mad = np.median(np.abs(errors - med), axis=0)
    eps = np.where(mad == 0, 1e-8, mad)
    for c in order:
        vals = errors[survivors, c]
        best = np.min(vals)
        threshold = best + eps[c]
        survivors = survivors[vals <= threshold]
        if len(survivors) == 1:
            return int(survivors[0])
    if len(survivors) > 0:
        return int(np.random.choice(survivors))
    return int(np.random.randint(pop_size))