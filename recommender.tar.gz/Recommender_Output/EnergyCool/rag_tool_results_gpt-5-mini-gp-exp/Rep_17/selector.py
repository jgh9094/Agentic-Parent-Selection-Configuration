def selection(fitnesses):
    import numpy as np

    # (1) number of test cases
    num_total_cases = len(fitnesses[0])
    # (2) population size
    pop_size = len(fitnesses)

    # Convert to numpy array: shape (pop_size, num_total_cases)
    arr = np.asarray(fitnesses, dtype=float)

    # Down-sample fraction of cases to consider per selection event
    sample_size = max(1, int(np.ceil(0.5 * num_total_cases)))
    cases = np.random.choice(num_total_cases, size=sample_size, replace=False)

    # Start with all individuals as candidates
    candidates = np.arange(pop_size)
    last_non_empty = candidates.copy()

    for c in cases:
        if candidates.size <= 1:
            break
        # compute epsilon for case c using median absolute deviation over the whole population
        col = arr[:, c]
        med = np.median(col)
        mad = np.median(np.abs(col - med))
        eps = mad if mad > 0.0 else 1e-8

        errors = arr[candidates, c]
        best = errors.min()
        pass_thresh = best + eps

        passed_mask = errors <= pass_thresh
        new_candidates = candidates[passed_mask]

        if new_candidates.size == 0:
            # fallback to last non-empty candidate set
            candidates = last_non_empty
            break

        last_non_empty = new_candidates.copy()
        candidates = new_candidates

    # If multiple candidates remain, prefer lower mean error, then break ties randomly
    if candidates.size > 1:
        means = arr[candidates].mean(axis=1)
        min_mean = means.min()
        bests = candidates[means <= (min_mean + 1e-12)]
        return int(np.random.choice(bests))

    # single candidate
    return int(candidates[0])