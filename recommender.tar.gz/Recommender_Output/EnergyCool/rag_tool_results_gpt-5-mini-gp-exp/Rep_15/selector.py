import numpy as np

def selection(fitnesses):
    # Calculate required values
    num_total_cases = len(fitnesses[0])
    pop_size = len(fitnesses)

    # Convert to numpy array: shape (pop_size, num_total_cases)
    errors = np.array(fitnesses, dtype=float)

    # Random ordering of cases
    cases = np.arange(num_total_cases)
    np.random.shuffle(cases)

    # Initialize candidate indices (all individuals)
    candidates = np.arange(pop_size)

    for case in cases:
        # Errors for current candidates on this case
        case_errors = errors[candidates, case]

        # Best (minimum) error among candidates on this case
        best = np.min(case_errors)

        # Compute epsilon for this case across the whole population (robust spread)
        all_case_errors = errors[:, case]
        median = np.median(all_case_errors)
        mad = np.median(np.abs(all_case_errors - median))

        # Fallbacks to avoid zero epsilon
        eps = mad
        if eps == 0:
            eps = np.mean(np.abs(all_case_errors - median))
        if eps == 0:
            eps = 1e-8

        # Select candidates that are within best + eps
        pass_mask = case_errors <= (best + eps)
        candidates = candidates[pass_mask]

        # If only one candidate remains, return it
        if candidates.size == 1:
            return int(candidates[0])

        # If no candidates (shouldn't happen), break and fallback to random
        if candidates.size == 0:
            break

    # If multiple candidates remain after all cases, pick one uniformly at random
    if candidates.size > 0:
        return int(np.random.choice(candidates))

    # Fallback: choose a random individual from the whole population
    return int(np.random.randint(0, pop_size))