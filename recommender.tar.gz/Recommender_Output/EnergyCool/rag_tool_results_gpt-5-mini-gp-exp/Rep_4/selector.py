def selection(fitnesses):
    import numpy as np

    # (1) number of test cases
    num_total_cases = len(fitnesses[0])
    # (2) population size
    pop_size = len(fitnesses)

    # Convert to numpy array: shape (pop_size, num_total_cases)
    arr = np.asarray(fitnesses, dtype=float)

    # Down-sample fraction: use half the cases (min 1)
    sample_size = max(1, int(np.ceil(num_total_cases * 0.5)))

    # Randomly choose a subset of cases without replacement and shuffle their order
    case_indices = np.random.choice(num_total_cases, size=sample_size, replace=False)
    np.random.shuffle(case_indices)

    # Start with all candidate indices
    candidates = np.arange(pop_size)

    for case in case_indices:
        # If only one candidate remains, return it
        if candidates.size == 1:
            return int(candidates[0])

        # Errors of current candidates on this case
        errors = arr[candidates, case]

        # Minimum error among candidates for this case
        min_err = np.min(errors)

        # Dynamic epsilon: median absolute deviation among current candidates
        med = np.median(errors)
        eps = np.median(np.abs(errors - med))
        if eps <= 0.0:
            eps = 1e-8

        # Keep candidates whose error is within min_err + eps
        keep_mask = errors <= (min_err + eps)
        candidates = candidates[keep_mask]

        # Safety: if no candidates remain (unlikely), fallback to best total-error individual
        if candidates.size == 0:
            total_err = arr.sum(axis=1)
            return int(np.argmin(total_err))

    # If multiple candidates remain after all cases, choose uniformly at random among them
    if candidates.size == 0:
        total_err = arr.sum(axis=1)
        return int(np.argmin(total_err))

    return int(np.random.choice(candidates, size=1)[0])