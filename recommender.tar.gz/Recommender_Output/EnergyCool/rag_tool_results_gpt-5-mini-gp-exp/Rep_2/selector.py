def selection(fitnesses):
    import numpy as np
    # (1) number of test cases
    num_total_cases = len(fitnesses[0])
    # (2) population size
    pop_size = len(fitnesses)

    # Convert to numpy array for efficient slicing
    arr = np.array(fitnesses, dtype=float)  # shape (pop_size, num_total_cases)

    # Initialize candidate pool (indices)
    candidates = list(range(pop_size))

    # Randomize case order
    case_indices = np.arange(num_total_cases)
    np.random.shuffle(case_indices)

    for case in case_indices:
        if len(candidates) <= 1:
            break
        # Errors for the current candidates on this case
        errs = arr[candidates, case]
        # Dynamic epsilon: median absolute deviation (MAD) over current candidates
        med = np.median(errs)
        mad = np.median(np.abs(errs - med))
        eps = max(mad, 1e-12)
        # Best (minimum) error among candidates
        best = np.min(errs)
        # Filter candidates: keep those within best + eps
        new_candidates = [candidates[i] for i, e in enumerate(errs) if e <= best + eps]
        if new_candidates:
            candidates = new_candidates
    # If multiple remain, choose uniformly at random among them
    if len(candidates) == 0:
        # Fallback: choose uniformly from full population
        return int(np.random.randint(0, pop_size))
    if len(candidates) == 1:
        return int(candidates[0])
    return int(np.random.choice(candidates))