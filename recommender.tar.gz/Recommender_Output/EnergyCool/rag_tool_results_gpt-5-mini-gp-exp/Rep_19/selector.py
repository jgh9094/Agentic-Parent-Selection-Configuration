def selection(fitnesses):
    import numpy as np

    # 1) Calculate num_total_cases
    num_total_cases = len(fitnesses[0])
    # 2) Calculate pop_size
    pop_size = len(fitnesses)

    arr = np.asarray(fitnesses, dtype=float)

    # Compute epsilon per case using median absolute deviation (parameter-less)
    eps = np.zeros(num_total_cases, dtype=float)
    for t in range(num_total_cases):
        col = arr[:, t]
        med = np.median(col)
        eps[t] = np.median(np.abs(col - med))

    # Candidate pool: all individuals
    candidates = list(range(pop_size))

    # Randomize order of cases
    case_order = np.random.permutation(num_total_cases)

    for t in case_order:
        # errors for current candidates on case t
        cand_errors = arr[candidates, t]
        min_err = np.min(cand_errors)
        threshold = min_err + eps[t]

        # filter candidates that are within min + epsilon
        new_candidates = [c for c in candidates if arr[c, t] <= threshold]

        # If filtering removes everyone (numerical issues), keep previous candidates
        if len(new_candidates) == 0:
            new_candidates = candidates

        candidates = new_candidates

        # If only one candidate remains, select it
        if len(candidates) == 1:
            return int(candidates[0])

    # If multiple remain after all cases, pick one uniformly at random
    return int(np.random.choice(candidates))