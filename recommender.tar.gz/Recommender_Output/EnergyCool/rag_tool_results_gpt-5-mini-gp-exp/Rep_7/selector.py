def selection(fitnesses):
    import numpy as np

    # (1) num_total_cases
    if len(fitnesses) == 0:
        raise ValueError("Empty population")
    num_total_cases = len(fitnesses[0])
    # (2) pop_size
    pop_size = len(fitnesses)

    # Convert to numpy array: shape (pop_size, num_total_cases)
    arr = np.array(fitnesses, dtype=float)
    if arr.shape != (pop_size, num_total_cases):
        # Ensure consistent shape
        arr = arr.reshape((pop_size, num_total_cases))

    # Random order of cases
    case_order = np.random.permutation(num_total_cases)

    # Candidate indices
    candidates = np.arange(pop_size)

    # Dynamic epsilon-lexicase: compute epsilon (MAD) on current candidate pool
    for case in case_order:
        if candidates.size <= 1:
            break
        errors = arr[candidates, case]
        # best (minimum) error on this case among candidates
        best = errors.min()
        # median absolute deviation (MAD) as epsilon; fallback to small positive
        median = np.median(errors)
        mad = np.median(np.abs(errors - median))
        eps = mad if mad > 0.0 else 1e-8
        # Keep candidates whose error <= best + eps
        keep_mask = errors <= (best + eps)
        candidates = candidates[keep_mask]

    # If none survived (unlikely), pick uniformly at random from population
    if candidates.size == 0:
        return int(np.random.randint(0, pop_size))
    # If multiple remain, choose randomly among them
    return int(np.random.choice(candidates))