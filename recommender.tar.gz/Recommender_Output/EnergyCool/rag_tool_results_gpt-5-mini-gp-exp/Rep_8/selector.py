def selection(fitnesses):
    import numpy as np
    # (1) num_total_cases
    num_total_cases = len(fitnesses[0])
    # (2) pop_size
    pop_size = len(fitnesses)
    # Convert to numpy array (pop_size x num_total_cases)
    arr = np.array(fitnesses, dtype=float)
    if pop_size == 0 or num_total_cases == 0:
        raise ValueError("Empty population or no cases")
    # Down-sample fraction (empirically effective default)
    sample_fraction = 0.5
    sample_size = max(1, int(np.ceil(sample_fraction * num_total_cases)))
    # Randomly choose a subset of cases without replacement
    cases = np.random.permutation(num_total_cases)[:sample_size]
    # Compute static epsilon per sampled case using median absolute deviation (robust)
    med = np.median(arr[:, cases], axis=0)
    mad = np.median(np.abs(arr[:, cases] - med), axis=0)
    eps = mad.copy()
    eps[eps == 0] = 1e-8
    # Initialize candidate set (indices)
    candidates = np.arange(pop_size)
    # Randomize order of sampled cases
    order = np.random.permutation(sample_size)
    for idx in order:
        c = cases[idx]
        case_errs = arr[candidates, c]
        best = np.min(case_errs)
        thresh = best + eps[idx]
        mask = case_errs <= thresh
        candidates = candidates[mask]
        if candidates.size == 1:
            return int(candidates[0])
        if candidates.size == 0:
            # Fallback: pick uniformly at random from full population
            return int(np.random.randint(pop_size))
    # If multiple candidates remain, pick one uniformly at random
    return int(np.random.choice(candidates))