def selection(fitnesses):
    import numpy as np

    # 1) Calculate sizes as required
    num_total_cases = len(fitnesses[0])
    pop_size = len(fitnesses)

    # Convert to numpy array (pop_size x num_total_cases)
    arr = np.array(fitnesses, dtype=float)

    # Dynamic epsilon per case: median absolute deviation across population
    med = np.median(arr, axis=0)
    mad = np.median(np.abs(arr - med), axis=0)
    eps = np.maximum(mad, 1e-8)

    # Down-sample a random subset of cases to evaluate for this selection event
    # Use 50% of cases (at least 1) as a pragmatic default for down-sampling
    sample_size = max(1, int(np.ceil(num_total_cases * 0.5)))
    cases = np.random.permutation(num_total_cases)[:sample_size]

    # Start with all individuals as candidates
    candidates = np.arange(pop_size)

    # Process sampled cases in random order, filtering candidates by epsilon threshold
    for c in cases:
        case_errors = arr[candidates, c]
        best = np.min(case_errors)
        thresh = best + eps[c]
        mask = case_errors <= thresh
        candidates = candidates[mask]
        if candidates.size == 1:
            return int(candidates[0])

    # If multiple candidates remain, choose uniformly at random among them
    if candidates.size > 0:
        return int(np.random.choice(candidates))

    # Fallback: if something unexpected happens, return a random individual
    return int(np.random.randint(pop_size))