def selection(fitnesses):
    import numpy as np
    # 1) Calculate num_total_cases
    num_total_cases = len(fitnesses[0])
    # 2) Calculate pop_size
    pop_size = len(fitnesses)
    # Convert to numpy array for vectorized operations
    arr = np.array(fitnesses, dtype=float)
    # Start with all individuals as candidates
    candidates = np.arange(pop_size)
    # Randomize the order of cases
    case_order = np.arange(num_total_cases)
    np.random.shuffle(case_order)
    # Dynamic ϵ-lexicase: compute epsilon from current candidate pool for each case
    for case in case_order:
        errs = arr[candidates, case]
        # Best error among candidates for this case
        best = np.min(errs)
        # Median absolute deviation (robust spread estimator)
        med = np.median(errs)
        mad = np.median(np.abs(errs - med))
        eps = mad
        if not np.isfinite(eps) or eps == 0:
            eps = 1e-8
        # Keep candidates whose error is within best + eps
        mask = errs <= (best + eps)
        candidates = candidates[mask]
        if candidates.size == 1:
            return int(candidates[0])
    # If multiple candidates remain, pick one at random; if none, fallback to uniform random
    if candidates.size == 0:
        return int(np.random.randint(pop_size))
    return int(np.random.choice(candidates))