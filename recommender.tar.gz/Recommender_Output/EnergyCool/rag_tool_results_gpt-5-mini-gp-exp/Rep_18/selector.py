def selection(fitnesses):
    import numpy as np

    # 1) Calculate num_total_cases as len(fitnesses[0]).
    # 2) Calculate pop_size as len(fitnesses).
    num_total_cases = len(fitnesses[0])
    pop_size = len(fitnesses)

    # Convert to numpy array for efficient indexing
    errs = np.array(fitnesses, dtype=float)  # shape: (pop_size, num_total_cases)

    # Candidate pool: indices of individuals still under consideration
    candidates = np.arange(pop_size)

    # Randomize order of test cases for this selection event
    case_order = np.random.permutation(num_total_cases)

    for t in case_order:
        if candidates.size <= 1:
            break

        # Errors of current candidates on case t
        e = errs[candidates, t]

        # Minimum error among candidates on this case
        min_e = np.min(e)

        # Dynamic epsilon: median absolute deviation (MAD) of errors among candidates
        eps = np.median(np.abs(e - np.median(e)))

        # Filter candidates who are within min_e + eps
        thresh = min_e + eps
        mask = e <= thresh

        # Fallback: if filtering eliminates all, keep those with minimum error
        if not np.any(mask):
            mask = e == np.min(e)

        candidates = candidates[mask]

    # If by some numeric edge case no candidates remain, choose randomly from population
    if candidates.size == 0:
        return int(np.random.randint(pop_size))

    # If multiple candidates remain after all cases, pick one uniformly at random
    return int(np.random.choice(candidates))