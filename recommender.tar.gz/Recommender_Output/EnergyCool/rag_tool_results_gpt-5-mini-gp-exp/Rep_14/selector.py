def selection(fitnesses):
    import numpy as np
    # (1) number of test cases
    num_total_cases = len(fitnesses[0])
    # (2) population size
    pop_size = len(fitnesses)

    # Convert to numpy array: shape (pop_size, num_cases)
    arr = np.array(fitnesses, dtype=float)

    # Handle trivial cases
    if pop_size == 1:
        return 0

    # Per-case statistics for epsilon (median absolute deviation)
    med = np.median(arr, axis=0)
    mad = np.median(np.abs(arr - med), axis=0)
    eps = np.maximum(mad, 1e-8)

    # Per-case best (minimum error)
    best = np.min(arr, axis=0)

    # Randomized ordering of cases
    cases = np.arange(num_total_cases)
    np.random.shuffle(cases)

    # Initialize candidate set to all individuals
    candidates = np.arange(pop_size)

    for c in cases:
        prev_candidates = candidates
        thresh = best[c] + eps[c]
        mask = arr[candidates, c] <= thresh
        candidates = candidates[mask]
        if candidates.size == 1:
            return int(candidates[0])
        if candidates.size == 0:
            # If filtering removes all, revert to previous candidates and stop
            candidates = prev_candidates
            break

    # If multiple remain, pick uniformly at random among them
    return int(np.random.choice(candidates))