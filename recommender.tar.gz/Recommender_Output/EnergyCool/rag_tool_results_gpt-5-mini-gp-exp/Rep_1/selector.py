def selection(fitnesses):
    import numpy as np
    # Required summary values
    num_total_cases = len(fitnesses[0])
    pop_size = len(fitnesses)

    # Convert to numpy array (pop_size x num_total_cases)
    arr = np.asarray(fitnesses, dtype=float)
    if arr.shape != (pop_size, num_total_cases):
        # Ensure consistent shape: truncate or pad with large errors if necessary
        new = np.full((pop_size, num_total_cases), np.finfo(float).max, dtype=float)
        for i in range(pop_size):
            row = np.asarray(fitnesses[i], dtype=float)
            L = min(len(row), num_total_cases)
            new[i, :L] = row[:L]
        arr = new

    # Compute per-case epsilon as median absolute deviation (robust to outliers)
    med = np.median(arr, axis=0)
    mad = np.median(np.abs(arr - med), axis=0)
    eps = np.maximum(mad, 1e-8)

    # Start with all candidates and a random ordering of cases
    candidates = np.arange(pop_size)
    case_order = np.random.permutation(num_total_cases)

    for case in case_order:
        if candidates.size == 1:
            return int(candidates[0])
        vals = arr[candidates, case]
        best = np.min(vals)
        thresh = best + eps[case]
        mask = vals <= thresh
        candidates = candidates[mask]
        if candidates.size == 0:
            # Fallback: choose best from previous set (shouldn't happen due to thresh)
            return int(np.argmin(arr[:, case]))
        if candidates.size == 1:
            return int(candidates[0])

    # If multiple candidates remain, choose uniformly at random
    return int(np.random.choice(candidates))