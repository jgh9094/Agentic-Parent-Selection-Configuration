def selection(fitnesses):
    import numpy as np
    # Handle empty input
    if not fitnesses:
        return 0
    pop_size = len(fitnesses)
    num_total_cases = len(fitnesses[0])
    arr = np.array(fitnesses, dtype=float)  # shape: (pop_size, num_cases)
    # Down-sample a fraction of cases (20% or at least 1)
    sample_size = max(1, int(np.ceil(0.2 * num_total_cases)))
    case_indices = np.random.permutation(num_total_cases)[:sample_size]
    # Compute epsilon per sampled case using median absolute deviation
    sampled = arr[:, case_indices]  # shape: (pop_size, sample_size)
    medians = np.median(sampled, axis=0)
    mad = np.median(np.abs(sampled - medians), axis=0)
    eps = np.maximum(mad, 1e-12)
    # Initialize candidate set
    candidates = np.arange(pop_size)
    # Lexicase filtering across sampled cases in random order
    for i, c in enumerate(case_indices):
        if candidates.size <= 1:
            break
        case_errors = arr[candidates, c]
        best = np.min(case_errors)
        threshold = best + eps[i]
        mask = case_errors <= threshold
        candidates = candidates[mask]
        # If filtering eliminates all, reset to full population and stop
        if candidates.size == 0:
            candidates = np.arange(pop_size)
            break
    # If multiple candidates remain, choose one uniformly at random
    chosen = int(np.random.choice(candidates))
    return chosen