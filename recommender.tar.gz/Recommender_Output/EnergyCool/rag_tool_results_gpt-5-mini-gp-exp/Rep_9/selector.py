def selection(fitnesses):
    import numpy as np

    # 1) Calculate sizes
    num_total_cases = len(fitnesses[0])
    pop_size = len(fitnesses)

    # Convert to numpy array: shape (pop_size, num_total_cases)
    arr = np.asarray(fitnesses, dtype=float)

    # Down-sampling fraction (use small subsample as in literature, e.g., 0.1)
    s = 0.1
    k = int(np.ceil(max(1, s * num_total_cases)))

    # Select a random subset of cases without replacement
    cases = np.arange(num_total_cases)
    if k >= num_total_cases:
        subsampled = np.copy(cases)
        np.random.shuffle(subsampled)
    else:
        subsampled = np.random.choice(cases, size=k, replace=False)
        np.random.shuffle(subsampled)

    # Candidate pool: indices of individuals still under consideration
    candidates = np.arange(pop_size)

    # Epsilon-lexicase filtering over the subsampled, randomized case order
    for t in subsampled:
        # errors of current candidates on case t
        e_t = arr[candidates, t]
        # dynamic epsilon: median absolute deviation (La Cava et al.)
        med = np.median(e_t)
        eps_t = np.median(np.abs(e_t - med))
        # best error among candidates on this case
        best = e_t.min()
        # pass threshold: best + eps
        thresh = best + eps_t
        # filter candidates that pass
        mask = e_t <= (thresh + 1e-12)
        candidates = candidates[mask]
        # if only one candidate remains, select it
        if candidates.size == 1:
            return int(candidates[0])
        # if no candidates remain due to numerical issues, fallback
        if candidates.size == 0:
            return int(np.random.randint(0, pop_size))

    # If multiple candidates remain after all cases, pick uniformly at random
    return int(np.random.choice(candidates))