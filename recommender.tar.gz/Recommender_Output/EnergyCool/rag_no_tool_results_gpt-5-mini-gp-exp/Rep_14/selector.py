def selection(fitnesses):
    import numpy as np
    # number of test cases and population size
    num_total_cases = len(fitnesses[0])
    pop_size = len(fitnesses)

    # Defensive checks
    if pop_size == 0:
        raise ValueError("Population is empty")
    if num_total_cases == 0:
        # If no cases, pick random individual
        return int(np.random.randint(0, pop_size))

    # Convert to numpy array: shape (pop_size, num_total_cases)
    arr = np.array(fitnesses, dtype=float)

    # Initial candidate set: all indices
    candidates = np.arange(pop_size)

    # Random permutation of case indices for lexicase ordering
    case_order = np.random.permutation(num_total_cases)

    for c in case_order:
        if candidates.size <= 1:
            break
        # Errors of current candidates on case c
        candidate_errs = arr[candidates, c]
        best = candidate_errs.min()

        # Compute epsilon for this case using median absolute deviation (MAD)
        all_errs = arr[:, c]
        med = np.median(all_errs)
        mad = np.median(np.abs(all_errs - med))
        # Fallback small epsilon if MAD is zero
        if mad <= 0:
            # use a tiny fraction of std deviation or tiny constant
            std = np.std(all_errs)
            eps = std * 1e-3 if std > 0 else 1e-12
        else:
            eps = mad
        # Filter candidates whose error is within best + eps
        keep_mask = candidate_errs <= (best + eps)
        candidates = candidates[keep_mask]

    # If no candidates remain (should be rare), fallback to global mean error minimizer
    if candidates.size == 0:
        mean_errs = arr.mean(axis=1)
        return int(int(np.argmin(mean_errs)))

    # If multiple remain, pick one uniformly at random
    if candidates.size > 1:
        return int(np.random.choice(candidates))

    # Single remaining candidate
    return int(candidates[0])