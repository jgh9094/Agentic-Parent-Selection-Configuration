def selection(fitnesses):
    import numpy as np
    # Step (1) and (2)
    num_total_cases = len(fitnesses[0])
    pop_size = len(fitnesses)

    # Convert to array: shape (pop_size, num_total_cases)
    arr = np.array(fitnesses, dtype=float)

    # Initial candidate set: all individuals
    candidates = np.arange(pop_size)

    # Randomize case order for lexicase
    case_order = np.random.permutation(num_total_cases)

    # Compute per-case epsilon using median absolute deviation (robust)
    med = np.median(arr, axis=0)
    mad = np.median(np.abs(arr - med), axis=0)
    # Ensure non-zero small epsilons to tolerate floating differences
    eps = np.maximum(mad, 1e-12)

    # Iteratively filter candidates by each case in random order
    for case in case_order:
        if candidates.size <= 1:
            break
        vals = arr[candidates, case]
        best = vals.min()
        thresh = best + eps[case]
        candidates = candidates[vals <= thresh]

    # If multiple remain, pick one uniformly at random
    if candidates.size == 0:
        # Fallback: pick random individual from full population
        return int(np.random.randint(pop_size))
    if candidates.size == 1:
        return int(candidates[0])
    return int(np.random.choice(candidates))