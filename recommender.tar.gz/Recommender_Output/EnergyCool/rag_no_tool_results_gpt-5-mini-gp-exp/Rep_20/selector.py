def selection(fitnesses):
    import numpy as np

    # 1) Calculate num_total_cases
    num_total_cases = len(fitnesses[0])
    # 2) Calculate pop_size
    pop_size = len(fitnesses)

    if pop_size == 0:
        raise ValueError("Empty population")

    # Convert to numpy array: shape (pop_size, num_total_cases)
    arr = np.asarray(fitnesses, dtype=float)

    # Randomize order of cases for lexicase
    case_order = np.random.permutation(num_total_cases)

    # Start with all candidate indices
    candidates = np.arange(pop_size)

    for c in case_order:
        # Errors of current candidates on case c
        errors_c = arr[candidates, c]
        min_err = errors_c.min()

        # Compute epsilon using median absolute deviation (MAD) across population for case c
        col = arr[:, c]
        med = np.median(col)
        mad = np.median(np.abs(col - med))
        eps = mad if mad > 1e-12 else 1e-12

        # Keep candidates within min_err + eps
        threshold = min_err + eps
        mask = errors_c <= threshold
        candidates = candidates[mask]

        # If only one candidate remains, return it
        if candidates.size == 1:
            return int(candidates[0])

    # If multiple remain after all cases, pick one uniformly at random
    return int(np.random.choice(candidates))