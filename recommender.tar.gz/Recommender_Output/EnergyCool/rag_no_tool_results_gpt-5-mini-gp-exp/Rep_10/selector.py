def selection(fitnesses):
    import numpy as np

    # Required derived values
    num_total_cases = len(fitnesses[0])
    pop_size = len(fitnesses)

    # Convert to numpy array: shape (pop_size, num_total_cases)
    arr = np.array(fitnesses, dtype=float)

    # Candidate indices
    candidates = np.arange(pop_size)

    # Randomize case order
    cases = np.arange(num_total_cases)
    np.random.shuffle(cases)

    for c in cases:
        # Errors for current candidates on case c
        errs_candidates = arr[candidates, c]

        # Best error across the entire population for this case
        best_error = np.min(arr[:, c])

        # Compute MAD-based epsilon across the population for robustness
        errors_all = arr[:, c]
        median = np.median(errors_all)
        mad = np.median(np.abs(errors_all - median))
        epsilon = max(mad, 1e-12)

        # Accept candidates within best + epsilon
        threshold = best_error + epsilon
        mask = errs_candidates <= threshold
        candidates = candidates[mask]

        if candidates.size == 1:
            return int(candidates[0])
        if candidates.size == 0:
            break

    # Fallback: if multiple remain, choose uniformly among them; if none, choose random individual
    if candidates.size == 0:
        return int(np.random.randint(0, pop_size))
    return int(np.random.choice(candidates))