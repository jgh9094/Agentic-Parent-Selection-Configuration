def selection(fitnesses):
    import numpy as np
    num_total_cases = len(fitnesses[0])
    pop_size = len(fitnesses)
    arr = np.asarray(fitnesses, dtype=float)
    if pop_size == 1:
        return 0
    cases = np.random.permutation(num_total_cases)
    candidates = np.arange(pop_size)
    for case in cases:
        if candidates.size <= 1:
            break
        errors = arr[candidates, case]
        med = np.median(errors)
        eps = np.median(np.abs(errors - med))
        if eps <= 0:
            overall_med = np.median(arr[:, case])
            eps = max(1e-8, 1e-6 * (abs(overall_med) + 1.0))
        best = np.min(errors)
        thresh = best + eps
        keep_mask = errors <= thresh
        candidates = candidates[keep_mask]
    if candidates.size == 0:
        return int(np.random.randint(pop_size))
    return int(np.random.choice(candidates))