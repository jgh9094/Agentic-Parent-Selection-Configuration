def selection(fitnesses):
    import numpy as np
    # Calculate required sizes
    num_total_cases = len(fitnesses[0])
    pop_size = len(fitnesses)
    # Convert to numpy array (shape: pop_size x num_total_cases)
    arr = np.array(fitnesses, dtype=float)
    # Compute mean squared error per individual (mean over test cases)
    with np.errstate(all='ignore'):
        per_ind_mse = np.nanmean(arr, axis=1)
    # Replace non-finite values with a large number to avoid selecting invalid individuals
    if not np.any(np.isfinite(per_ind_mse)):
        per_ind_mse = np.full(pop_size, 1e12, dtype=float)
    else:
        max_finite = np.nanmax(per_ind_mse[np.isfinite(per_ind_mse)])
        per_ind_mse[~np.isfinite(per_ind_mse)] = max_finite * 1e6 + 1.0
    # Tournament selection parameters
    k = min(7, pop_size)
    rng = np.random.default_rng()
    contestants = rng.choice(pop_size, size=k, replace=False)
    winner = contestants[int(np.argmin(per_ind_mse[contestants]))]
    return int(winner)