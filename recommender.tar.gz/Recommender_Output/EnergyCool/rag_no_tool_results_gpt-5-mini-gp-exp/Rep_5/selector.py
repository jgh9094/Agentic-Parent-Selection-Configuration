def selection(fitnesses):
    import numpy as np
    # number of test cases per individual
    num_total_cases = len(fitnesses[0])
    # population size
    pop_size = len(fitnesses)

    # convert to numpy array (pop_size x num_total_cases)
    arr = np.asarray(fitnesses, dtype=float)

    # trivial case
    if pop_size <= 1:
        return 0

    # compute per-case median absolute deviation (MAD) as epsilon baseline
    medians = np.median(arr, axis=0)
    mads = np.median(np.abs(arr - medians), axis=0)
    epsilons = np.maximum(mads, 1e-8)

    # randomize the order of cases
    case_order = np.random.permutation(num_total_cases)

    # start with all individuals as candidates
    candidates = np.arange(pop_size)

    for case in case_order:
        case_errors = arr[candidates, case]
        best = np.min(case_errors)
        eps = epsilons[case]
        # keep individuals within best + epsilon
        keep_mask = case_errors <= (best + eps)
        candidates = candidates[keep_mask]
        if candidates.size == 1:
            return int(candidates[0])
        if candidates.size == 0:
            break

    # if multiple candidates remain (or none), pick one at random from original population filtered by last valid candidates
    if candidates.size == 0:
        # fallback: choose any individual with global minimum mean error
        mean_errors = np.mean(arr, axis=1)
        best_idx = int(np.argmin(mean_errors))
        return best_idx

    return int(np.random.choice(candidates))