def selection(fitnesses):
    import numpy as np
    # number of test cases per individual
    num_total_cases = len(fitnesses[0])
    # population size
    pop_size = len(fitnesses)
    # array of per-case errors (lower is better)
    arr = np.asarray(fitnesses, dtype=float)
    # tournament size (configurable); keep reasonable pressure for GP
    k = min(7, pop_size)
    # select k competitors without replacement
    competitors = np.random.choice(pop_size, size=k, replace=False)
    # aggregate error per competitor (mean across cases)
    agg_errors = arr[competitors].mean(axis=1)
    # pick the competitor(s) with minimal error and break ties randomly
    best_mask = agg_errors == agg_errors.min()
    best_candidates = competitors[best_mask]
    return int(np.random.choice(best_candidates))