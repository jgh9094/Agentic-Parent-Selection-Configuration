def selection(fitnesses):
    import numpy as np

    # Required derived values
    num_total_cases = len(fitnesses[0])
    pop_size = len(fitnesses)

    # Convert to array: shape (pop_size, num_total_cases)
    fits = np.array(fitnesses, dtype=float)

    rng = np.random.default_rng()

    # Initial candidate indices
    candidates = np.arange(pop_size)

    # Randomized order of cases for lexicase filtering
    case_order = rng.permutation(num_total_cases)

    for case in case_order:
        # Errors for current candidates on this case
        case_errors = fits[candidates, case]

        # Minimum error among candidates
        min_err = case_errors.min()

        # Compute adaptive epsilon using median absolute deviation (MAD) across the whole population
        all_case_errors = fits[:, case]
        med = np.median(all_case_errors)
        mad = np.median(np.abs(all_case_errors - med))

        # Fallback small epsilon when MAD is zero
        if mad > 0:
            epsilon = mad
        else:
            epsilon = max(1e-12, 1e-6 * (abs(med) + 1.0))

        threshold = min_err + epsilon

        # Keep candidates that are within epsilon of the best on this case
        mask = case_errors <= threshold
        candidates = candidates[mask]

        # If only one candidate remains, return it
        if candidates.size == 1:
            return int(candidates[0])

    # If multiple candidates remain after all cases, pick one uniformly at random
    if candidates.size == 0:
        # Fallback: choose any individual if filtering eliminated all
        return int(rng.integers(0, pop_size))

    return int(rng.choice(candidates))