def selection(fitnesses):
    import numpy as np

    # (1) Calculate num_total_cases as len(fitnesses[0]).
    num_total_cases = len(fitnesses[0])
    # (2) Calculate pop_size as len(fitnesses).
    pop_size = len(fitnesses)

    # Convert to numpy array: shape (pop_size, num_total_cases)
    arr = np.array(fitnesses, dtype=float)

    # Initialize candidate indices and randomize case order
    indices = np.arange(pop_size)
    cases = np.arange(num_total_cases)
    np.random.shuffle(cases)

    remaining = indices.copy()

    for case in cases:
        errors = arr[remaining, case]
        # best (minimum) error for this case
        best = errors.min()
        # epsilon: median absolute deviation (robust spread)
        med = np.median(errors)
        eps = np.median(np.abs(errors - med))
        # threshold: allow those within best + eps
        threshold = best + eps
        mask = errors <= threshold
        remaining = remaining[mask]
        if remaining.size == 1:
            return int(remaining[0])

    # If multiple remain after all cases, pick one uniformly at random
    if remaining.size > 0:
        return int(np.random.choice(remaining))

    # Fallback: choose uniformly from full population
    return int(np.random.randint(0, pop_size))