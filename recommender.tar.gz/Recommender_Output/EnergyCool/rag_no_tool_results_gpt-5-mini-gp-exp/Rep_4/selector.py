def selection(fitnesses):
    import numpy as np

    # 1) num_total_cases
    num_total_cases = len(fitnesses[0])
    # 2) pop_size
    pop_size = len(fitnesses)

    # Convert to numpy array (pop_size, num_total_cases)
    arr = np.array(fitnesses, dtype=float)

    # Compute per-case epsilon using median absolute deviation (robust dispersion)
    med = np.median(arr, axis=0)
    mad = np.median(np.abs(arr - med), axis=0)
    # Small floor to avoid exact-zero thresholds
    eps = mad + 1e-8

    # Random ordering of cases for lexicase
    cases = np.random.permutation(num_total_cases)

    # Start with all candidate indices
    candidates = np.arange(pop_size)

    for c in cases:
        # errors of current candidates on case c
        vals = arr[candidates, c]
        best = np.min(vals)
        thr = best + eps[c]
        # keep candidates within threshold
        mask = vals <= thr
        candidates = candidates[mask]
        if candidates.size == 1:
            return int(candidates[0])

    # If multiple remain after all cases, choose uniformly at random
    return int(np.random.choice(candidates))