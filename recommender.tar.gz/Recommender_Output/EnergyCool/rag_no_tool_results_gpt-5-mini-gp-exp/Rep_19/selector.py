def selection(fitnesses):
    import numpy as np

    # 1) Calculate num_total_cases
    num_total_cases = len(fitnesses[0])
    # 2) Calculate pop_size
    pop_size = len(fitnesses)

    # Handle degenerate inputs
    if pop_size == 0 or num_total_cases == 0:
        return 0

    # Convert to numpy array: shape (pop_size, num_total_cases)
    arr = np.array(fitnesses, dtype=float)

    # Randomized ordering of cases (lexicase)
    cases = np.random.permutation(num_total_cases)

    # Start with all individuals as candidates
    candidates = np.arange(pop_size)

    for c in cases:
        cand_errors = arr[candidates, c]
        # Best (minimum) error among current candidates for this case
        best = np.nanmin(cand_errors)
        # Epsilon tolerance: median absolute deviation (robust) + tiny floor
        mad = np.median(np.abs(cand_errors - np.median(cand_errors)))
        eps = mad + 1e-12
        # Keep candidates that are within best + eps
        candidates = candidates[cand_errors <= best + eps]
        if candidates.size == 1:
            return int(candidates[0])

    # If multiple remain after all cases, pick uniformly at random
    return int(np.random.choice(candidates))