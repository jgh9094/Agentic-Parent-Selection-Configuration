def selection(fitnesses):
    import numpy as np
    # Required quantities
    num_total_cases = len(fitnesses[0])
    pop_size = len(fitnesses)

    # Convert to numpy array of shape (pop_size, num_total_cases)
    arr = np.asarray(fitnesses, dtype=float)

    # Compute per-case epsilon using median absolute deviation (MAD)
    med = np.median(arr, axis=0)
    mad = np.median(np.abs(arr - med), axis=0)
    eps = mad + 1e-12

    # Initialize candidate set and randomize case order
    candidates = np.arange(pop_size)
    case_indices = np.arange(num_total_cases)
    np.random.shuffle(case_indices)

    for c in case_indices:
        cand_errors = arr[candidates, c]
        best = np.min(cand_errors)
        mask = cand_errors <= (best + eps[c])
        candidates = candidates[mask]
        if candidates.size == 1:
            return int(candidates[0])
        if candidates.size == 0:
            return int(np.random.randint(pop_size))

    # If multiple remain after all cases, choose uniformly at random among them
    return int(np.random.choice(candidates))