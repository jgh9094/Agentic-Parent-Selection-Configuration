def selection(fitnesses):
    import numpy as np

    # (1) and (2) as required
    num_total_cases = len(fitnesses[0])
    pop_size = len(fitnesses)

    # Convert to numpy array: shape (pop_size, num_total_cases)
    arr = np.array(fitnesses, dtype=float)

    # Candidate indices start as all individuals
    candidates = np.arange(pop_size)

    # Randomize order of test cases for lexicase filtering
    case_indices = np.arange(num_total_cases)
    np.random.shuffle(case_indices)

    for ci in case_indices:
        if candidates.size <= 1:
            break
        errors = arr[candidates, ci]
        best = np.min(errors)
        # Epsilon computed as median absolute deviation (robust to outliers)
        med = np.median(errors)
        mad = np.median(np.abs(errors - med))
        epsilon = max(mad, 1e-12)
        # Keep candidates within best + epsilon
        mask = errors <= (best + epsilon)
        candidates = candidates[mask]

    # If filtering removed all or none, fall back to random choice among survivors
    if candidates.size == 0:
        return int(np.random.randint(pop_size))
    if candidates.size == 1:
        return int(candidates[0])
    return int(np.random.choice(candidates))