def selection(fitnesses):
    import numpy as np
    # Number of test cases per individual
    num_total_cases = len(fitnesses[0])
    # Population size
    pop_size = len(fitnesses)
    if pop_size == 0:
        raise ValueError("Population is empty")
    # Compute per-individual mean error (lower is better)
    try:
        arr = np.array(fitnesses, dtype=float)
    except Exception:
        # Fallback: compute means elementwise if ragged
        means = np.array([np.mean(f) for f in fitnesses], dtype=float)
    else:
        if arr.ndim != 2 or arr.shape[1] != num_total_cases:
            means = np.array([np.mean(f) for f in fitnesses], dtype=float)
        else:
            means = arr.mean(axis=1)
    # Tournament size (cap at population size)
    k = min(7, pop_size)
    # Select k competitors without replacement
    competitors = np.random.choice(pop_size, size=k, replace=False)
    comp_means = means[competitors]
    # Choose the competitor with minimal mean error; break ties randomly
    min_val = comp_means.min()
    tie_positions = np.flatnonzero(comp_means == min_val)
    chosen_pos = np.random.choice(tie_positions)
    chosen_index = int(competitors[chosen_pos])
    return chosen_index