def selection(fitnesses):
    import numpy as np
    num_total_cases = len(fitnesses[0])
    pop_size = len(fitnesses)
    arr = np.array(fitnesses, dtype=float)
    med = np.median(arr, axis=0)
    mad = np.median(np.abs(arr - med), axis=0)
    eps = mad + 1e-8
    cases = np.arange(num_total_cases)
    np.random.shuffle(cases)
    candidates = np.arange(pop_size)
    for c in cases:
        if candidates.size <= 1:
            break
        case_errors = arr[candidates, c]
        best = np.min(case_errors)
        threshold = best + eps[c]
        mask = case_errors <= threshold
        candidates = candidates[mask]
    if candidates.size == 0:
        sums = arr.sum(axis=1)
        return int(np.argmin(sums))
    return int(np.random.choice(candidates))