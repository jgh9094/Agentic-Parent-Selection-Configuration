def selection(fitnesses):
    import numpy as np
    # number of test cases per individual
    num_total_cases = len(fitnesses[0])
    # population size
    pop_size = len(fitnesses)
    if pop_size == 0:
        raise ValueError("Empty population")
    # convert to array: shape (pop_size, num_total_cases)
    arr = np.array(fitnesses, dtype=float)
    # aggregate fitness per individual: mean squared error (lower is better)
    agg = arr.mean(axis=1)
    # tournament size (7-way); adjust if population is smaller
    k = 7
    if k > pop_size:
        k = pop_size
    # select k unique contenders and pick the one with minimal aggregate error
    contenders = np.random.choice(pop_size, size=k, replace=False)
    winner_idx = contenders[np.argmin(agg[contenders])]
    return int(winner_idx)