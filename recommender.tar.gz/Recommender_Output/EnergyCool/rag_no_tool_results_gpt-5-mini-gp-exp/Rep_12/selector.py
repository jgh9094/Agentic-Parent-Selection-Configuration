import numpy as np

def selection(fitnesses):
    # 1) Calculate num_total_cases
    num_total_cases = len(fitnesses[0])
    # 2) Calculate pop_size
    pop_size = len(fitnesses)
    # Convert to numpy array for efficient operations
    arr = np.asarray(fitnesses, dtype=float)
    # Aggregate per-individual error (lower is better): use mean squared error across cases
    mean_err = arr.mean(axis=1)
    # Tournament size (bounded by population size)
    tournament_size = min(7, pop_size)
    # Select tournament contestants without replacement
    contestants = np.random.choice(pop_size, size=tournament_size, replace=False)
    # Choose the contestant with minimal mean error
    winner_idx = contestants[np.argmin(mean_err[contestants])]
    return int(winner_idx)