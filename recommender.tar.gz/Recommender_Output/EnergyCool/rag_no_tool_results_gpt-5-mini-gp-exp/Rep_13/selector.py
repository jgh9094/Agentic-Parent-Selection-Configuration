import numpy as np

def selection(fitnesses):
    num_total_cases = len(fitnesses[0])
    pop_size = len(fitnesses)
    arr = np.asarray(fitnesses, dtype=float)

    # per-case best (lower is better)
    best = np.min(arr, axis=0)

    # epsilon per case: median absolute deviation (robust to outliers)
    median = np.median(arr, axis=0)
    mad = np.median(np.abs(arr - median), axis=0)
    eps = np.where(mad <= 0.0, 1e-8, mad)

    candidates = np.arange(pop_size)
    case_order = np.random.permutation(num_total_cases)

    for c in case_order:
        thresh = best[c] + eps[c]
        mask = arr[candidates, c] <= thresh
        candidates = candidates[mask]
        if candidates.size == 1:
            return int(candidates[0])

    if candidates.size == 0:
        # fallback: choose the individual with minimal total error
        total_err = np.sum(arr, axis=1)
        return int(np.argmin(total_err))

    return int(np.random.choice(candidates))