def selection(fitnesses):
    import numpy as np

    # 1) Calculate num_total_cases as len(fitnesses[0]).
    num_total_cases = len(fitnesses[0])
    # 2) Calculate pop_size as len(fitnesses).
    pop_size = len(fitnesses)

    if pop_size == 0:
        raise ValueError("Empty population")
    if pop_size == 1:
        return 0

    # Compute scalar fitness: mean error per individual (errors are to be minimized)
    mean_errors = np.array([np.mean(ind) for ind in fitnesses], dtype=float)

    # Tournament size k (bounded by population size)
    k = min(7, pop_size)

    # Sample k distinct competitors
    competitors = np.random.choice(pop_size, size=k, replace=False)
    comp_errors = mean_errors[competitors]

    # Winner is the competitor with minimum mean error; break ties randomly
    min_err = comp_errors.min()
    winners = competitors[comp_errors == min_err]
    winner = int(np.random.choice(winners, size=1)[0])

    return winner