import numpy as np

def selection(fitnesses):
    # number of test cases per individual
    num_total_cases = len(fitnesses[0])
    # population size
    pop_size = len(fitnesses)

    # Convert to numpy array for vectorized aggregation
    arr = np.array(fitnesses, dtype=float)  # shape: (pop_size, num_total_cases)

    # Aggregate per-individual error: mean squared error across cases (errors are already squared abs diffs)
    mean_errors = arr.mean(axis=1)

    # Tournament selection parameters
    tourn_size = 7
    k = min(tourn_size, pop_size)

    # Select k distinct contestants uniformly at random
    contestants = np.random.choice(pop_size, size=k, replace=False)

    # Choose the contestant with minimal mean error
    winner = contestants[np.argmin(mean_errors[contestants])]

    return int(winner)