import numpy as np
def selection(fitnesses):
    num_total_cases = len(fitnesses[0])
    pop_size = len(fitnesses)
    epsilon = 0.01

    case_order = np.random.permutation(num_total_cases)
    candidates = list(range(pop_size))

    for case in case_order:
        min_error = min(fitnesses[i][case] for i in candidates)
        threshold = min_error + epsilon
        candidates = [i for i in candidates if fitnesses[i][case] <= threshold]

        if len(candidates) == 1:
            return candidates[0]

    return np.random.choice(candidates)