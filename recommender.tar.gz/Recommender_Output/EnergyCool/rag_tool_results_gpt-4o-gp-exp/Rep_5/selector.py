import numpy as np
def selection(fitnesses):
    num_total_cases = len(fitnesses[0])
    pop_size = len(fitnesses)
    epsilon = 0.1

    indices = list(range(pop_size))
    for case_index in range(num_total_cases):
        case_errors = [fitnesses[i][case_index] for i in indices]
        min_error = min(case_errors)
        threshold = min_error + epsilon
        indices = [indices[i] for i in range(len(indices)) if case_errors[i] <= threshold]
        if len(indices) == 1:
            return indices[0]
    return np.random.choice(indices)