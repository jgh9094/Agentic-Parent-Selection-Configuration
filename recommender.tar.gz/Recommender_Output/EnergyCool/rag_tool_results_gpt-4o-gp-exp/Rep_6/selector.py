import numpy as np

def selection(fitnesses):
    num_total_cases = len(fitnesses[0])
    pop_size = len(fitnesses)
    epsilon = 0.1  # Relaxation parameter for ε-lexicase selection

    # Shuffle test cases
    test_case_order = np.random.permutation(num_total_cases)

    # Initialize candidate pool
    candidates = list(range(pop_size))

    for case in test_case_order:
        if len(candidates) == 1:
            break

        # Find minimum error for current test case
        min_error = min(fitnesses[i][case] for i in candidates)

        # Filter candidates based on ε condition
        candidates = [i for i in candidates if fitnesses[i][case] <= min_error + epsilon]

    return candidates[0]