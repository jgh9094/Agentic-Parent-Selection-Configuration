import numpy as np

def selection(fitnesses):
    num_total_cases = len(fitnesses[0])
    pop_size = len(fitnesses)
    indices = list(range(pop_size))
    np.random.shuffle(indices)

    for case_index in range(num_total_cases):
        min_error = min(fitnesses[i][case_index] for i in indices)
        indices = [i for i in indices if fitnesses[i][case_index] == min_error]
        if len(indices) == 1:
            return indices[0]

    return np.random.choice(indices)