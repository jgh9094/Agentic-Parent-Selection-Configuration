import numpy as np
def selection(fitnesses):
    num_total_cases = len(fitnesses[0])
    pop_size = len(fitnesses)
    epsilon = 0.01  # Relaxation parameter

    # Shuffle test cases
    test_case_order = np.random.permutation(num_total_cases)

    # Initialize candidate pool
    candidates = list(range(pop_size))

    for case in test_case_order:
        # Find minimum error for the current test case among remaining candidates
        min_error = min(fitnesses[i][case] for i in candidates)
        threshold = min_error + epsilon

        # Filter candidates based on relaxed pass condition
        candidates = [i for i in candidates if fitnesses[i][case] <= threshold]

        # If only one candidate remains, return it
        if len(candidates) == 1:
            return candidates[0]

    # If multiple candidates remain, select one randomly
    return np.random.choice(candidates)