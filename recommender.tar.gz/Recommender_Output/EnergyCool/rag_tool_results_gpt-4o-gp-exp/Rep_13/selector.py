import numpy as np

def selection(fitnesses):
    num_total_cases = len(fitnesses[0])
    pop_size = len(fitnesses)
    epsilon = 0.01  # Small threshold for ε-lexicase selection

    # Shuffle test cases
    test_case_indices = np.arange(num_total_cases)
    np.random.shuffle(test_case_indices)

    # Initialize candidate pool with all individuals
    candidates = np.arange(pop_size)

    for case in test_case_indices:
        if len(candidates) == 1:
            break

        # Extract errors for the current test case
        errors = np.array([fitnesses[i][case] for i in candidates])
        min_error = np.min(errors)

        # Apply ε threshold
        candidates = candidates[errors <= min_error + epsilon]

    # Return the selected parent
    return candidates[0] if len(candidates) > 0 else np.random.randint(pop_size)