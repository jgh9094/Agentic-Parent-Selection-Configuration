import numpy as np
def selection(fitnesses):
    num_total_cases = len(fitnesses[0])
    pop_size = len(fitnesses)
    epsilon = 0.1  # Define epsilon threshold

    candidates = list(range(pop_size))
    for case_index in range(num_total_cases):
        case_errors = [fitnesses[i][case_index] for i in candidates]
        min_error = min(case_errors)
        threshold = min_error + epsilon
        candidates = [candidates[i] for i in range(len(candidates)) if case_errors[i] <= threshold]
        if len(candidates) == 1:
            break

    return candidates[0]