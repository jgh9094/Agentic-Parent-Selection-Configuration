import numpy as np
def selection(fitnesses):
    num_total_cases = len(fitnesses[0])
    pop_size = len(fitnesses)
    epsilon = 0.1  # Threshold for ε-lexicase selection

    # Shuffle the test cases
    test_case_order = np.random.permutation(num_total_cases)

    # Initialize candidate pool
    candidates = list(range(pop_size))

    for case in test_case_order:
        if len(candidates) == 1:
            break

        # Calculate errors for the current test case
        errors = np.array([fitnesses[i][case] for i in candidates])

        # Determine the threshold for selection
        min_error = np.min(errors)
        threshold = min_error + epsilon

        # Filter candidates based on threshold
        candidates = [candidates[i] for i in range(len(candidates)) if errors[i] <= threshold]

    # Return the selected parent
    return candidates[0]