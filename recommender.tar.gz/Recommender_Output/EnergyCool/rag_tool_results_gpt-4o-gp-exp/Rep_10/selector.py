import numpy as np
def selection(fitnesses):
    num_total_cases = len(fitnesses[0])
    pop_size = len(fitnesses)
    epsilon = np.random.uniform(0, 1, num_total_cases)
    candidates = list(range(pop_size))
    for case_index in range(num_total_cases):
        min_error = min([fitnesses[i][case_index] for i in candidates])
        candidates = [i for i in candidates if fitnesses[i][case_index] <= min_error + epsilon[case_index]]
        if len(candidates) == 1:
            break
    return candidates[0] if candidates else np.random.randint(0, pop_size)