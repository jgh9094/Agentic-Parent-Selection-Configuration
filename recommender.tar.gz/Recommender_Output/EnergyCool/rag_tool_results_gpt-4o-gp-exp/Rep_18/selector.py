import numpy as np

def selection(fitnesses):
    num_total_cases = len(fitnesses[0])
    pop_size = len(fitnesses)

    epsilon = 0.1  # Relaxation parameter
    case_indices = np.random.permutation(num_total_cases)

    remaining_indices = list(range(pop_size))

    for case in case_indices:
        errors = np.array([fitnesses[i][case] for i in remaining_indices])
        min_error = np.min(errors)
        threshold = min_error + epsilon

        remaining_indices = [i for i in remaining_indices if fitnesses[i][case] <= threshold]

        if len(remaining_indices) == 1:
            return remaining_indices[0]

    return np.random.choice(remaining_indices)