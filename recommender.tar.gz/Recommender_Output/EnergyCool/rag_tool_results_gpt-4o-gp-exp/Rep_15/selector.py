import numpy as np
def selection(fitnesses):
    num_total_cases = len(fitnesses[0])
    pop_size = len(fitnesses)
    epsilon = 0.1  # Define a small epsilon value for relaxation

    # Shuffle the order of test cases
    test_case_order = np.random.permutation(num_total_cases)

    # Initialize the pool of candidates
    candidates = list(range(pop_size))

    for case in test_case_order:
        # Calculate the minimum error for the current test case
        min_error = min(fitnesses[i][case] for i in candidates)

        # Filter candidates based on ε-relaxed condition
        candidates = [i for i in candidates if fitnesses[i][case] <= min_error + epsilon]

        # If only one candidate remains, return it
        if len(candidates) == 1:
            return candidates[0]

    # If multiple candidates remain, return one randomly
    return np.random.choice(candidates)