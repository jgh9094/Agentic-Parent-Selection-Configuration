import numpy as np
def selection(fitnesses):
    num_total_cases = len(fitnesses[0])
    pop_size = len(fitnesses)
    epsilon = 0.1  # Define epsilon threshold

    # Randomize the order of test cases
    test_case_order = np.random.permutation(num_total_cases)

    # Initialize candidate pool with all individuals
    candidates = list(range(pop_size))

    for test_case in test_case_order:
        if len(candidates) == 1:
            break

        # Calculate errors for the current test case
        errors = [fitnesses[ind][test_case] for ind in candidates]

        # Determine the epsilon threshold for this test case
        min_error = min(errors)
        threshold = min_error + epsilon

        # Filter candidates based on epsilon threshold
        candidates = [candidates[i] for i in range(len(candidates)) if errors[i] <= threshold]

    # Return the selected parent
    return candidates[0] if candidates else np.random.randint(pop_size)