import numpy as np

def selection(fitnesses):
    num_total_cases = len(fitnesses[0])
    pop_size = len(fitnesses)

    epsilon = 0.01  # Small tolerance for error comparison
    candidates = list(range(pop_size))

    for case_index in range(num_total_cases):
        case_errors = [fitnesses[i][case_index] for i in candidates]
        min_error = min(case_errors)

        # Filter candidates based on ε condition
        candidates = [candidates[i] for i in range(len(candidates)) if case_errors[i] <= min_error + epsilon]

        # If only one candidate remains, return it
        if len(candidates) == 1:
            return candidates[0]

    # Return a random candidate if multiple remain
    return np.random.choice(candidates)