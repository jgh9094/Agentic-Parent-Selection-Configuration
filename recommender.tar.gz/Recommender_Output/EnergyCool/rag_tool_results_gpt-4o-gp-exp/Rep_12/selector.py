import numpy as np
def selection(fitnesses):
    num_total_cases = len(fitnesses[0])
    pop_size = len(fitnesses)
    epsilon = 0.01  # Small threshold to relax strict pass conditions

    remaining_indices = list(range(pop_size))
    for case_index in range(num_total_cases):
        case_errors = [fitnesses[i][case_index] for i in remaining_indices]
        min_error = min(case_errors)
        threshold = min_error + epsilon
        remaining_indices = [remaining_indices[i] for i in range(len(remaining_indices)) if case_errors[i] <= threshold]
        if len(remaining_indices) == 1:
            return remaining_indices[0]

    return np.random.choice(remaining_indices)