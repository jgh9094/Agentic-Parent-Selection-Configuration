import numpy as np
def selection(fitnesses):
    num_total_cases = len(fitnesses[0])
    pop_size = len(fitnesses)
    epsilon = np.random.uniform(0, 0.1, num_total_cases)
    indices = np.arange(pop_size)
    np.random.shuffle(indices)
    for case_index in indices:
        best_error = min(fitness[case_index] for fitness in fitnesses)
        candidates = [i for i in indices if fitnesses[i][case_index] <= best_error + epsilon[case_index]]
        indices = candidates
        if len(indices) == 1:
            return indices[0]
    return indices[0]