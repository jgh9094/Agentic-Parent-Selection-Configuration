import numpy as np

def selection(fitnesses):
    num_total_cases = len(fitnesses[0])
    pop_size = len(fitnesses)
    epsilon = 1e-8
    # Down-sampling: randomly sample a subset of cases
    sample_size = max(1, int(0.5 * num_total_cases))  # 50% down-sampling
    cases = np.random.choice(num_total_cases, sample_size, replace=False)
    candidates = np.arange(pop_size)
    np.random.shuffle(cases)
    for case in cases:
        case_errors = np.array([fitnesses[i][case] for i in candidates])
        min_error = np.min(case_errors)
        threshold = min_error + epsilon
        candidates = candidates[case_errors <= threshold]
        if len(candidates) == 1:
            return candidates[0]
    return np.random.choice(candidates)