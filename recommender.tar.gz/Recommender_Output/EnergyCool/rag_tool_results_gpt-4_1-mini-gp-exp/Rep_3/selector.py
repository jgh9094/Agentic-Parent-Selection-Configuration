import numpy as np

def selection(fitnesses):
    num_total_cases = len(fitnesses[0])
    pop_size = len(fitnesses)
    epsilon = 0.1  # epsilon threshold for relaxed pass condition

    # Indices of candidates still in the selection pool
    candidates = list(range(pop_size))
    # Randomly shuffle the order of test cases
    cases = np.random.permutation(num_total_cases)

    for case in cases:
        # Find the best error on this case among candidates
        case_errors = [fitnesses[i][case] for i in candidates]
        best_error = min(case_errors)
        # Filter candidates who are within epsilon of the best error
        candidates = [candidates[i] for i, err in enumerate(case_errors) if err <= best_error + epsilon]
        if len(candidates) == 1:
            return candidates[0]
    # If multiple candidates remain, select one at random
    return np.random.choice(candidates)