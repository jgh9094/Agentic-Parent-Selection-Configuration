import numpy as np

def selection(fitnesses):
    num_total_cases = len(fitnesses[0])
    pop_size = len(fitnesses)
    # Convert fitnesses to numpy array for efficient computation
    fitness_array = np.array(fitnesses)
    # Calculate epsilon as median absolute deviation for each case
    abs_deviation = np.abs(fitness_array - np.median(fitness_array, axis=0))
    epsilon = np.median(abs_deviation, axis=0)
    # Start with all individuals as candidates
    candidates = np.arange(pop_size)
    # Randomly shuffle the order of test cases
    cases_order = np.random.permutation(num_total_cases)
    for case in cases_order:
        if len(candidates) == 1:
            break
        # Find best error on this case among candidates
        best_error = np.min(fitness_array[candidates, case])
        # Select candidates within epsilon of best error
        pass_threshold = best_error + epsilon[case]
        candidates = candidates[fitness_array[candidates, case] <= pass_threshold]
    # If multiple candidates remain, select one at random
    if len(candidates) > 1:
        return np.random.choice(candidates)
    else:
        return candidates[0]