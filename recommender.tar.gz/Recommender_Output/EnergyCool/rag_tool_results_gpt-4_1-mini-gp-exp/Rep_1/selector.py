import numpy as np

def selection(fitnesses):
    num_total_cases = len(fitnesses[0])
    pop_size = len(fitnesses)
    # Convert fitnesses to numpy array for vectorized operations
    fitness_array = np.array(fitnesses)
    # Calculate epsilon per case as median absolute deviation
    errors = fitness_array
    best_errors = np.min(errors, axis=0)
    abs_devs = np.abs(errors - best_errors)
    epsilon = np.median(abs_devs, axis=0)
    # Initialize candidate indices as all individuals
    candidates = np.arange(pop_size)
    # Randomly shuffle the order of cases
    cases_order = np.random.permutation(num_total_cases)
    for case in cases_order:
        # Filter candidates that are within epsilon of best error on this case
        case_errors = errors[candidates, case]
        best_case_error = np.min(case_errors)
        threshold = best_case_error + epsilon[case]
        candidates = candidates[case_errors <= threshold]
        if len(candidates) == 1:
            return candidates[0]
    # If multiple candidates remain, pick one at random
    return np.random.choice(candidates)