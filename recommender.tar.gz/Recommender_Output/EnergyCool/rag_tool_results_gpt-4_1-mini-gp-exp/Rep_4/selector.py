import numpy as np

def selection(fitnesses):
    num_total_cases = len(fitnesses[0])
    pop_size = len(fitnesses)
    # Convert fitnesses to numpy array for easier manipulation
    fitness_array = np.array(fitnesses)
    # Initialize candidate indices to all individuals
    candidates = np.arange(pop_size)
    # Randomly shuffle the order of test cases
    cases_order = np.random.permutation(num_total_cases)
    # Threshold U for n-plexicase (set to 1.0 as a reasonable default)
    U = 1.0
    for case in cases_order:
        if len(candidates) == 1:
            break
        # Find the minimum error on this case among candidates
        min_error = np.min(fitness_array[candidates, case])
        # Select candidates with error within U of the minimum error
        candidates = candidates[fitness_array[candidates, case] <= min_error + U]
    # If multiple candidates remain, select one at random
    if len(candidates) > 1:
        return np.random.choice(candidates)
    else:
        return candidates[0]