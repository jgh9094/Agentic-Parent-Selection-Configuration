import numpy as np

def selection(fitnesses):
    num_total_cases = len(fitnesses[0])
    pop_size = len(fitnesses)
    # Convert errors to numpy array for efficient computation
    errors = np.array(fitnesses)
    # Calculate epsilon threshold per test case as median absolute deviation
    medians = np.median(errors, axis=0)
    abs_devs = np.abs(errors - medians)
    epsilons = np.median(abs_devs, axis=0)
    # Initialize candidate pool as all individuals
    candidates = np.arange(pop_size)
    # Randomly shuffle order of test cases
    case_order = np.random.permutation(num_total_cases)
    for case in case_order:
        if len(candidates) == 1:
            break
        case_errors = errors[candidates, case]
        best_error = np.min(case_errors)
        threshold = best_error + epsilons[case]
        # Filter candidates that pass the epsilon threshold
        candidates = candidates[case_errors <= threshold]
    # If multiple candidates remain, select one at random
    if len(candidates) > 1:
        return np.random.choice(candidates)
    else:
        return candidates[0]