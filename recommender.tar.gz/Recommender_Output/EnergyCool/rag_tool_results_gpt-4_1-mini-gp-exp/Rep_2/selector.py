import numpy as np

def selection(fitnesses):
    num_total_cases = len(fitnesses[0])
    pop_size = len(fitnesses)
    
    # Convert errors to numpy array for efficient processing
    errors = np.array(fitnesses)
    
    # Calculate epsilon threshold for each case as median absolute deviation
    medians = np.median(errors, axis=0)
    abs_devs = np.abs(errors - medians)
    epsilons = np.median(abs_devs, axis=0)
    
    # Indices of candidates initially all individuals
    candidates = np.arange(pop_size)
    
    # Random order of cases
    case_order = np.random.permutation(num_total_cases)
    
    for case in case_order:
        if len(candidates) == 1:
            break
        # Best error on this case among candidates
        best_error = np.min(errors[candidates, case])
        # Select candidates within epsilon of best error
        pass_threshold = best_error + epsilons[case]
        candidates = candidates[errors[candidates, case] <= pass_threshold]
        if len(candidates) == 0:
            # If no candidates pass, revert to previous candidates
            candidates = np.arange(pop_size)
            break
    
    # If multiple candidates remain, select one at random
    selected = np.random.choice(candidates)
    return int(selected)