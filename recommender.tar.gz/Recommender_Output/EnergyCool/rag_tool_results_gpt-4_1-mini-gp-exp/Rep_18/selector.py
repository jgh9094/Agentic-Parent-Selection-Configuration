import numpy as np

def selection(fitnesses):
    num_total_cases = len(fitnesses[0])
    pop_size = len(fitnesses)
    
    # Convert fitnesses to numpy array for efficient operations
    errors = np.array(fitnesses)
    
    # Define epsilon as a fraction of the median error per case
    median_errors = np.median(errors, axis=0)
    epsilon = 0.1 * median_errors
    
    # Start with all individuals as candidates
    candidates = np.arange(pop_size)
    
    # Randomly shuffle the order of test cases
    cases_order = np.random.permutation(num_total_cases)
    
    for case in cases_order:
        if len(candidates) == 1:
            break
        # Find best error among candidates for this case
        best_error = np.min(errors[candidates, case])
        # Select candidates within epsilon of best error
        threshold = best_error + epsilon[case]
        candidates = candidates[errors[candidates, case] <= threshold]
    
    # If multiple candidates remain, select one at random
    if len(candidates) > 1:
        selected = np.random.choice(candidates)
    else:
        selected = candidates[0]
    
    return int(selected)