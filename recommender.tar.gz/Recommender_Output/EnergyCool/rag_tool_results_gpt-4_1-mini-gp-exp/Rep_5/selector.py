import numpy as np

def selection(fitnesses):
    num_total_cases = len(fitnesses[0])
    pop_size = len(fitnesses)
    epsilon = 1e-8  # small epsilon to allow near-best performance
    # Random down-sampling of cases (e.g., 50% of cases)
    sample_size = max(1, num_total_cases // 2)
    cases = np.random.choice(num_total_cases, sample_size, replace=False)
    candidates = list(range(pop_size))
    for case in cases:
        errors = np.array([fitnesses[i][case] for i in candidates])
        min_error = errors.min()
        threshold = min_error + epsilon
        candidates = [candidates[i] for i, e in enumerate(errors) if e <= threshold]
        if len(candidates) == 1:
            return candidates[0]
    # If multiple candidates remain, select one at random
    return np.random.choice(candidates)