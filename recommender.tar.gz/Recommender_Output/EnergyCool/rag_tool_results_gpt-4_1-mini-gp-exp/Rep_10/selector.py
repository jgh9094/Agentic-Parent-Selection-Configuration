def selection(fitnesses):
    import numpy as np
    num_total_cases = len(fitnesses[0])
    pop_size = len(fitnesses)
    errors = np.array(fitnesses)
    candidates = np.arange(pop_size)
    cases = np.random.permutation(num_total_cases)
    for case in cases:
        case_errors = errors[candidates, case]
        best_error = np.min(case_errors)
        epsilon = 1e-8 + 0.1 * np.std(errors[:, case])
        pass_mask = case_errors <= best_error + epsilon
        candidates = candidates[pass_mask]
        if len(candidates) == 1:
            return candidates[0]
    return np.random.choice(candidates)