import numpy as np

def selection(fitnesses):
    num_total_cases = len(fitnesses[0])
    pop_size = len(fitnesses)
    # Convert errors to numpy array for vectorized operations
    errors = np.array(fitnesses)
    # Calculate probabilistic lexicase selection
    # Step 1: Randomize order of test cases
    cases_order = np.random.permutation(num_total_cases)
    candidates = np.arange(pop_size)
    for case in cases_order:
        # Find minimum error on this case among candidates
        case_errors = errors[candidates, case]
        min_error = np.min(case_errors)
        # Filter candidates that are within a threshold of min_error
        # Use a threshold to allow probabilistic selection (U parameter)
        threshold = min_error + 1e-8  # very small tolerance
        candidates = candidates[case_errors <= threshold]
        if len(candidates) == 1:
            return candidates[0]
    # If multiple candidates remain, select one randomly
    return np.random.choice(candidates)