import numpy as np

def selection(fitnesses):
    num_total_cases = len(fitnesses[0])
    pop_size = len(fitnesses)
    errors = np.array(fitnesses)  # shape (pop_size, num_total_cases)
    # Calculate epsilon as median absolute deviation of errors across population for each case
    median_errors = np.median(errors, axis=0)
    abs_deviation = np.abs(errors - median_errors)
    epsilon = np.median(abs_deviation, axis=0)
    # Start with all individuals as candidates
    candidates = np.arange(pop_size)
    # Randomly shuffle the order of test cases
    case_order = np.random.permutation(num_total_cases)
    for case in case_order:
        if len(candidates) == 1:
            break
        case_errors = errors[candidates, case]
        best_error = np.min(case_errors)
        # Select candidates within epsilon of best error
        pass_threshold = best_error + epsilon[case]
        candidates = candidates[case_errors <= pass_threshold]
    # If multiple candidates remain, select one at random
    if len(candidates) == 0:
        # fallback: select random individual
        return np.random.randint(pop_size)
    elif len(candidates) == 1:
        return candidates[0]
    else:
        return np.random.choice(candidates)