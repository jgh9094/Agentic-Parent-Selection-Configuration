import numpy as np
def selection(fitnesses):
    num_total_cases = len(fitnesses[0])
    pop_size = len(fitnesses)
    tournament_size = 7
    selected_indices = np.random.choice(pop_size, tournament_size, replace=False)
    best_index = selected_indices[0]
    best_fitness = np.mean(fitnesses[best_index])
    for idx in selected_indices[1:]:
        current_fitness = np.mean(fitnesses[idx])
        if current_fitness < best_fitness:
            best_fitness = current_fitness
            best_index = idx
    return best_index