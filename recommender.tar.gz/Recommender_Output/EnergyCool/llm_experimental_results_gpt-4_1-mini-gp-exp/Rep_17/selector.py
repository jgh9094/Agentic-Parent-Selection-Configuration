import numpy as np

def selection(fitnesses):
    num_total_cases = len(fitnesses[0])
    pop_size = len(fitnesses)
    tournament_size = 7
    selected_indices = np.random.choice(pop_size, tournament_size, replace=False)
    # Compute mean error per individual in tournament
    mean_errors = [np.mean(fitnesses[i]) for i in selected_indices]
    # Select individual with minimum mean error
    winner_index = selected_indices[np.argmin(mean_errors)]
    return winner_index