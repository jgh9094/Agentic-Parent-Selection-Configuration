import numpy as np

def selection(fitnesses):
    num_total_cases = len(fitnesses[0])
    pop_size = len(fitnesses)
    tournament_size = 7

    # Aggregate errors per individual by mean squared error
    aggregated_fitness = np.array([np.mean(ind_errors) for ind_errors in fitnesses])

    # Randomly select tournament_size individuals
    competitors = np.random.choice(pop_size, tournament_size, replace=False)

    # Select the individual with minimum aggregated fitness (error)
    best = competitors[0]
    best_fitness = aggregated_fitness[best]
    for c in competitors[1:]:
        if aggregated_fitness[c] < best_fitness:
            best = c
            best_fitness = aggregated_fitness[c]

    return best