def selection(fitnesses):
    import numpy as np
    num_total_cases = len(fitnesses[0])
    pop_size = len(fitnesses)
    fitness_arr = np.array(fitnesses)
    remaining = np.arange(pop_size)
    order = np.random.permutation(num_total_cases)
    epsilon_factor = 0.1
    for idx in order:
        errors = fitness_arr[remaining, idx]
        best = errors.min()
        worst = errors.max()
        epsilon = epsilon_factor * (worst - best)
        mask = errors <= best + epsilon
        remaining = remaining[mask]
        if remaining.size == 1:
            return int(remaining[0])
    return int(np.random.choice(remaining))