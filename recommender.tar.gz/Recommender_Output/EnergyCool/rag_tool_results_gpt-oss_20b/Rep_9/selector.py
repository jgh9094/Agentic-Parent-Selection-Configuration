import numpy as np

def selection(fitnesses):
    num_total_cases = len(fitnesses[0])
    pop_size = len(fitnesses)
    indices = np.arange(pop_size)
    case_indices = np.arange(num_total_cases)
    np.random.shuffle(case_indices)
    epsilon = 1e-6
    for case in case_indices:
        best = np.min([fitnesses[i][case] for i in indices])
        mask = np.array([fitnesses[i][case] <= best + epsilon for i in indices])
        indices = indices[mask]
        if len(indices) == 1:
            break
    if len(indices) == 0:
        return np.random.randint(pop_size)
    return int(np.random.choice(indices))