import numpy as np

def selection(fitnesses):
    num_total_cases = len(fitnesses[0])
    pop_size = len(fitnesses)
    errors = np.array(fitnesses)
    rng = np.random.default_rng()
    candidates = np.arange(pop_size)
    case_order = rng.permutation(num_total_cases)
    for case in case_order:
        case_errors = errors[candidates, case]
        best = case_errors.min()
        eps = 0.1 * (case_errors.max() - case_errors.min())
        mask = case_errors <= best + eps
        candidates = candidates[mask]
        if candidates.size == 1:
            return int(candidates[0])
        if candidates.size == 0:
            candidates = np.arange(pop_size)
    total_errors = errors[candidates].sum(axis=1)
    best_idx = candidates[np.argmin(total_errors)]
    return int(best_idx)