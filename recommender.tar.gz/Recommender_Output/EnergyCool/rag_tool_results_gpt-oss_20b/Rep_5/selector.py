import numpy as np

def selection(fitnesses):
    num_total_cases = len(fitnesses[0])
    pop_size = len(fitnesses)
    candidates = np.arange(pop_size)
    case_indices = np.arange(num_total_cases)
    np.random.shuffle(case_indices)
    epsilon_factor = 0.01
    for case in case_indices:
        errors = np.array([fitnesses[i][case] for i in candidates])
        min_err = errors.min()
        max_err = errors.max()
        eps = (max_err - min_err) * epsilon_factor
        mask = errors <= min_err + eps
        candidates = candidates[mask]
        if len(candidates) == 1:
            return int(candidates[0])
    return int(np.random.choice(candidates))