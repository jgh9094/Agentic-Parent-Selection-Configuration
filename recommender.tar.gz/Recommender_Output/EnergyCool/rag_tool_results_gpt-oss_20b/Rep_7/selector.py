import numpy as np

def selection(fitnesses):
    fitnesses = np.array(fitnesses)
    pop_size, num_cases = fitnesses.shape
    case_order = np.arange(num_cases)
    np.random.shuffle(case_order)
    candidates = np.arange(pop_size)
    for j in case_order:
        errors = fitnesses[candidates, j]
        best = errors.min()
        eps = 0.1 * (errors.max() - best)
        mask = errors <= best + eps
        candidates = candidates[mask]
        if candidates.size == 1:
            return int(candidates[0])
    return int(np.random.choice(candidates))