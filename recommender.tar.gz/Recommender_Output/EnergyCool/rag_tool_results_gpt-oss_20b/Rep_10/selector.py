import numpy as np

def selection(fitnesses):
    num_total_cases = len(fitnesses[0])
    pop_size = len(fitnesses)
    remaining = np.arange(pop_size)
    case_order = np.random.permutation(num_total_cases)
    for c in case_order:
        errors = np.array([fitnesses[i][c] for i in remaining])
        min_err = errors.min()
        mask = errors == min_err
        remaining = remaining[mask]
        if remaining.size == 1:
            break
    if remaining.size > 1:
        remaining = np.random.choice(remaining, size=1)
    return int(remaining[0])