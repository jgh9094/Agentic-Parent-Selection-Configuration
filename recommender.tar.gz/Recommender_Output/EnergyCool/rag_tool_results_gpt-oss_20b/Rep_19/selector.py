import numpy as np

def selection(fitnesses):
    num_total_cases = len(fitnesses[0])
    pop_size = len(fitnesses)
    remaining = np.arange(pop_size)
    case_order = np.random.permutation(num_total_cases)
    for case in case_order:
        errors = np.array([fitnesses[i][case] for i in remaining])
        best_error = errors.min()
        remaining = remaining[errors == best_error]
        if remaining.size == 1:
            break
    if remaining.size > 1:
        return int(np.random.choice(remaining))
    return int(remaining[0])