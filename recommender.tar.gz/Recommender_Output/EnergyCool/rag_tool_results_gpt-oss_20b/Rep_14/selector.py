import numpy as np

def selection(fitnesses):
    num_total_cases = len(fitnesses[0])
    pop_size = len(fitnesses)
    indices = np.arange(pop_size)
    test_cases = np.arange(num_total_cases)
    np.random.shuffle(test_cases)
    for tc in test_cases:
        errors = np.array([fitnesses[i][tc] for i in indices])
        min_err = errors.min()
        mask = errors == min_err
        indices = indices[mask]
        if len(indices) == 1:
            return int(indices[0])
    return int(np.random.choice(indices))