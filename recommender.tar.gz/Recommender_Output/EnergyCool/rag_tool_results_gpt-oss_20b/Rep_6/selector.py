def selection(fitnesses):
    import numpy as np
    num_total_cases = len(fitnesses[0])
    pop_size = len(fitnesses)
    total_errors = np.array([sum(errors) for errors in fitnesses])
    idx1 = np.random.randint(pop_size)
    idx2 = np.random.randint(pop_size)
    return idx1 if total_errors[idx1] <= total_errors[idx2] else idx2