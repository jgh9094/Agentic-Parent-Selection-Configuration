import numpy as np

def selection(fitnesses):
    num_total_cases = len(fitnesses[0])
    pop_size = len(fitnesses)
    errors = np.array(fitnesses)
    case_order = np.random.permutation(num_total_cases)
    mask = np.arange(pop_size)
    for c in case_order:
        min_err = errors[mask, c].min()
        mask = mask[errors[mask, c] == min_err]
        if mask.size == 1:
            break
    if mask.size > 1:
        return int(np.random.choice(mask))
    return int(mask[0])