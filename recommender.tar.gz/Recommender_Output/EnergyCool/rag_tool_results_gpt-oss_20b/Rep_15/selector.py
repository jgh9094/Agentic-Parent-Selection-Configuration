import numpy as np

def selection(fitnesses):
    num_total_cases = len(fitnesses[0])
    pop_size = len(fitnesses)
    total_errors = np.sum(fitnesses, axis=1)
    fitness = 1.0 / (1.0 + total_errors)
    idx = np.random.choice(pop_size, size=2, replace=False)
    if fitness[idx[0]] > fitness[idx[1]]:
        return int(idx[0])
    else:
        return int(idx[1])