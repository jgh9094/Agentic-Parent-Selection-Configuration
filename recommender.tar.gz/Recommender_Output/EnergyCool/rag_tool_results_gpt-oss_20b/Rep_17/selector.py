import numpy as np

def selection(fitnesses):
    num_total_cases = len(fitnesses[0])
    pop_size = len(fitnesses)
    k = int(np.sqrt(num_total_cases))
    if k < 1:
        k = 1
    rng = np.random.default_rng()
    case_indices = rng.choice(num_total_cases, size=k, replace=False)
    rng.shuffle(case_indices)
    candidates = np.arange(pop_size)
    for case in case_indices:
        errors = np.array([fitnesses[i][case] for i in candidates])
        min_error = errors.min()
        mask = errors == min_error
        candidates = candidates[mask]
        if len(candidates) == 1:
            return int(candidates[0])
        if len(candidates) == 0:
            return int(rng.integers(pop_size))
    return int(rng.choice(candidates))