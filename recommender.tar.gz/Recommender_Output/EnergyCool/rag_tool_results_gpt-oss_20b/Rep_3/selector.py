def selection(fitnesses):
    import numpy as np
    pop_size = len(fitnesses)
    if pop_size == 0:
        return None
    if pop_size == 1:
        return 0
    # compute fitness: lower error -> higher fitness
    errors = np.array(fitnesses)
    total_errors = errors.sum(axis=1)
    fitness = 1.0 / (1.0 + total_errors)
    # tournament size 2
    idx1, idx2 = np.random.randint(0, pop_size, size=2)
    if fitness[idx1] >= fitness[idx2]:
        return int(idx1)
    else:
        return int(idx2)