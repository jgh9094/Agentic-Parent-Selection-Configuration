import numpy as np

def selection(fitnesses):
    num_total_cases = len(fitnesses[0])
    pop_size = len(fitnesses)
    errors = np.array(fitnesses)
    remaining = np.arange(pop_size)
    case_order = np.random.permutation(num_total_cases)
    epsilon = 1e-6
    for c in case_order:
        best = errors[remaining, c].min()
        mask = errors[remaining, c] <= best + epsilon
        remaining = remaining[mask]
        if remaining.size == 1:
            return int(remaining[0])
    return int(np.random.choice(remaining))