import numpy as np

def selection(fitnesses):
    fitnesses = np.array(fitnesses)
    pop_size, num_total_cases = fitnesses.shape
    indices = np.arange(pop_size)
    case_order = np.random.permutation(num_total_cases)
    candidates = indices
    epsilon = 1e-6
    for case in case_order:
        errors = fitnesses[candidates, case]
        min_error = errors.min()
        mask = errors <= min_error + epsilon
        candidates = candidates[mask]
        if candidates.size == 1:
            return int(candidates[0])
    return int(np.random.choice(candidates))