import numpy as np

def selection(fitnesses):
    num_total_cases = len(fitnesses[0])
    pop_size = len(fitnesses)
    errors = np.array([sum(f) for f in fitnesses])
    t = 2
    indices = np.random.choice(pop_size, size=t, replace=False)
    best = indices[np.argmin(errors[indices])]
    return int(best)