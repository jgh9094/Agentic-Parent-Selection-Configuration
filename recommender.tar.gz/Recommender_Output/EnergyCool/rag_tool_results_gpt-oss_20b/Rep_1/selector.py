import numpy as np

def selection(fitnesses):
    num_total_cases = len(fitnesses[0])
    pop_size = len(fitnesses)
    total_errors = np.sum(fitnesses, axis=1)
    i1, i2 = np.random.randint(0, pop_size, size=2)
    return i1 if total_errors[i1] <= total_errors[i2] else i2