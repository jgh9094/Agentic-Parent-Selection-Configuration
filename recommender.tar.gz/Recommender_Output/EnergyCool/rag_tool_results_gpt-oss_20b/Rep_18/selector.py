import numpy as np

def selection(fitnesses):
    fitnesses = np.array(fitnesses)
    pop_size, num_cases = fitnesses.shape
    epsilon = 1e-6 * np.mean(fitnesses)
    case_indices = np.arange(num_cases)
    np.random.shuffle(case_indices)
    candidates = np.arange(pop_size)
    for idx in case_indices:
        case_errors = fitnesses[candidates, idx]
        min_error = np.min(case_errors)
        mask = case_errors <= min_error + epsilon
        candidates = candidates[mask]
        if len(candidates) == 1:
            break
    if len(candidates) == 0:
        return np.random.randint(pop_size)
    return int(np.random.choice(candidates))