def selection(fitnesses):
    import numpy as np
    num_total_cases = len(fitnesses[0])
    pop_size = len(fitnesses)
    errors = np.array([sum(f) for f in fitnesses])
    tournament_size = 3
    indices = np.random.choice(pop_size, size=tournament_size, replace=False)
    best_idx = indices[np.argmin(errors[indices])]
    return int(best_idx)