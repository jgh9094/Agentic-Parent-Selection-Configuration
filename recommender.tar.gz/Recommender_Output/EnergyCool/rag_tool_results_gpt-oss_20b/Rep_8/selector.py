import numpy as np

def selection(fitnesses):
    num_total_cases = len(fitnesses[0])
    pop_size = len(fitnesses)
    errors = np.array(fitnesses)
    candidates = np.arange(pop_size)
    test_order = np.random.permutation(num_total_cases)
    for t in test_order:
        vals = errors[candidates, t]
        min_val = vals.min()
        mask = vals == min_val
        candidates = candidates[mask]
        if len(candidates) == 1:
            break
    idx = np.random.choice(candidates)
    return int(idx)