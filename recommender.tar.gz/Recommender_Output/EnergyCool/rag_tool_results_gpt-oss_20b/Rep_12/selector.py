import numpy as np

def selection(fitnesses):
    num_total_cases = len(fitnesses[0])
    pop_size = len(fitnesses)
    errors = np.array(fitnesses)
    indices = np.arange(pop_size)
    case_order = np.random.permutation(num_total_cases)
    for c in case_order:
        if len(indices) == 1:
            break
        case_errors = errors[indices, c]
        min_err = np.min(case_errors)
        max_err = np.max(case_errors)
        eps = 0.01 * (max_err - min_err)
        mask = case_errors <= min_err + eps
        indices = indices[mask]
    if len(indices) == 0:
        return np.random.randint(pop_size)
    return int(indices[0])