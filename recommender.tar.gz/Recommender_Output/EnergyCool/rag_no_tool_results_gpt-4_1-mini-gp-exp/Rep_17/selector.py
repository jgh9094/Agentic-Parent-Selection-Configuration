import numpy as np
def selection(fitnesses):
    num_total_cases = len(fitnesses[0])
    pop_size = len(fitnesses)
    tournament_size = 7
    candidates = np.random.choice(pop_size, tournament_size, replace=False)
    # Calculate mean fitness (error) for each candidate
    candidate_fitness = [np.mean(fitnesses[i]) for i in candidates]
    # Select the candidate with the lowest mean error
    winner_index = candidates[np.argmin(candidate_fitness)]
    return winner_index