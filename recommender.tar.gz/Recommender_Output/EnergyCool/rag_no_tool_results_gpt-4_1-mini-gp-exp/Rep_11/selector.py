import numpy as np

def selection(fitnesses):
    num_total_cases = len(fitnesses[0])
    pop_size = len(fitnesses)
    tournament_size = 7
    # Randomly select tournament_size individuals
    competitors = np.random.choice(pop_size, tournament_size, replace=False)
    # Calculate mean error per individual in tournament
    mean_errors = [np.mean(fitnesses[i]) for i in competitors]
    # Select individual with minimal mean error
    winner_index = competitors[np.argmin(mean_errors)]
    return winner_index