import numpy as np

def selection(fitnesses):
    num_total_cases = len(fitnesses[0])
    pop_size = len(fitnesses)
    tournament_size = 7
    # Randomly select tournament_size individuals
    competitors = np.random.choice(pop_size, tournament_size, replace=False)
    # Calculate total error (sum of errors) for each competitor
    total_errors = [np.sum(fitnesses[i]) for i in competitors]
    # Select the individual with minimum total error
    winner_index = competitors[np.argmin(total_errors)]
    return winner_index