import numpy as np

def selection(fitnesses):
    num_total_cases = len(fitnesses[0])
    pop_size = len(fitnesses)
    tournament_size = 7
    selected_indices = np.random.choice(pop_size, tournament_size, replace=False)
    # Compute total error (sum of squared errors) for each selected individual
    total_errors = [np.sum(fitnesses[i]) for i in selected_indices]
    # Since errors are to be minimized, select the individual with the smallest total error
    winner_index = selected_indices[np.argmin(total_errors)]
    return winner_index