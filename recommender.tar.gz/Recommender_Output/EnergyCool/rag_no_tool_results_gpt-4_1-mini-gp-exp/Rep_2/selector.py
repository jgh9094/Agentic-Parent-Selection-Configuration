import numpy as np

def selection(fitnesses):
    num_total_cases = len(fitnesses[0])
    pop_size = len(fitnesses)
    tournament_size = 7
    participants = np.random.choice(pop_size, tournament_size, replace=False)
    avg_errors = [np.mean(fitnesses[i]) for i in participants]
    winner_index = participants[np.argmin(avg_errors)]
    return int(winner_index)