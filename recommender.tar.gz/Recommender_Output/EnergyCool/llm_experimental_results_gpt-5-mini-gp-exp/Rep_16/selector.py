def selection(fitnesses):
    import numpy as np

    # Number of test cases and population size (as required)
    num_total_cases = len(fitnesses[0])
    pop_size = len(fitnesses)

    # Convert to numpy array of shape (pop_size, num_total_cases)
    arr = np.array(fitnesses, dtype=float)

    # Initialize candidate set (all individuals) and a random order of cases
    candidates = np.arange(pop_size)
    cases = np.arange(num_total_cases)
    np.random.shuffle(cases)

    # Epsilon-lexicase filtering across cases in random order
    for c in cases:
        if candidates.size <= 1:
            break
        errs = arr[candidates, c]
        best = np.min(errs)
        # epsilon as median absolute deviation from best; fallback to tiny value
        eps = np.median(np.abs(errs - best))
        if eps == 0 or not np.isfinite(eps):
            eps = 1e-8
        mask = errs <= (best + eps)
        candidates = candidates[mask]

    # If multiple survivors remain, pick uniformly at random
    if candidates.size == 0:
        # Fallback: choose a random individual from the whole population
        return int(np.random.randint(0, pop_size))
    return int(np.random.choice(candidates))