def selection(fitnesses):
    import numpy as np

    pop_size = len(fitnesses)
    if pop_size == 0:
        raise ValueError("Empty population")
    num_total_cases = len(fitnesses[0])

    arr = np.asarray(fitnesses, dtype=float)
    # Ensure shape (pop_size, num_total_cases)
    if arr.shape != (pop_size, num_total_cases):
        arr = np.array([np.array(f, dtype=float) for f in fitnesses])

    rng = np.random.default_rng()
    cases = np.arange(num_total_cases)
    rng.shuffle(cases)

    candidates = np.arange(pop_size)

    for c in cases:
        if candidates.size <= 1:
            break
        errors_all = arr[:, c]
        errors_candidates = errors_all[candidates]
        best = errors_candidates.min()
        # Compute epsilon robustly across the whole population for this case
        med = np.median(errors_all)
        eps = np.median(np.abs(errors_all - med))
        if eps <= 0:
            eps = 1e-8
        mask = errors_candidates <= (best + eps)
        candidates = candidates[mask]

    if candidates.size == 0:
        # Fallback: choose individual with lowest total error
        totals = arr.sum(axis=1)
        return int(np.argmin(totals))
    if candidates.size == 1:
        return int(candidates[0])
    # If multiple remain, select uniformly at random among them
    return int(rng.choice(candidates))