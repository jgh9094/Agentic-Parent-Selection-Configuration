import numpy as np

def selection(fitnesses):
    # number of test cases per individual
    num_total_cases = len(fitnesses[0])
    # population size
    pop_size = len(fitnesses)

    # convert to numpy array for vectorized computations
    arr = np.array(fitnesses, dtype=float)

    # tournament size (bounded by population)
    k = min(7, pop_size)

    # sample k distinct individuals for the tournament
    tournament_inds = np.random.choice(pop_size, size=k, replace=False)

    # primary criterion: total (sum) error across all cases (minimize)
    total_errors = arr[tournament_inds].sum(axis=1)
    min_total = np.min(total_errors)
    candidates = tournament_inds[total_errors == min_total]

    # if a single winner, return it
    if candidates.size == 1:
        return int(candidates[0])

    # tie-breaker 1: minimize the worst-case (max) per-case error
    max_errors = arr[candidates].max(axis=1)
    min_max = np.min(max_errors)
    candidates = candidates[max_errors == min_max]

    if candidates.size == 1:
        return int(candidates[0])

    # tie-breaker 2: minimize variance across cases (prefer consistent performers)
    var_errors = arr[candidates].var(axis=1)
    min_var = np.min(var_errors)
    candidates = candidates[var_errors == min_var]

    # final tie-breaker: random choice among remaining candidates
    return int(np.random.choice(candidates))