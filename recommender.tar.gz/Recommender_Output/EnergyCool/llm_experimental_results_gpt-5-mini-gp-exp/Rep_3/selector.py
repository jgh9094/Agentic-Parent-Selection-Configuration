def selection(fitnesses):
    import numpy as np

    # 1) Calculate num_total_cases as len(fitnesses[0]).
    num_total_cases = len(fitnesses[0])
    # 2) Calculate pop_size as len(fitnesses).
    pop_size = len(fitnesses)

    # Convert to numpy array for vectorized operations
    arr = np.asarray(fitnesses, dtype=float)  # shape: (pop_size, num_total_cases)

    # Initialize candidate set to all individuals
    candidates = np.arange(pop_size)

    # Randomize order of cases for lexicase filtering
    case_order = np.random.permutation(num_total_cases)

    for c in case_order:
        # Errors across the entire population for case c
        case_errors_all = arr[:, c]

        # Compute epsilon for this case as the median absolute deviation (MAD)
        med = np.median(case_errors_all)
        mad = np.median(np.abs(case_errors_all - med))
        eps = mad if mad > 0.0 else 1e-12

        # Among current candidates, find the minimum error on this case
        cand_errors = arr[candidates, c]
        min_err = np.min(cand_errors)

        # Filter candidates that are within min_err + eps
        mask = cand_errors <= (min_err + eps)
        new_candidates = candidates[mask]

        # If filtering yields no candidates (numerical edge), fall back to exact minima
        if new_candidates.size == 0:
            exact_mask = cand_errors == min_err
            new_candidates = candidates[exact_mask]
            if new_candidates.size == 0:
                # As a last resort, keep previous candidates
                new_candidates = candidates

        candidates = new_candidates

        # If only one candidate remains, select it
        if candidates.size == 1:
            return int(candidates[0])

    # If multiple candidates remain after all cases, break ties uniformly at random
    return int(np.random.choice(candidates))