def selection(fitnesses):
    import numpy as np
    # Required quantities
    num_total_cases = len(fitnesses[0])
    pop_size = len(fitnesses)

    # Convert to array: shape (pop_size, num_total_cases)
    arr = np.array(fitnesses, dtype=float)

    # Random order of cases for lexicase
    cases = np.random.permutation(num_total_cases)

    # Start with all individuals as candidates
    candidates = np.arange(pop_size)

    # Epsilon-lexicase filtering
    for case in cases:
        # Errors for all individuals on this case
        errors_all = arr[:, case]
        # Errors for current candidates
        errors = arr[candidates, case]

        # Best (minimum) error among candidates
        best = errors.min()

        # Compute epsilon for this case using median absolute deviation (MAD)
        med = np.median(errors_all)
        mad = np.median(np.abs(errors_all - med))
        eps = max(mad, 1e-8)

        # Retain candidates within best + eps
        survivors = candidates[errors <= best + eps]
        if survivors.size > 0:
            candidates = survivors

        # If only one candidate remains, return it
        if candidates.size == 1:
            return int(candidates[0])

    # If multiple candidates remain after all cases, pick one uniformly at random
    return int(np.random.choice(candidates))