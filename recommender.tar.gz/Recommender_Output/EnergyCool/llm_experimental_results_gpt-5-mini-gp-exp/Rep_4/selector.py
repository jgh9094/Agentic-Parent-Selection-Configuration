def selection(fitnesses):
    import numpy as np
    # Required variables
    num_total_cases = len(fitnesses[0])
    pop_size = len(fitnesses)

    # Convert to numpy array: shape (pop_size, num_total_cases)
    arr = np.asarray(fitnesses, dtype=float)

    # Compute epsilon per case using median absolute deviation (MAD)
    medians = np.median(arr, axis=0)
    mad = np.median(np.abs(arr - medians), axis=0)
    eps = np.maximum(mad, 1e-12)

    # Randomize case order for lexicase
    cases = np.arange(num_total_cases)
    np.random.shuffle(cases)

    # Start with all candidates
    candidates = np.arange(pop_size)

    # Progressive filtering by case
    for case in cases:
        if candidates.size <= 1:
            break
        errors = arr[candidates, case]
        best = errors.min()
        threshold = best + eps[case]
        keep_mask = errors <= threshold
        candidates = candidates[keep_mask]
        # If filtering removes all, reset to full population and stop
        if candidates.size == 0:
            candidates = np.arange(pop_size)
            break

    # Return a single index
    return int(np.random.choice(candidates))