def selection(fitnesses):
    import numpy as np
    # Required variables
    num_total_cases = len(fitnesses[0])
    pop_size = len(fitnesses)

    arr = np.asarray(fitnesses, dtype=float)
    rng = np.random.default_rng()

    cases = np.arange(num_total_cases)
    perm = rng.permutation(cases)

    candidates = np.arange(pop_size)
    for c in perm:
        errors = arr[:, c]
        # Robust epsilon: median absolute deviation (MAD)
        med = np.median(errors)
        mad = np.median(np.abs(errors - med))
        epsilon = max(1e-12, mad)

        cand_errors = errors[candidates]
        best = cand_errors.min()
        candidates = candidates[cand_errors <= best + epsilon]

        if candidates.size == 1:
            return int(candidates[0])

    # If multiple remain, pick one uniformly at random; if none (unlikely), pick any random individual
    if candidates.size == 0:
        return int(rng.integers(0, pop_size))
    return int(rng.choice(candidates))