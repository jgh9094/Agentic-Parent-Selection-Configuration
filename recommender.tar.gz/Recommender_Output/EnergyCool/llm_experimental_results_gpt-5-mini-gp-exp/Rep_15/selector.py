def selection(fitnesses):
    import numpy as np

    num_total_cases = len(fitnesses[0])
    pop_size = len(fitnesses)

    arr = np.asarray(fitnesses, dtype=float)
    rng = np.random.default_rng()

    cases = np.arange(num_total_cases)
    rng.shuffle(cases)

    candidates = np.arange(pop_size)

    for case in cases:
        errs = arr[candidates, case]
        min_err = errs.min()
        # adaptive epsilon: median absolute deviation from the minimum
        mad = np.median(np.abs(errs - min_err))
        eps = mad
        threshold = min_err + eps
        keep_mask = errs <= threshold
        candidates = candidates[keep_mask]
        if candidates.size == 1:
            return int(candidates[0])

    # if multiple remain, choose uniformly at random
    return int(rng.choice(candidates))