def selection(fitnesses):
    import numpy as np

    # Required summaries
    num_total_cases = len(fitnesses[0])
    pop_size = len(fitnesses)

    # Convert to numpy array: shape (pop_size, num_cases)
    arr = np.asarray(fitnesses, dtype=float)

    # Start with all individuals as candidates
    survivors = np.arange(pop_size)

    # Randomize order of cases for lexicase filtering
    case_order = np.random.permutation(num_total_cases)

    for case in case_order:
        if survivors.size <= 1:
            break
        # Errors for current survivors on this case
        case_errors = arr[survivors, case]
        best = np.min(case_errors)

        # Epsilon: robust scale estimator (median absolute deviation) with a tiny floor
        mad = np.median(np.abs(arr[:, case] - np.median(arr[:, case])))
        eps = max(1e-8, mad)

        # Keep survivors within best + eps
        keep_mask = case_errors <= (best + eps)
        survivors = survivors[keep_mask]

    # Fallbacks: if none remain, choose random; if multiple remain, choose uniformly
    if survivors.size == 0:
        return int(np.random.randint(0, pop_size))
    return int(np.random.choice(survivors))