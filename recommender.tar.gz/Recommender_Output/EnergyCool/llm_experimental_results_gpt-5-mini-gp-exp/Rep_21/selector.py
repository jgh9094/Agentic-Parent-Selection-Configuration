def selection(fitnesses):
    import numpy as np

    # (1) Number of test cases per individual
    num_total_cases = len(fitnesses[0])
    # (2) Population size
    pop_size = len(fitnesses)

    # Convert to numpy array for efficient slicing: shape (pop_size, num_total_cases)
    arr = np.asarray(fitnesses, dtype=float)

    # Candidate indices
    candidates = np.arange(pop_size)

    # Random order of cases for lexicase
    rng = np.random.default_rng()
    case_order = rng.permutation(num_total_cases)

    for c in case_order:
        # Case values for current candidates
        vals = arr[candidates, c]
        # Best (minimum) error on this case among candidates
        min_val = vals.min()
        # Small epsilon tolerance to account for numerical noise (relative + absolute)
        eps = 1e-12 + 1e-8 * (abs(min_val))
        # Keep candidates whose error is within min_val + eps
        keep_mask = vals <= (min_val + eps)
        candidates = candidates[keep_mask]
        # If one candidate remains, return it
        if candidates.size == 1:
            return int(candidates[0])

    # If multiple remain after all cases, choose uniformly at random among them
    return int(rng.choice(candidates))