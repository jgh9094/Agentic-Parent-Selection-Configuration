import numpy as np

def selection(fitnesses):
    num_total_cases = len(fitnesses[0]) if len(fitnesses) > 0 else 0
    pop_size = len(fitnesses)
    if pop_size == 0:
        raise ValueError("Population is empty")
    if num_total_cases == 0:
        return int(np.random.randint(0, pop_size))

    errors = np.array(fitnesses, dtype=float)
    # candidates: indices of individuals still in contention
    candidates = np.arange(pop_size)

    # randomize order of cases
    case_order = np.random.permutation(num_total_cases)

    # compute per-case epsilon using median absolute deviation (MAD)
    medians = np.median(errors, axis=0)
    mad = np.median(np.abs(errors - medians), axis=0)
    eps = np.maximum(mad, 1e-12)

    for c in case_order:
        if candidates.size <= 1:
            break
        vals = errors[candidates, c]
        best = np.min(vals)
        thresh = best + eps[c]
        keep_mask = vals <= thresh
        candidates = candidates[keep_mask]

    if candidates.size == 0:
        # fallback: pick individual with lowest mean error
        mean_err = errors.mean(axis=1)
        return int(np.argmin(mean_err))
    if candidates.size == 1:
        return int(candidates[0])
    # multiple survivors: choose uniformly at random among them
    return int(np.random.choice(candidates))