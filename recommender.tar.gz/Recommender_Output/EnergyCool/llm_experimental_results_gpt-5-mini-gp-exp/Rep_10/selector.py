def selection(fitnesses):
    import numpy as np
    # Number of test cases and population size (as required)
    num_total_cases = len(fitnesses[0])
    pop_size = len(fitnesses)

    # Convert to numpy array: shape (pop_size, num_total_cases)
    arr = np.array(fitnesses)

    # Start with all individuals as candidates
    candidates = np.arange(pop_size)

    # Randomize order of cases for lexicase filtering
    cases = np.random.permutation(num_total_cases)

    # Small tolerance to avoid floating-point equality issues
    tol = 1e-12

    for c in cases:
        errors = arr[candidates, c]
        min_err = errors.min()
        # Keep candidates whose error on this case is (near) minimal
        mask = errors <= (min_err + tol)
        candidates = candidates[mask]
        if candidates.size == 1:
            return int(candidates[0])

    # If multiple candidates remain, choose one at random
    if candidates.size == 0:
        return int(np.random.randint(0, pop_size))
    return int(np.random.choice(candidates))