import numpy as np

def selection(fitnesses):
    num_total_cases = len(fitnesses[0])
    pop_size = len(fitnesses)
    errors = np.asarray(fitnesses, dtype=float)
    if pop_size <= 1:
        return 0
    # compute per-case median absolute deviation (scaled) as epsilon
    med = np.median(errors, axis=0)
    mad = np.median(np.abs(errors - med), axis=0)
    eps = np.maximum(mad * 1.4826, 1e-12)
    candidates = np.arange(pop_size)
    rng = np.random.default_rng()
    case_order = rng.permutation(num_total_cases)
    for c in case_order:
        case_errs = errors[candidates, c]
        best = case_errs.min()
        thresh = best + eps[c]
        candidates = candidates[case_errs <= thresh]
        if candidates.size == 1:
            return int(candidates[0])
    return int(rng.choice(candidates))