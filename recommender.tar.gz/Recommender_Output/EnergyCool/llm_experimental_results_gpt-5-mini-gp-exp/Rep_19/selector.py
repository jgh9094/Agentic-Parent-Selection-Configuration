def selection(fitnesses):
    import numpy as np
    # (1) number of test cases per individual
    num_total_cases = len(fitnesses[0])
    # (2) population size
    pop_size = len(fitnesses)

    # Aggregate per-individual errors (lower is better). Use sum over cases.
    errors = np.array([np.sum(np.asarray(ind, dtype=float)) for ind in fitnesses])

    # Robustify: replace non-finite errors with a very large number
    large = np.finfo(float).max / 2.0
    errors = np.where(np.isfinite(errors), errors, large)

    # Tournament selection parameters
    k = 7
    if k > pop_size:
        k = max(2, pop_size)

    # Sample k distinct competitors and choose the one with minimum aggregated error
    competitors = np.random.choice(pop_size, size=k, replace=False)
    winner_idx = competitors[np.argmin(errors[competitors])]
    return int(winner_idx)