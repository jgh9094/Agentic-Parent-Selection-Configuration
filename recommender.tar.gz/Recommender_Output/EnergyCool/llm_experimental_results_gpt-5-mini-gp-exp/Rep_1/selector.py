def selection(fitnesses):
    import numpy as np

    # Calculate required sizes
    num_total_cases = len(fitnesses[0])
    pop_size = len(fitnesses)

    # Convert to numpy array for efficient indexing
    arr = np.array(fitnesses, dtype=float)  # shape: (pop_size, num_total_cases)

    # Start with all candidate indices
    candidates = np.arange(pop_size)

    # Random ordering of cases for lexicase
    case_order = np.random.permutation(num_total_cases)

    for c in case_order:
        # Errors for current candidates on case c
        errors_c = arr[candidates, c]
        # Minimum error among current candidates
        min_err = np.min(errors_c)
        # Keep candidates that match the minimum (within numerical tolerance)
        is_best = np.isclose(errors_c, min_err, atol=1e-12)
        candidates = candidates[is_best]
        # If only one candidate remains, select it
        if candidates.size == 1:
            return int(candidates[0])

    # If multiple remain after all cases, pick one uniformly at random
    if candidates.size > 0:
        return int(np.random.choice(candidates))

    # Fallback: should not occur, but select a random individual
    return int(np.random.randint(0, pop_size))