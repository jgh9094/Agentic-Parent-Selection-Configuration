def selection(fitnesses):
    import numpy as np
    # Required values
    num_total_cases = len(fitnesses[0])
    pop_size = len(fitnesses)
    # Convert to array: shape (pop_size, num_total_cases)
    arr = np.array(fitnesses, dtype=float)
    # Compute per-case epsilon using MAD, fallback to std, and ensure positive
    med = np.median(arr, axis=0)
    mad = np.median(np.abs(arr - med), axis=0)
    std = np.std(arr, axis=0)
    eps = np.where(mad > 0, mad, std)
    eps = np.maximum(eps, 1e-12)
    # Randomize case order
    cases = np.random.permutation(num_total_cases)
    candidates = np.arange(pop_size)
    for c in cases:
        errs = arr[candidates, c]
        min_err = errs.min()
        thresh = min_err + eps[c]
        pass_mask = errs <= thresh
        if np.any(pass_mask):
            candidates = candidates[pass_mask]
        if candidates.size == 1:
            return int(candidates[0])
    # If multiple remain, choose one uniformly at random
    return int(np.random.choice(candidates))