def selection(fitnesses):
    import numpy as np

    num_total_cases = len(fitnesses[0])
    pop_size = len(fitnesses)

    arr = np.array(fitnesses, dtype=float)
    # start with all candidate indices
    candidates = np.arange(pop_size)
    # randomize order of cases for lexicase
    cases = np.random.permutation(num_total_cases)

    for case in cases:
        if candidates.size <= 1:
            break
        errors = arr[candidates, case]
        min_err = errors.min()
        # compute a small tolerance (epsilon) per case using MAD across the whole population
        case_vals = arr[:, case]
        mad = np.median(np.abs(case_vals - np.median(case_vals)))
        eps = mad if mad > 0 else 1e-8
        # filter candidates that are within epsilon of the best on this case
        mask = errors <= (min_err + eps)
        candidates = candidates[mask]

    if candidates.size == 0:
        # fallback: choose the best by mean error
        mean_err = arr.mean(axis=1)
        return int(np.argmin(mean_err))

    # if multiple remain, pick one at random
    return int(np.random.choice(candidates))