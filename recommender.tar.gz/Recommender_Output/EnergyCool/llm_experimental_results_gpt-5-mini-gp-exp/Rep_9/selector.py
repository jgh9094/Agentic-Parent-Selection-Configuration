import numpy as np

def selection(fitnesses):
    num_total_cases = len(fitnesses[0])
    pop_size = len(fitnesses)
    arr = np.asarray(fitnesses, dtype=float)  # shape: (pop_size, num_total_cases)

    # Compute per-case epsilons: median absolute deviation from the best per case
    best_per_case = np.min(arr, axis=0)
    abs_devs = np.abs(arr - best_per_case)
    epsilons = np.median(abs_devs, axis=0)
    epsilons = np.maximum(epsilons, 1e-12)

    candidates = list(range(pop_size))
    case_order = np.random.permutation(num_total_cases)

    for case in case_order:
        # Errors for current candidates on this case
        errors = arr[candidates, case]
        best = np.min(errors)
        threshold = best + epsilons[case]
        # Keep candidates within epsilon of the best on this case
        candidates = [c for c in candidates if arr[c, case] <= threshold]
        if len(candidates) == 1:
            return int(candidates[0])

    # Fallbacks
    if len(candidates) == 0:
        # No candidates (should be rare); choose individual with lowest total error
        totals = np.sum(arr, axis=1)
        return int(np.argmin(totals))

    # If multiple remain, choose uniformly at random
    return int(np.random.choice(candidates))