import numpy as np

def selection(fitnesses):
    num_total_cases = len(fitnesses[0])
    pop_size = len(fitnesses)

    rng = np.random.default_rng()

    # Aggregate per-case errors to a single scalar fitness (mean error); lower is better
    mean_errors = np.array([np.mean(ind) for ind in fitnesses])

    # Tournament parameters
    tournament_size = min(7, pop_size)

    # Sample tournament participants (without replacement when possible)
    if pop_size <= tournament_size:
        participants = np.arange(pop_size)
    else:
        participants = rng.choice(pop_size, size=tournament_size, replace=False)

    participant_errors = mean_errors[participants]
    min_err = participant_errors.min()

    # Resolve ties uniformly at random among best contestants
    best_indices = participants[participant_errors == min_err]
    chosen = int(rng.choice(best_indices))

    return chosen