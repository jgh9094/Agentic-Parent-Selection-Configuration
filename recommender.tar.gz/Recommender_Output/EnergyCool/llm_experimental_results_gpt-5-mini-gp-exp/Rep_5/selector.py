def selection(fitnesses):
    import numpy as np

    # Required quantities
    num_total_cases = len(fitnesses[0])
    pop_size = len(fitnesses)

    # Convert to numpy array: shape (pop_size, num_total_cases)
    arr = np.array(fitnesses, dtype=float)

    # Compute per-case epsilon using median absolute deviation (robust)
    med = np.median(arr, axis=0)
    mad = np.median(np.abs(arr - med), axis=0)
    eps = np.maximum(mad, 1e-12)

    # Start with all candidate indices
    candidates = np.arange(pop_size)

    # Randomize case order for lexicase
    case_order = np.random.permutation(num_total_cases)

    for t in case_order:
        # Errors of current candidates on case t
        cand_errs = arr[candidates, t]
        best = np.min(cand_errs)
        # Keep candidates within best + epsilon
        keep_mask = cand_errs <= (best + eps[t])
        candidates = candidates[keep_mask]

        if candidates.size == 1:
            return int(candidates[0])
        if candidates.size == 0:
            # Fallback: if filtering removes all, pick uniformly at random
            return int(np.random.randint(pop_size))

    # If multiple remain after all cases, pick one uniformly at random
    return int(np.random.choice(candidates))