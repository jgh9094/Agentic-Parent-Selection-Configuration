def selection(fitnesses):
    import numpy as np
    num_total_cases = len(fitnesses[0])
    pop_size = len(fitnesses)
    arr = np.array(fitnesses, dtype=float)
    # compute per-case epsilon via median absolute deviation
    med = np.median(arr, axis=0)
    mad = np.median(np.abs(arr - med), axis=0)
    eps = np.where(mad == 0, 1e-8, mad)
    # randomize case order
    cases = np.arange(num_total_cases)
    np.random.shuffle(cases)
    candidates = np.arange(pop_size)
    for c in cases:
        errs = arr[candidates, c]
        best = np.min(errs)
        thr = best + eps[c]
        mask = errs <= thr
        candidates = candidates[mask]
        if candidates.size == 1:
            return int(candidates[0])
    if candidates.size == 0:
        return int(np.random.randint(pop_size))
    return int(np.random.choice(candidates))