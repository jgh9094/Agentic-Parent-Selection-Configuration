def selection(fitnesses):
    import numpy as np
    num_total_cases = len(fitnesses[0])
    pop_size = len(fitnesses)
    # Compute mean error per individual (lower is better)
    mean_errors = np.array([np.mean(ind_errors) for ind_errors in fitnesses])
    # Convert errors to fitness scores (higher is better)
    fitness_scores = 1 / (mean_errors + 1e-10)
    # Roulette wheel selection
    total_fitness = np.sum(fitness_scores)
    pick = np.random.uniform(0, total_fitness)
    current = 0
    for i, score in enumerate(fitness_scores):
        current += score
        if current >= pick:
            return i
    return pop_size - 1