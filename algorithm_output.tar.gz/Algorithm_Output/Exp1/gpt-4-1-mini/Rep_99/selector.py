def selection(fitnesses):
    import numpy as np
    num_total_cases = len(fitnesses[0])
    pop_size = len(fitnesses)
    # Calculate mean error for each individual
    mean_errors = np.array([np.mean(ind_errors) for ind_errors in fitnesses])
    # Convert errors to fitness by negation (lower error -> higher fitness)
    fitness_values = -mean_errors
    # Tournament selection parameters
    tournament_size = 5
    # Randomly select tournament participants
    participants = np.random.choice(pop_size, tournament_size, replace=False)
    # Select the participant with the highest fitness (lowest error)
    winner = participants[np.argmax(fitness_values[participants])]
    return int(winner)