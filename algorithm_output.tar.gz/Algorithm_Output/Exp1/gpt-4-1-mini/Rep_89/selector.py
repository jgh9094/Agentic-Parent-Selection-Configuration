def selection(fitnesses):
    import numpy as np
    num_total_cases = len(fitnesses[0])
    pop_size = len(fitnesses)
    # Calculate mean error per individual
    mean_errors = np.array([np.mean(ind_errors) for ind_errors in fitnesses])
    # Convert errors to fitness scores (lower error -> higher fitness)
    fitness_scores = 1 / (1 + mean_errors)
    # Roulette wheel selection
    total_fitness = np.sum(fitness_scores)
    pick = np.random.rand() * total_fitness
    current = 0
    for i, fit in enumerate(fitness_scores):
        current += fit
        if current >= pick:
            return i
    return pop_size - 1