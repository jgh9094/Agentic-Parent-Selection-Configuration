def selection(fitnesses):
    import numpy as np
    num_total_cases = len(fitnesses[0])
    pop_size = len(fitnesses)
    # Compute mean error for each individual
    mean_errors = np.array([np.mean(ind_errors) for ind_errors in fitnesses])
    # Convert errors to fitness scores (higher is better)
    fitness_scores = 1 / (1 + mean_errors)
    # Roulette wheel selection
    total_fitness = np.sum(fitness_scores)
    pick = np.random.uniform(0, total_fitness)
    current = 0
    for i, fit in enumerate(fitness_scores):
        current += fit
        if current >= pick:
            return i
    return pop_size - 1