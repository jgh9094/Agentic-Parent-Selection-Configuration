def selection(fitnesses):
    import numpy as np
    num_total_cases = len(fitnesses[0])
    pop_size = len(fitnesses)
    # Calculate total error per individual by summing errors across all test cases
    total_errors = np.array([np.sum(individual_errors) for individual_errors in fitnesses])
    # Fitness is inverse of error; add a small epsilon to avoid division by zero
    fitness_scores = 1 / (total_errors + 1e-10)
    # Normalize fitness scores to probabilities
    probabilities = fitness_scores / np.sum(fitness_scores)
    # Select one parent index based on fitness-proportional selection (roulette wheel)
    selected_index = np.random.choice(pop_size, p=probabilities)
    return selected_index