def selection(fitnesses):
    import numpy as np
    num_total_cases = len(fitnesses[0])
    pop_size = len(fitnesses)
    # Compute mean error for each individual
    mean_errors = np.array([np.mean(ind_errors) for ind_errors in fitnesses])
    # Convert errors to fitness scores by inverting (lower error -> higher fitness)
    fitness_scores = 1 / (mean_errors + 1e-10)
    # Normalize fitness scores to sum to 1
    probabilities = fitness_scores / np.sum(fitness_scores)
    # Select one parent index based on probabilities
    selected_index = np.random.choice(pop_size, p=probabilities)
    return selected_index