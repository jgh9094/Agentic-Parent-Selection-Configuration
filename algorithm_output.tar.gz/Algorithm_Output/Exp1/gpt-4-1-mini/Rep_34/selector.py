def selection(fitnesses):
    import numpy as np
    num_total_cases = len(fitnesses[0])
    pop_size = len(fitnesses)
    # Calculate total error per individual by summing errors over all test cases
    total_errors = np.array([np.sum(individual_errors) for individual_errors in fitnesses])
    # Since errors are to be minimized, select the individual with the smallest total error
    selected_index = int(np.argmin(total_errors))
    return selected_index