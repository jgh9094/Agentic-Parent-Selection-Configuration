def selection(fitnesses):
    import numpy as np
    num_total_cases = len(fitnesses[0])
    pop_size = len(fitnesses)
    # Calculate total error (sum of errors) for each individual
    total_errors = np.array([sum(individual_errors) for individual_errors in fitnesses])
    # Select the individual with the lowest total error (best fitness)
    selected_index = int(np.argmin(total_errors))
    return selected_index