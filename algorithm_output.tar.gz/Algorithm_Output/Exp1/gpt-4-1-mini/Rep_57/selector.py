def selection(fitnesses):
    import numpy as np
    num_total_cases = len(fitnesses[0])
    pop_size = len(fitnesses)
    # Calculate mean error for each individual
    mean_errors = np.array([np.mean(individual_errors) for individual_errors in fitnesses])
    # Convert errors to fitness by taking inverse (add small epsilon to avoid division by zero)
    epsilon = 1e-12
    fitness_values = 1 / (mean_errors + epsilon)
    # Roulette wheel selection
    total_fitness = np.sum(fitness_values)
    probabilities = fitness_values / total_fitness
    selected_index = np.random.choice(pop_size, p=probabilities)
    return selected_index