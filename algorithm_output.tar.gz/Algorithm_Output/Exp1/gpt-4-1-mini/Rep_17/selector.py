def selection(fitnesses):
    import numpy as np
    num_total_cases = len(fitnesses[0])
    pop_size = len(fitnesses)
    # Compute mean error per individual (lower is better)
    mean_errors = np.array([np.mean(ind_errors) for ind_errors in fitnesses])
    # Convert errors to fitness scores (higher is better)
    fitness_scores = 1 / (mean_errors + 1e-12)
    # Roulette wheel selection
    probabilities = fitness_scores / np.sum(fitness_scores)
    selected_index = np.random.choice(pop_size, p=probabilities)
    return selected_index