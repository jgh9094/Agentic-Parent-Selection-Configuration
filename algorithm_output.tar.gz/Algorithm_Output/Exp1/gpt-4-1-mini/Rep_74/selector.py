def selection(fitnesses):
    import numpy as np
    num_total_cases = len(fitnesses[0])
    pop_size = len(fitnesses)
    # Compute total error per individual (sum of absolute errors)
    total_errors = np.array([np.sum(ind_errors) for ind_errors in fitnesses])
    # Convert errors to fitness scores (lower error -> higher fitness)
    fitness_scores = 1 / (total_errors + 1e-10)
    # Roulette wheel selection
    probabilities = fitness_scores / np.sum(fitness_scores)
    selected_index = np.random.choice(pop_size, p=probabilities)
    return selected_index