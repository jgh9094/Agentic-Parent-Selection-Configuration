def selection(fitnesses):
    import numpy as np
    num_total_cases = len(fitnesses[0])
    pop_size = len(fitnesses)
    # Calculate mean error for each individual
    mean_errors = np.array([np.mean(ind_errors) for ind_errors in fitnesses])
    # Select the individual with the lowest mean error (best fitness)
    selected_index = int(np.argmin(mean_errors))
    return selected_index