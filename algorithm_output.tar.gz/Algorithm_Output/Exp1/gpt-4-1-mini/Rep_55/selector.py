def selection(fitnesses):
    import numpy as np
    num_total_cases = len(fitnesses[0])
    pop_size = len(fitnesses)
    # Calculate total error per individual (sum of absolute errors)
    total_errors = np.array([np.sum(individual_errors) for individual_errors in fitnesses])
    # Fitness is inverse of error; add a small epsilon to avoid division by zero
    fitness_values = 1 / (total_errors + 1e-10)
    # Normalize fitness values to sum to 1 for probability distribution
    probabilities = fitness_values / np.sum(fitness_values)
    # Select one parent index based on fitness-proportionate selection (roulette wheel)
    selected_index = np.random.choice(pop_size, p=probabilities)
    return selected_index