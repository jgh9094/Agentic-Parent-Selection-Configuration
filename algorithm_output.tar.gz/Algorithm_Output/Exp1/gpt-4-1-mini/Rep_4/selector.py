def selection(fitnesses):
    import numpy as np
    num_total_cases = len(fitnesses[0])
    pop_size = len(fitnesses)
    # Calculate mean error for each individual
    mean_errors = np.array([np.mean(individual_errors) for individual_errors in fitnesses])
    # Convert errors to fitness scores (lower error -> higher fitness)
    fitness_scores = 1 / (mean_errors + 1e-10)
    # Roulette wheel selection
    total_fitness = np.sum(fitness_scores)
    pick = np.random.rand() * total_fitness
    current = 0
    for i, fitness in enumerate(fitness_scores):
        current += fitness
        if current > pick:
            return i
    return pop_size - 1