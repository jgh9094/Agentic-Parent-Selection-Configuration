def selection(fitnesses):
    import numpy as np
    num_total_cases = len(fitnesses[0])
    pop_size = len(fitnesses)
    # Compute fitness as negative mean error (since errors are to be minimized)
    mean_errors = np.array([np.mean(ind_errors) for ind_errors in fitnesses])
    fitness_values = -mean_errors
    # Tournament selection parameters
    tournament_size = 5
    # Randomly select tournament_size individuals
    participants = np.random.choice(pop_size, tournament_size, replace=False)
    # Select the individual with the highest fitness (lowest mean error)
    best_idx = participants[np.argmax(fitness_values[participants])]
    return best_idx