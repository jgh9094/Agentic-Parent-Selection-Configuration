def selection(fitnesses):
    import numpy as np
    num_total_cases = len(fitnesses[0])
    pop_size = len(fitnesses)
    # Calculate mean error for each individual
    mean_errors = np.array([np.mean(ind_errors) for ind_errors in fitnesses])
    # Convert errors to fitness values (higher is better)
    fitness_values = 1 / (1 + mean_errors)
    # Normalize fitness values to sum to 1
    probabilities = fitness_values / np.sum(fitness_values)
    # Select one parent index based on probabilities
    selected_index = np.random.choice(pop_size, p=probabilities)
    return selected_index