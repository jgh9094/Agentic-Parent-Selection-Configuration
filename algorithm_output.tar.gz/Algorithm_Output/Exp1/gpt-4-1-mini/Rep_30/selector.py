def selection(fitnesses):
    import numpy as np
    num_total_cases = len(fitnesses[0])
    pop_size = len(fitnesses)
    # Calculate mean error per individual
    mean_errors = np.array([np.mean(ind_errors) for ind_errors in fitnesses])
    # Select the individual with the lowest mean error
    selected_index = int(np.argmin(mean_errors))
    return selected_index