def selection(fitnesses):
    import numpy as np
    num_total_cases = len(fitnesses[0])
    pop_size = len(fitnesses)
    # Calculate mean error per individual
    mean_errors = np.array([np.mean(ind_errors) for ind_errors in fitnesses])
    # Convert errors to fitness by taking inverse (add small epsilon to avoid division by zero)
    fitness_values = 1 / (mean_errors + 1e-12)
    # Roulette wheel selection
    total_fitness = np.sum(fitness_values)
    pick = np.random.rand() * total_fitness
    current = 0
    for i, fit in enumerate(fitness_values):
        current += fit
        if current >= pick:
            return i
    return pop_size - 1