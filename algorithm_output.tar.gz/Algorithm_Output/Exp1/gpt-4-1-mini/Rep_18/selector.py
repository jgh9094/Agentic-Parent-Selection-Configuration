def selection(fitnesses):
    import numpy as np
    num_total_cases = len(fitnesses[0])
    pop_size = len(fitnesses)
    # Calculate mean error for each individual
    mean_errors = np.array([np.mean(ind_errors) for ind_errors in fitnesses])
    # Convert errors to fitness by taking inverse (higher fitness is better)
    fitness_values = 1 / (mean_errors + 1e-12)  # add small epsilon to avoid division by zero
    # Roulette wheel selection
    total_fitness = np.sum(fitness_values)
    pick = np.random.uniform(0, total_fitness)
    current = 0
    for i in range(pop_size):
        current += fitness_values[i]
        if current >= pick:
            return i
    return pop_size - 1  # fallback in case of rounding errors