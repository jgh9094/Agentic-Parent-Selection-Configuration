def selection(fitnesses):
    import numpy as np
    num_total_cases = len(fitnesses[0])
    pop_size = len(fitnesses)
    # Calculate mean error for each individual
    mean_errors = np.array([np.mean(ind_errors) for ind_errors in fitnesses])
    # Convert errors to fitness by taking inverse (add small epsilon to avoid division by zero)
    epsilon = 1e-12
    fitness_scores = 1 / (mean_errors + epsilon)
    # Normalize fitness scores to sum to 1
    probabilities = fitness_scores / np.sum(fitness_scores)
    # Select one parent index based on fitness-proportional selection (roulette wheel)
    selected_index = np.random.choice(pop_size, p=probabilities)
    return selected_index