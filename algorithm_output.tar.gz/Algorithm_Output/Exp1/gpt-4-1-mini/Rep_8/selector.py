def selection(fitnesses):
    import numpy as np
    num_total_cases = len(fitnesses[0])
    pop_size = len(fitnesses)
    # Calculate mean error for each individual
    mean_errors = np.array([np.mean(ind_errors) for ind_errors in fitnesses])
    # Convert errors to fitness scores (lower error means higher fitness)
    fitness_scores = 1 / (mean_errors + 1e-10)
    # Tournament selection parameters
    tournament_size = 5
    # Randomly select tournament_size individuals
    candidates = np.random.choice(pop_size, tournament_size, replace=False)
    # Select the individual with the highest fitness score among candidates
    winner = candidates[np.argmax(fitness_scores[candidates])]
    return int(winner)