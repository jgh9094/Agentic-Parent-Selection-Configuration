def selection(fitnesses):
    import numpy as np
    num_total_cases = len(fitnesses[0])
    pop_size = len(fitnesses)
    # Compute total error for each individual (sum of absolute errors)
    total_errors = np.array([np.sum(individual_errors) for individual_errors in fitnesses])
    # Convert errors to fitness values (lower error -> higher fitness)
    fitness_values = 1 / (1 + total_errors)
    # Normalize fitness values to probabilities
    probabilities = fitness_values / np.sum(fitness_values)
    # Select one parent index based on fitness proportionate selection
    selected_index = np.random.choice(pop_size, p=probabilities)
    return selected_index