import numpy as np

def selection(fitnesses):
    num_total_cases = len(fitnesses[0])
    pop_size = len(fitnesses)
    
    # Calculate fitness for each individual
    fitness = [np.mean([error for error in fit]) for fit in fitnesses]
    
    # Normalize the fitness values to be between 0 and 1
    max_fitness = np.max(fitness)
    if max_fitness != 0:
        fitness = [f / max_fitness for f in fitness]
        
    # Select parent using roulette wheel selection
    cumulative_probabilities = np.cumsum(fitness)
    r = np.random.rand()
    index = np.where(cumulative_probabilities >= r)[0][0]
    
    return index