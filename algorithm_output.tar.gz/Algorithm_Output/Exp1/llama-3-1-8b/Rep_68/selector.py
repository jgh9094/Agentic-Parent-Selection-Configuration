import numpy as np
def selection(fitnesses):
    num_total_cases = len(fitnesses[0])
    pop_size = len(fitnesses)
    min_fitness = float('inf')
    best_individual_index = -1
    for i in range(pop_size):
        fitness = sum(fitnesses[i]) / num_total_cases
        if fitness < min_fitness:
            min_fitness = fitness
            best_individual_index = i
    return best_individual_index