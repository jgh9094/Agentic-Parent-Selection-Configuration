import numpy as np
def selection(fitnesses):
    num_total_cases = len(fitnesses[0])
    pop_size = len(fitnesses)
    scores = [sum(individual) for individual in fitnesses]
    best_individual_index = np.argmin(scores)
    return best_individual_index