import numpy as np
def selection(fitnesses):
    num_total_cases = len(fitnesses[0])
    pop_size = len(fitnesses)
    fitness = [np.mean([error for error in individual]) for individual in fitnesses]
    return np.argmax(fitness)