import numpy as np
def selection(fitnesses):
    num_total_cases = len(fitnesses[0])
    pop_size = len(fitnesses)
    total_fitness = 0
    for i in range(pop_size):
        total_fitness += sum(fitnesses[i]) / num_total_cases
    best_individual_index = 0
    min_error = float('inf')
    for i in range(pop_size):
        individual_error = sum(fitnesses[i]) / num_total_cases
        if individual_error < min_error:
            min_error = individual_error
            best_individual_index = i
    return best_individual_index