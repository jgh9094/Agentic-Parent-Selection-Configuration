import numpy as np

def selection(fitnesses):
    num_total_cases = len(fitnesses[0])
    pop_size = len(fitnesses)
    
    # Calculate average fitness for each individual
    avg_fitness = [np.mean(individual) for individual in fitnesses]
    
    # Normalize the fitness values to be between 0 and 1
    normalized_avg_fitness = np.array(avg_fitness) / max(avg_fitness)
    
    # Use roulette wheel selection based on the normalized fitness values
    cumulative_probabilities = np.cumsum(normalized_avg_fitness)
    selected_index = np.searchsorted(cumulative_probabilities, np.random.rand())
    
    return selected_index