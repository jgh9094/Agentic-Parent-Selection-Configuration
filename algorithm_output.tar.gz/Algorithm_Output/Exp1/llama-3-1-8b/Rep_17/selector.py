import numpy as np

def selection(fitnesses):
    num_total_cases = len(fitnesses[0])
    pop_size = len(fitnesses)
    
    # Calculate average fitness for each individual
    avg_fitness = [np.mean(individual) for individual in fitnesses]
    
    # Sort the population based on their average fitness
    sorted_indices = np.argsort(avg_fitness)
    
    # Select the parent with the best average fitness
    selected_parent_index = sorted_indices[0]
    
    return selected_parent_index