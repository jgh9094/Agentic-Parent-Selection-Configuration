import numpy as np
def selection(fitnesses):
    num_total_cases = len(fitnesses[0])
    pop_size = len(fitnesses)
    fitness = [np.mean([fitnesses[i][j] for j in range(num_total_cases)]) for i in range(pop_size)]
    return np.argmax(fitness)