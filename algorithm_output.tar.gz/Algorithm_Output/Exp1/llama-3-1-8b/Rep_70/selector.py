import numpy as np

def selection(fitnesses):
    num_total_cases = len(fitnesses[0])
    pop_size = len(fitnesses)
    
    # Calculate average fitness for each individual
    avg_fitness = [np.mean(individual) for individual in fitnesses]
    
    # Normalize the average fitness values to be between 0 and 1
    normalized_avg_fitness = [val / np.max(avg_fitness) for val in avg_fitness]
    
    # Select parent based on roulette wheel selection
    total_prob = sum(normalized_avg_fitness)
    r = np.random.rand()
    cumulative_prob = 0
    
    for i, prob in enumerate(normalized_avg_fitness):
        cumulative_prob += prob / total_prob
        if r <= cumulative_prob:
            return i