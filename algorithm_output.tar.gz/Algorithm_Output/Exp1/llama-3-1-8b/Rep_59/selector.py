import numpy as np

def selection(fitnesses):
    num_total_cases = len(fitnesses[0])
    pop_size = len(fitnesses)
    
    # Calculate total fitness for each individual
    total_fitness = [sum(individual) for individual in fitnesses]
    
    # Normalize the total fitness to ensure it is within the range of 0 to 1
    normalized_total_fitness = np.array(total_fitness) / sum(total_fitness)
    
    # Use roulette wheel selection to select a parent
    selected_parent_index = np.random.choice(pop_size, p=normalized_total_fitness)
    
    return selected_parent_index