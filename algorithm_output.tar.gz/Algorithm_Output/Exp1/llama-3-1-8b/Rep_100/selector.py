import numpy as np
def selection(fitnesses):
    num_total_cases = len(fitnesses[0])
    pop_size = len(fitnesses)
    fitness_sum = [sum(individual) for individual in fitnesses]
    min_fitness = min(fitness_sum)
    selected_index = 0
    for i in range(pop_size):
        if fitness_sum[i] == min_fitness:
            selected_index = i
            break
    return selected_index