import numpy as np
def selection(fitnesses):
    num_total_cases = len(fitnesses[0])
    pop_size = len(fitnesses)
    total_errors = [np.mean([fitness[i] for fitness in fitnesses]) for i in range(pop_size)]
    min_error_index = total_errors.index(min(total_errors))
    return min_error_index