import numpy as np

def selection(fitnesses):
    num_total_cases = len(fitnesses[0])
    pop_size = len(fitnesses)
    total_fitness = 0
    for i in range(pop_size):
        total_fitness += 1 / (sum([fitnesses[i][j] ** 2 for j in range(num_total_cases)]) + 1)
    selection_probabilities = [total_fitness * (1 / (sum([fitnesses[i][j] ** 2 for j in range(num_total_cases)]) + 1)) for i in range(pop_size)]
    cumulative_probabilities = np.cumsum(selection_probabilities) / sum(selection_probabilities)
    r = np.random.rand()
    for i in range(pop_size):
        if r <= cumulative_probabilities[i]:
            return i