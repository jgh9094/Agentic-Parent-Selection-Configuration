import numpy as np

def selection(fitnesses):
    num_total_cases = len(fitnesses[0])
    pop_size = len(fitnesses)
    
    # Calculate average fitness for each individual
    avg_fitness = [np.mean(individual) for individual in fitnesses]
    
    # Normalize the average fitness values to be between 0 and 1
    normalized_avg_fitness = np.array(avg_fitness) / max(avg_fitness)
    
    # Select parent based on roulette wheel selection
    cumulative_probabilities = np.cumsum(normalized_avg_fitness)
    random_value = np.random.rand()
    for i, cum_prob in enumerate(cumulative_probabilities):
        if random_value <= cum_prob:
            return i