import numpy as np

def selection(fitnesses):
    num_total_cases = len(fitnesses[0])
    pop_size = len(fitnesses)
    
    # Calculate average error for each individual
    avg_errors = [np.mean(individual) for individual in fitnesses]
    
    # Select the index of the individual with the minimum average error
    parent_index = np.argmin(avg_errors)
    
    return parent_index