import numpy as np

def selection(fitnesses):
    num_total_cases = len(fitnesses[0])
    pop_size = len(fitnesses)
    
    # Calculate average fitness for each individual
    avg_fitness = [np.mean(individual) for individual in fitnesses]
    
    # Normalize the average fitness values to be between 0 and 1
    normalized_avg_fitness = np.array(avg_fitness) / max(avg_fitness)
    
    # Select parent based on roulette wheel selection
    parent_index = np.random.choice(pop_size, p=normalized_avg_fitness)
    
    return parent_index