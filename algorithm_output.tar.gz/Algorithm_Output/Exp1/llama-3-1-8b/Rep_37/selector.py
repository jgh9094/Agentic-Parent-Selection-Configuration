import numpy as np
def selection(fitnesses):
    num_total_cases = len(fitnesses[0])
    pop_size = len(fitnesses)
    min_index = 0
    min_value = float('inf')
    for i in range(pop_size):
        total_error = sum(fitnesses[i])
        if total_error < min_value:
            min_value = total_error
            min_index = i
    return min_index