import numpy as np

def selection(fitnesses):
    num_total_cases = len(fitnesses[0])
    pop_size = len(fitnesses)
    
    fitness_sum = [sum(individual) for individual in fitnesses]
    min_fitness = min(fitness_sum)
    normalized_fitness = [(min_fitness + fit) / (num_total_cases * min_fitness) for fit in fitness_sum]
    
    cum_prob = np.cumsum(normalized_fitness)
    rand_num = np.random.rand()
    
    for i, prob in enumerate(cum_prob):
        if rand_num <= prob:
            return i