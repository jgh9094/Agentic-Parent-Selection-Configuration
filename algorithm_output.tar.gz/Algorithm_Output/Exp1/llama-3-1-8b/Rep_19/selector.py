import numpy as np
def selection(fitnesses):
    num_total_cases = len(fitnesses[0])
    pop_size = len(fitnesses)
    min_index = 0
    min_fitness = float('inf')
    for i in range(pop_size):
        fitness = sum(fitnesses[i]) / num_total_cases
        if fitness < min_fitness:
            min_fitness = fitness
            min_index = i
    return min_index