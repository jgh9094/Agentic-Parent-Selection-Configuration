import numpy as np

def selection(fitnesses):
    num_total_cases = len(fitnesses[0])
    pop_size = len(fitnesses)
    
    # Calculate fitness for each individual
    fitness = [np.mean([error for error in fit if error != 0]) for fit in fitnesses]
    
    # Normalize fitness values to be between 0 and 1
    min_fitness = np.min(fitness)
    max_fitness = np.max(fitness)
    normalized_fitness = [(f - min_fitness) / (max_fitness - min_fitness) for f in fitness]
    
    # Select parent based on tournament selection with size of 3
    selected_parents = []
    for _ in range(pop_size):
        tournament_participants = np.random.choice(pop_size, size=3, replace=False)
        winner_index = np.argmax([normalized_fitness[i] for i in tournament_participants])
        selected_parents.append(tournament_participants[winner_index])
    
    # Select one parent from the selected parents
    parent_index = np.random.choice(selected_parents)
    return parent_index