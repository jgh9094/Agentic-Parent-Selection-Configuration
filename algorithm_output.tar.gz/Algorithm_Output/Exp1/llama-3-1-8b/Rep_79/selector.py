import numpy as np
def selection(fitnesses):
    num_total_cases = len(fitnesses[0])
    pop_size = len(fitnesses)
    scores = []
    for i in range(pop_size):
        score = -np.mean([error for error in fitnesses[i] if error != 0]) # ignore zero errors
        scores.append(score)
    max_score_index = np.argmax(scores)
    return max_score_index