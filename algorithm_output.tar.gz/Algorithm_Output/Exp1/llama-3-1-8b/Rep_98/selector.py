import numpy as np
def selection(fitnesses):
    num_total_cases = len(fitnesses[0])
    pop_size = len(fitnesses)
    fitness_sum = [sum(individual) for individual in fitnesses]
    total_fitness = sum(fitness_sum)
    probabilities = [fitness / total_fitness for fitness in fitness_sum]
    cumulative_probabilities = np.cumsum(probabilities)
    random_value = np.random.rand()
    for i, cumulative_probability in enumerate(cumulative_probabilities):
        if random_value < cumulative_probability:
            return i