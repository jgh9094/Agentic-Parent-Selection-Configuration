import numpy as np

def selection(fitnesses):
    num_total_cases = len(fitnesses[0])
    pop_size = len(fitnesses)
    
    # Calculate average fitness for each individual
    averages = [np.mean(individual) for individual in fitnesses]
    
    # Select the index of the individual with the minimum average fitness
    parent_index = np.argmin(averages)
    
    return parent_index