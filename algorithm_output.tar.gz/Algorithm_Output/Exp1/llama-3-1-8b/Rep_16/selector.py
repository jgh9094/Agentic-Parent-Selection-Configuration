import numpy as np
def selection(fitnesses):
    num_total_cases = len(fitnesses[0])
    pop_size = len(fitnesses)
    scores = []
    for i in range(pop_size):
        score = -np.mean(fitnesses[i]) # Invert the fitness to maximize it
        scores.append(score)
    best_individual_index = np.argmax(scores)
    return best_individual_index