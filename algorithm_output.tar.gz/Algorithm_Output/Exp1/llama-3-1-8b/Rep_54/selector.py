import numpy as np
def selection(fitnesses):
    num_total_cases = len(fitnesses[0])
    pop_size = len(fitnesses)
    total_fitness = [sum(individual) for individual in fitnesses]
    probabilities = [total / (num_total_cases * pop_size) for total in total_fitness]
    cumulative_probabilities = np.cumsum(probabilities)
    random_value = np.random.rand()
    for i, cp in enumerate(cumulative_probabilities):
        if random_value < cp:
            return i