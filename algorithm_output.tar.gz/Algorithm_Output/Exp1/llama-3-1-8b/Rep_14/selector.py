import numpy as np

def selection(fitnesses):
    num_total_cases = len(fitnesses[0])
    pop_size = len(fitnesses)
    
    # Calculate total fitness for each individual
    total_fitness = [sum(individual) for individual in fitnesses]
    
    # Normalize the total fitness values to ensure they are between 0 and 1
    normalized_total_fitness = np.array(total_fitness) / sum(total_fitness)
    
    # Select parent based on roulette wheel selection
    r = np.random.rand()
    cumulative_prob = 0
    for i in range(pop_size):
        cumulative_prob += normalized_total_fitness[i]
        if r <= cumulative_prob:
            return i