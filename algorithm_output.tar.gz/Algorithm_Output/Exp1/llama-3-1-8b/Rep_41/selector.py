import numpy as np

def selection(fitnesses):
    num_total_cases = len(fitnesses[0])
    pop_size = len(fitnesses)
    
    # Calculate average fitness for each individual
    avg_fitness = [np.mean(individual) for individual in fitnesses]
    
    # Normalize the fitness values to ensure they are within a similar range
    max_avg_fitness = max(avg_fitness)
    if max_avg_fitness != 0:
        avg_fitness = [fitness / max_avg_fitness for fitness in avg_fitness]
        
    # Calculate the cumulative sum of normalized fitness values
    cum_sum = np.cumsum(avg_fitness)
    
    # Generate a random number between 0 and 1
    rand_num = np.random.rand()
    
    # Find the index where the cumulative sum exceeds the random number
    for i in range(pop_size):
        if cum_sum[i] > rand_num:
            return i