import numpy as np

def selection(fitnesses):
    num_total_cases = len(fitnesses[0])
    pop_size = len(fitnesses)
    
    # Calculate total error for each individual
    total_errors = [sum(individual) for individual in fitnesses]
    
    # Normalize the total errors to be between 0 and 1
    normalized_errors = np.array(total_errors) / sum(total_errors)
    
    # Select parent based on roulette wheel selection
    parent_index = np.random.choice(pop_size, p=normalized_errors)
    
    return parent_index