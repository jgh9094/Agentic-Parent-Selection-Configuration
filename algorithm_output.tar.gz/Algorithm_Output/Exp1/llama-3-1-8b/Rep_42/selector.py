import numpy as np

def selection(fitnesses):
    num_total_cases = len(fitnesses[0])
    pop_size = len(fitnesses)
    
    # Calculate average fitness for each individual
    avg_fitness = [np.mean(individual) for individual in fitnesses]
    
    # Normalize the average fitness values to be between 0 and 1
    normalized_avg_fitness = [val / max(avg_fitness) for val in avg_fitness]
    
    # Use roulette wheel selection to select a parent
    cumulative_probabilities = [sum(normalized_avg_fitness[:i+1]) for i in range(pop_size)]
    selected_parent_index = np.random.choice(pop_size, p=cumulative_probabilities)
    
    return selected_parent_index