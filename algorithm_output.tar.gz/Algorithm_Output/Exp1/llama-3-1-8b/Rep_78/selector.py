import numpy as np

def selection(fitnesses):
    num_total_cases = len(fitnesses[0])
    pop_size = len(fitnesses)
    
    # Calculate average error for each individual
    avg_errors = [np.mean(individual) for individual in fitnesses]
    
    # Select the index of the individual with the minimum average error
    min_avg_error_idx = np.argmin(avg_errors)
    
    return min_avg_error_idx