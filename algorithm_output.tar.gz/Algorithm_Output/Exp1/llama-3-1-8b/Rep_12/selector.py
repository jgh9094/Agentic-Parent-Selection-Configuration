import numpy as np

def selection(fitnesses):
    num_total_cases = len(fitnesses[0])
    pop_size = len(fitnesses)
    
    # Calculate average fitness for each individual
    avg_fitness = [np.mean(individual) for individual in fitnesses]
    
    # Normalize the average fitness values to ensure they are between 0 and 1
    normalized_avg_fitness = np.array(avg_fitness) / max(avg_fitness)
    
    # Use roulette wheel selection based on the normalized average fitness values
    cumulative_probabilities = np.cumsum(normalized_avg_fitness)
    random_value = np.random.rand()
    selected_index = np.where(cumulative_probabilities >= random_value)[0][0]
    
    return selected_index