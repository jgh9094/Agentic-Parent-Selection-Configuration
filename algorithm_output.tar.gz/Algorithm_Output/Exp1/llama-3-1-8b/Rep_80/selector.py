import numpy as np

def selection(fitnesses):
    num_total_cases = len(fitnesses[0])
    pop_size = len(fitnesses)
    
    # Calculate mean fitness for each individual
    mean_fitness = [np.mean(individual) for individual in fitnesses]
    
    # Normalize the mean fitness values to be between 0 and 1
    normalized_mean_fitness = [fitness / max(mean_fitness) for fitness in mean_fitness]
    
    # Select parent based on tournament selection with size 3
    selected_parent_index = np.random.choice(pop_size, p=normalized_mean_fitness)
    
    return selected_parent_index