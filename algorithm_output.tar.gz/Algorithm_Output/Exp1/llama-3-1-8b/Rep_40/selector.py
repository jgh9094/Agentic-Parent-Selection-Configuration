import numpy as np

def selection(fitnesses):
    num_total_cases = len(fitnesses[0])
    pop_size = len(fitnesses)
    
    # Calculate fitness for each individual
    fitness = [np.mean([error for error in fit]) for fit in fitnesses]
    
    # Normalize fitness values to be between 0 and 1
    max_fitness = np.max(fitness)
    if max_fitness != 0:
        fitness = [f / max_fitness for f in fitness]
        
    # Use roulette wheel selection to select a parent
    total_fitness = sum(fit for fit in fitness)
    r = np.random.rand() * total_fitness
    cumulative_fitness = 0
    for i, fit in enumerate(fitness):
        cumulative_fitness += fit
        if r <= cumulative_fitness:
            return i