import numpy as np
def selection(fitnesses):
    num_total_cases = len(fitnesses[0])
    pop_size = len(fitnesses)
    errors = [np.mean([f[i] for f in fitnesses]) for i in range(pop_size)]
    return np.argmin(errors)