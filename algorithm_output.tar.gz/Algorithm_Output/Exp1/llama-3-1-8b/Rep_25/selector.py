import numpy as np

def selection(fitnesses):
    num_total_cases = len(fitnesses[0])
    pop_size = len(fitnesses)
    
    # Calculate average fitness for each individual
    avg_fitness = [sum(individual) / num_total_cases for individual in fitnesses]
    
    # Normalize the average fitness values to be between 0 and 1
    max_avg_fitness = max(avg_fitness)
    if max_avg_fitness != 0:
        normalized_avg_fitness = [fitness / max_avg_fitness for fitness in avg_fitness]
    else:
        normalized_avg_fitness = [1.0 / pop_size for _ in range(pop_size)]
    
    # Calculate cumulative sum of the normalized average fitness values
    cum_sum_normalized_avg_fitness = np.cumsum(normalized_avg_fitness)
    
    # Generate a random number between 0 and 1
    rand_num = np.random.rand()
    
    # Find the index of the first element in the cumulative sum that is greater than or equal to the random number
    for i, cum_sum in enumerate(cum_sum_normalized_avg_fitness):
        if cum_sum >= rand_num:
            return i