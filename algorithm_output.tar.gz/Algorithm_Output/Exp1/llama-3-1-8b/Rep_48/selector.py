import numpy as np

def selection(fitnesses):
    num_total_cases = len(fitnesses[0])
    pop_size = len(fitnesses)
    
    fitness = [np.mean(individual) for individual in fitnesses]
    
    indices = np.argsort(fitness)
    
    return indices[0]