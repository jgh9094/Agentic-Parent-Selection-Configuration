import numpy as np
def selection(fitnesses):
    num_total_cases = len(fitnesses[0])
    pop_size = len(fitnesses)
    min_error = float('inf')
    parent_index = -1
    for i in range(pop_size):
        error = sum(fitnesses[i]) / num_total_cases
        if error < min_error:
            min_error = error
            parent_index = i
    return parent_index