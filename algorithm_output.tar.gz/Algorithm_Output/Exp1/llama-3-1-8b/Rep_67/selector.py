import numpy as np
def selection(fitnesses):
    num_total_cases = len(fitnesses[0])
    pop_size = len(fitnesses)
    return np.argmin(np.mean(fitnesses, axis=1))