import numpy as np
def selection(fitnesses):
    num_total_cases = len(fitnesses[0])
    pop_size = len(fitnesses)
    total_errors = [sum(individual) for individual in fitnesses]
    best_index = np.argmin(total_errors)
    return best_index