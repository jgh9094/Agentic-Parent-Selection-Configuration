import numpy as np

def selection(fitnesses):
    num_total_cases = len(fitnesses[0])
    pop_size = len(fitnesses)
    
    # Calculate average fitness for each individual
    avg_fitness = [np.mean(individual) for individual in fitnesses]
    
    # Normalize the average fitness values to ensure they are between 0 and 1
    max_avg_fitness = np.max(avg_fitness)
    if max_avg_fitness != 0:
        avg_fitness = [f / max_avg_fitness for f in avg_fitness]
        
    # Use roulette wheel selection based on the normalized average fitness values
    cumulative_probabilities = [sum(avg_fitness[:i+1]) for i in range(pop_size)]
    
    # Generate a random number between 0 and 1 to simulate spinning the roulette wheel
    spin_result = np.random.rand()
    
    # Determine which individual is selected based on the spin result and the cumulative probabilities
    selected_index = next(i for i, prob in enumerate(cumulative_probabilities) if spin_result <= prob)
    
    return selected_index