import numpy as np

def selection(fitnesses):
    num_total_cases = len(fitnesses[0])
    pop_size = len(fitnesses)
    
    # Calculate fitness for each individual
    fitness = [np.mean(individual) for individual in fitnesses]
    
    # Normalize fitness values to ensure they are between 0 and 1
    min_fitness = np.min(fitness)
    max_fitness = np.max(fitness)
    normalized_fitness = [(f - min_fitness) / (max_fitness - min_fitness) if max_fitness != min_fitness else 0.5 for f in fitness]
    
    # Use roulette wheel selection to select a parent
    total_normalized_fitness = sum(normalized_fitness)
    r = np.random.rand()
    cumulative_prob = 0
    selected_parent_index = None
    
    for i, prob in enumerate(normalized_fitness):
        cumulative_prob += prob / total_normalized_fitness
        if r < cumulative_prob:
            selected_parent_index = i
            break
    
    return selected_parent_index