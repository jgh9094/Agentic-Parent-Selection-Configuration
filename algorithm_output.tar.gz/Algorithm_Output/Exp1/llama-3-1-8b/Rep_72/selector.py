import numpy as np

def selection(fitnesses):
    num_total_cases = len(fitnesses[0])
    pop_size = len(fitnesses)
    
    # Calculate fitness for each individual
    fitness = [np.mean([error for error in fit if error != 0]) for fit in fitnesses]
    
    # Normalize the fitness values to ensure they are between 0 and 1
    min_fitness = np.min(fitness)
    max_fitness = np.max(fitness)
    normalized_fitness = [(fit - min_fitness) / (max_fitness - min_fitness) if max_fitness != min_fitness else 0.5 for fit in fitness]
    
    # Use roulette wheel selection to select a parent
    cumulative_probabilities = [sum(normalized_fitness[:i+1]) for i in range(pop_size)]
    selected_parent_index = np.random.choice(pop_size, p=cumulative_probabilities)
    
    return selected_parent_index