import numpy as np
def selection(fitnesses):
    num_total_cases = len(fitnesses[0])
    pop_size = len(fitnesses)
    total_fitness = 0
    for i in range(pop_size):
        total_fitness += sum(fitnesses[i]) / num_total_cases
    best_index = 0
    min_avg_error = float('inf')
    for i in range(pop_size):
        avg_error = sum(fitnesses[i]) / num_total_cases
        if avg_error < min_avg_error:
            min_avg_error = avg_error
            best_index = i
    return best_index