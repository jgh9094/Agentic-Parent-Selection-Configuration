import numpy as np

def selection(fitnesses):
    num_total_cases = len(fitnesses[0])
    pop_size = len(fitnesses)
    
    # Calculate the average fitness for each individual
    avg_fitness = [np.mean(individual) for individual in fitnesses]
    
    # Normalize the average fitness values to be between 0 and 1
    normalized_avg_fitness = [value / max(avg_fitness) for value in avg_fitness]
    
    # Select the parent with the highest normalized average fitness
    selected_parent_index = np.argmax(normalized_avg_fitness)
    
    return selected_parent_index