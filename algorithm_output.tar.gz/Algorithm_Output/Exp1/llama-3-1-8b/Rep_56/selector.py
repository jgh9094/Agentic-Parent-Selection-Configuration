import numpy as np

def selection(fitnesses):
    num_total_cases = len(fitnesses[0])
    pop_size = len(fitnesses)
    
    # Calculate average fitness for each individual
    avg_fitness = [np.mean(individual) for individual in fitnesses]
    
    # Normalize the average fitness values to be between 0 and 1
    max_avg_fitness = max(avg_fitness)
    if max_avg_fitness != 0:
        normalized_avg_fitness = [avg / max_avg_fitness for avg in avg_fitness]
    else:
        normalized_avg_fitness = avg_fitness
    
    # Use roulette wheel selection to select the parent
    total_normalized_fitness = sum(normalized_avg_fitness)
    r = np.random.rand()
    cumulative_prob = 0
    for i, prob in enumerate(normalized_avg_fitness):
        cumulative_prob += prob / total_normalized_fitness
        if r < cumulative_prob:
            return i