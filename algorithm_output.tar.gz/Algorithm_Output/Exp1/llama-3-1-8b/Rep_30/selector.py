import numpy as np

def selection(fitnesses):
    num_total_cases = len(fitnesses[0])
    pop_size = len(fitnesses)
    
    total_fitness = [sum(individual) for individual in fitnesses]
    probabilities = [total / (num_total_cases * pop_size) for total in total_fitness]
    
    cumulative_probabilities = np.cumsum(probabilities)
    
    random_value = np.random.rand()
    selected_parent_index = 0
    
    while True:
        if random_value <= cumulative_probabilities[selected_parent_index]:
            break
        else:
            selected_parent_index += 1
            
    return selected_parent_index