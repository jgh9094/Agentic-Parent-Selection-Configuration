import numpy as np
def selection(fitnesses):
    num_total_cases = len(fitnesses[0])
    pop_size = len(fitnesses)
    min_error = float('inf')
    best_individual = -1
    for i in range(pop_size):
        error = sum(fitnesses[i]) / num_total_cases
        if error < min_error:
            min_error = error
            best_individual = i
    return best_individual