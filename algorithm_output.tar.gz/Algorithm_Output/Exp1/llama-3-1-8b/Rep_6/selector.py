import numpy as np

def selection(fitnesses):
    num_total_cases = len(fitnesses[0])
    pop_size = len(fitnesses)
    
    # Calculate average fitness for each individual
    avg_fitness = [np.mean(individual) for individual in fitnesses]
    
    # Normalize the average fitness values to be between 0 and 1
    max_avg_fitness = max(avg_fitness)
    if max_avg_fitness != 0:
        normalized_avg_fitness = [avg / max_avg_fitness for avg in avg_fitness]
    else:
        normalized_avg_fitness = avg_fitness
    
    # Select parent based on the normalized average fitness values
    selected_parent_index = np.argmax(normalized_avg_fitness)
    
    return selected_parent_index