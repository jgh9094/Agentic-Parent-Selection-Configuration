import numpy as np

def selection(fitnesses):
    num_total_cases = len(fitnesses[0])
    pop_size = len(fitnesses)
    
    # Calculate fitness for each individual
    fitness = [np.mean([error for error in fit if error != 0]) if any(error != 0 for error in fit) else np.inf for fit in fitnesses]
    
    # Normalize fitness values to be between 0 and 1
    max_fitness = max(fitness)
    min_fitness = min(fitness)
    normalized_fitness = [(fit - min_fitness) / (max_fitness - min_fitness) if max_fitness != min_fitness else 1.0 for fit in fitness]
    
    # Calculate probability of selection for each individual
    probabilities = [p / sum(normalized_fitness) for p in normalized_fitness]
    
    # Select parent using roulette wheel selection
    r = np.random.rand()
    cumulative_prob = 0
    for i, prob in enumerate(probabilities):
        cumulative_prob += prob
        if r <= cumulative_prob:
            return i