import numpy as np

def selection(fitnesses):
    num_total_cases = len(fitnesses[0])
    pop_size = len(fitnesses)
    
    # Calculate average fitness for each individual
    avg_fitness = [np.mean(individual) for individual in fitnesses]
    
    # Normalize the average fitness values to ensure they are between 0 and 1
    max_avg_fitness = max(avg_fitness)
    if max_avg_fitness != 0:
        avg_fitness = [f / max_avg_fitness for f in avg_fitness]
    
    # Calculate cumulative sum of normalized average fitness values
    cum_sum = np.cumsum(avg_fitness)
    
    # Generate a random number between 0 and 1
    rand_num = np.random.rand()
    
    # Find the index where the cumulative sum exceeds the random number
    for i, c in enumerate(cum_sum):
        if c >= rand_num:
            return i