import numpy as np
def selection(fitnesses):
    num_total_cases = len(fitnesses[0])
    pop_size = len(fitnesses)
    fitness = [np.mean([f[i] for f in fitnesses]) for i in range(num_total_cases)]
    return np.argmin(fitness)