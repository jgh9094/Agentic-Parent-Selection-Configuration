import numpy as np

def selection(fitnesses):
    num_total_cases = len(fitnesses[0])
    pop_size = len(fitnesses)
    
    # Calculate average fitness for each individual
    avg_fitness = [np.mean(individual) for individual in fitnesses]
    
    # Normalize the average fitness values to ensure they are between 0 and 1
    max_avg_fitness = max(avg_fitness)
    if max_avg_fitness != 0:
        avg_fitness = [f / max_avg_fitness for f in avg_fitness]
        
    # Select parent based on roulette wheel selection
    cumulative_probabilities = np.cumsum(avg_fitness)
    r = np.random.rand()
    index = np.where(cumulative_probabilities >= r)[0][0]
    
    return index