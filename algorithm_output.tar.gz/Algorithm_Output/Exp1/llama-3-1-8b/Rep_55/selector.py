import numpy as np

def selection(fitnesses):
    num_total_cases = len(fitnesses[0])
    pop_size = len(fitnesses)
    
    # Calculate average fitness for each individual
    avg_fitness = [np.mean(individual) for individual in fitnesses]
    
    # Normalize the average fitness values to be between 0 and 1
    max_avg_fitness = max(avg_fitness)
    normalized_avg_fitness = [avg / max_avg_fitness if max_avg_fitness != 0 else 0 for avg in avg_fitness]
    
    # Calculate cumulative sum of normalized average fitness values
    cum_sum_normalized_avg_fitness = np.cumsum(normalized_avg_fitness)
    
    # Generate a random number between 0 and total population size
    rand_num = np.random.rand() * pop_size
    
    # Find the index of the first element in the cumulative sum that is greater than or equal to the random number
    parent_index = np.where(cum_sum_normalized_avg_fitness >= rand_num)[0][0]
    
    return parent_index