import numpy as np

def selection(fitnesses):
    num_total_cases = len(fitnesses[0])
    pop_size = len(fitnesses)
    
    # Calculate average fitness for each individual
    avg_fitness = [np.mean(individual) for individual in fitnesses]
    
    # Normalize the average fitness values to ensure they are between 0 and 1
    max_avg_fitness = np.max(avg_fitness)
    normalized_avg_fitness = [avg / max_avg_fitness if max_avg_fitness != 0 else 0.5 for avg in avg_fitness]
    
    # Use roulette wheel selection based on normalized average fitness
    cumulative_probabilities = [sum(normalized_avg_fitness[:i+1]) for i in range(pop_size)]
    selected_index = np.random.choice(pop_size, p=cumulative_probabilities)
    
    return selected_index