def selection(fitnesses):
    import numpy as np
    num_total_cases = len(fitnesses[0])
    pop_size = len(fitnesses)
    error_sums = np.array([sum(ind) for ind in fitnesses])
    fitness = 1.0 / (1.0 + error_sums)
    total_fitness = np.sum(fitness)
    if total_fitness == 0:
        return np.random.randint(pop_size)
    probs = fitness / total_fitness
    cumulative = np.cumsum(probs)
    r = np.random.rand()
    idx = np.searchsorted(cumulative, r)
    return int(idx)