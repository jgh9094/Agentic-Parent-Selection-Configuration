def selection(fitnesses):
    import numpy as np
    num_total_cases = len(fitnesses[0])
    pop_size = len(fitnesses)
    errors = np.array(fitnesses, dtype=float)
    mean_errors = np.mean(errors, axis=1)
    fitness = 1.0 / (1.0 + mean_errors)
    total_fitness = np.sum(fitness)
    r = np.random.rand() * total_fitness
    cumulative = np.cumsum(fitness)
    parent_index = np.searchsorted(cumulative, r)
    return int(parent_index)