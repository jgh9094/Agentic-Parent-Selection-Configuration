import numpy as np
def selection(fitnesses):
    num_total_cases = len(fitnesses[0])
    pop_size = len(fitnesses)
    errors_sum = np.array([sum(f) for f in fitnesses], dtype=np.float64)
    fitness = 1.0 / (errors_sum + 1e-6)
    probs = fitness / fitness.sum()
    return int(np.random.choice(pop_size, p=probs))