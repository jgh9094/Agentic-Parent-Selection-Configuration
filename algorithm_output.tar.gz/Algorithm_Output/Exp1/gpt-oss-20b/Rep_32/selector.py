import numpy as np
def selection(fitnesses):
    num_total_cases = len(fitnesses[0])
    pop_size = len(fitnesses)
    errors = np.sum(np.array(fitnesses), axis=1)
    idx1, idx2 = np.random.randint(0, pop_size, size=2)
    return idx1 if errors[idx1] < errors[idx2] else idx2