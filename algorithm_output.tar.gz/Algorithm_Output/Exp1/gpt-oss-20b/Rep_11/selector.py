import numpy as np
def selection(fitnesses):
    import numpy as np
    num_total_cases = len(fitnesses[0])
    pop_size = len(fitnesses)
    if pop_size == 0:
        return -1
    total_errors = np.array([sum(f) for f in fitnesses])
    tournament_size = min(3, pop_size)
    indices = np.random.randint(0, pop_size, size=tournament_size)
    best_idx = indices[np.argmin(total_errors[indices])]
    return int(best_idx)