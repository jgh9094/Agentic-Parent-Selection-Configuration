def selection(fitnesses):
    import numpy as np
    num_total_cases = len(fitnesses[0])
    pop_size = len(fitnesses)
    total_errors = [sum(individual_errors) for individual_errors in fitnesses]
    i1, i2 = np.random.randint(pop_size, size=2)
    if total_errors[i1] < total_errors[i2]:
        return i1
    elif total_errors[i2] < total_errors[i1]:
        return i2
    else:
        return np.random.choice([i1, i2])