import numpy as np
def selection(fitnesses):
    num_total_cases = len(fitnesses[0])
    pop_size = len(fitnesses)
    errors = np.array(fitnesses, dtype=float)
    total_errors = errors.sum(axis=1)
    fitness = 1.0 / (total_errors + 1e-9)
    if fitness.sum() == 0:
        probs = np.full(pop_size, 1.0 / pop_size)
    else:
        probs = fitness / fitness.sum()
    return int(np.random.choice(pop_size, p=probs))