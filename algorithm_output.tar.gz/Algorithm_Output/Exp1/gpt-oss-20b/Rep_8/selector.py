import numpy as np

def selection(fitnesses):
    num_total_cases = len(fitnesses[0])
    pop_size = len(fitnesses)
    total_errors = np.sum(np.array(fitnesses), axis=1)
    tournament_size = min(3, pop_size)
    indices = np.random.choice(pop_size, size=tournament_size, replace=False)
    best_idx = indices[np.argmin(total_errors[indices])]
    return int(best_idx)