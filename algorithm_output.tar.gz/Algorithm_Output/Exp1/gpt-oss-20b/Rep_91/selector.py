def selection(fitnesses):
    import numpy as np
    num_total_cases = len(fitnesses[0])
    pop_size = len(fitnesses)
    errors = np.array([sum(ind) for ind in fitnesses])
    eps = 1e-8
    fitness = 1.0 / (errors + eps)
    probs = fitness / fitness.sum()
    idx = np.random.choice(pop_size, p=probs)
    return idx