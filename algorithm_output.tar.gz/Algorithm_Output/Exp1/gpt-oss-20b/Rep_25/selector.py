import numpy as np

def selection(fitnesses):
    import numpy as np
    num_total_cases = len(fitnesses[0])
    pop_size = len(fitnesses)
    errors = np.array([sum(f) for f in fitnesses], dtype=float)
    eps = 1e-12
    inv_errors = 1.0 / (errors + eps)
    probs = inv_errors / np.sum(inv_errors)
    idx = np.random.choice(pop_size, p=probs)
    return idx