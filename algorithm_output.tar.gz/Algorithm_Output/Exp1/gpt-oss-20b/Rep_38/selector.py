def selection(fitnesses):
    import numpy as np
    num_total_cases = len(fitnesses[0])
    pop_size = len(fitnesses)
    total_errors = np.array([sum(f) for f in fitnesses])
    k = 3
    best_idx = None
    best_error = float('inf')
    for _ in range(k):
        idx = np.random.randint(pop_size)
        err = total_errors[idx]
        if err < best_error:
            best_error = err
            best_idx = idx
    return best_idx