def selection(fitnesses):
    import numpy as np
    num_total_cases = len(fitnesses[0])
    pop_size = len(fitnesses)
    if pop_size == 0:
        raise ValueError("Empty population")
    # Compute mean error for each individual
    mean_errors = np.array([np.mean(f) for f in fitnesses])
    # Tournament selection
    k = min(3, pop_size)
    candidates = np.random.randint(0, pop_size, size=k)
    best = candidates[0]
    best_error = mean_errors[best]
    for idx in candidates[1:]:
        if mean_errors[idx] < best_error:
            best = idx
            best_error = mean_errors[idx]
    return best