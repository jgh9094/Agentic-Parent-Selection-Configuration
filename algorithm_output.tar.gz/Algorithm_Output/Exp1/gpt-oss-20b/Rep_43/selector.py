def selection(fitnesses):
    import numpy as np
    num_total_cases = len(fitnesses[0])
    pop_size = len(fitnesses)
    errors = np.array([sum(f) for f in fitnesses])
    i1, i2 = np.random.randint(0, pop_size, size=2)
    return int(i1 if errors[i1] < errors[i2] else i2)