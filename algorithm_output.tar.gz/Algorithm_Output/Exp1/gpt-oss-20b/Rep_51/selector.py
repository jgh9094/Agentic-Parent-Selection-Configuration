def selection(fitnesses):
    import numpy as np
    pop_size = len(fitnesses)
    if pop_size == 0:
        return None
    # Tournament selection with size 3
    tournament_size = 3
    best_idx = None
    best_error = None
    for _ in range(tournament_size):
        idx = np.random.randint(pop_size)
        error = sum(fitnesses[idx])
        if best_idx is None or error < best_error:
            best_idx = idx
            best_error = error
    return best_idx