import numpy as np
def selection(fitnesses):
    num_total_cases = len(fitnesses[0])
    pop_size = len(fitnesses)
    sums = np.sum(fitnesses, axis=1)
    fitness = 1.0 / (sums + 1e-6)
    cumulative = np.cumsum(fitness)
    total = cumulative[-1]
    r = np.random.rand() * total
    idx = np.searchsorted(cumulative, r)
    return int(idx)