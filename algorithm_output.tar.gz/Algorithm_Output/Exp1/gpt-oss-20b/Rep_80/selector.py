import numpy as np

def selection(fitnesses):
    num_total_cases = len(fitnesses[0])
    pop_size = len(fitnesses)
    errors = np.array([sum(ind) for ind in fitnesses], dtype=float)
    eps = 1e-12
    fitness = 1.0 / (errors + eps)
    probs = fitness / fitness.sum()
    return int(np.random.choice(pop_size, p=probs))