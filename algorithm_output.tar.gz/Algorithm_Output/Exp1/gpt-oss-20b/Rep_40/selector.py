def selection(fitnesses):
    import numpy as np
    num_total_cases = len(fitnesses[0])
    pop_size = len(fitnesses)
    if pop_size == 0:
        raise ValueError("Empty population")
    if pop_size == 1:
        return 0
    total_errors = np.array([sum(f) for f in fitnesses])
    i1, i2 = np.random.randint(0, pop_size, size=2)
    return i1 if total_errors[i1] < total_errors[i2] else i2