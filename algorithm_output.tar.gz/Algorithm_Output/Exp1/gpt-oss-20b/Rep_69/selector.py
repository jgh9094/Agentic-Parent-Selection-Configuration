def selection(fitnesses):
    import numpy as np
    num_total_cases = len(fitnesses[0])
    pop_size = len(fitnesses)
    errors = np.array([sum(ind) for ind in fitnesses], dtype=float)
    fitness = 1.0 / (1.0 + errors)
    probs = fitness / fitness.sum()
    idx = np.random.choice(pop_size, p=probs)
    return idx