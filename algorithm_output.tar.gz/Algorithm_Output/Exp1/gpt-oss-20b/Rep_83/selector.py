def selection(fitnesses):
    import numpy as np
    num_total_cases = len(fitnesses[0])
    pop_size = len(fitnesses)
    total_errors = np.array([sum(f) for f in fitnesses], dtype=float)
    fitness = 1.0 / (total_errors + 1e-12)
    probabilities = fitness / fitness.sum()
    selected_index = np.random.choice(pop_size, p=probabilities)
    return int(selected_index)