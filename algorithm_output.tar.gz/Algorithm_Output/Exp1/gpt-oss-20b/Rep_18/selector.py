def selection(fitnesses):
    import numpy as np
    num_total_cases = len(fitnesses[0])
    pop_size = len(fitnesses)
    errors = np.array([sum(f) for f in fitnesses])
    k = 3
    if pop_size < k:
        k = pop_size
    candidates = np.random.choice(pop_size, k, replace=False)
    best = candidates[0]
    best_err = errors[best]
    for idx in candidates[1:]:
        if errors[idx] < best_err:
            best = idx
            best_err = errors[idx]
    return best