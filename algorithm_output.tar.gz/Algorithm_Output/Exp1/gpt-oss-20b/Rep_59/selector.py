def selection(fitnesses):
    import numpy as np
    num_total_cases = len(fitnesses[0])
    pop_size = len(fitnesses)
    total_errors = np.sum(np.array(fitnesses), axis=1)
    tournament_size = 3
    if pop_size < tournament_size:
        tournament_size = pop_size
    tournament_indices = np.random.choice(pop_size, size=tournament_size, replace=(pop_size < tournament_size))
    best_index = tournament_indices[np.argmin(total_errors[tournament_indices])]
    return int(best_index)