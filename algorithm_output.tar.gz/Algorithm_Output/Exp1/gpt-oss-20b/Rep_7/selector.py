def selection(fitnesses):
    import numpy as np
    num_total_cases = len(fitnesses[0])
    pop_size = len(fitnesses)
    arr = np.array(fitnesses)
    total_errors = arr.sum(axis=1)
    k = 3 if pop_size >= 3 else pop_size
    indices = np.random.randint(0, pop_size, size=k)
    best_idx = indices[np.argmin(total_errors[indices])]
    return int(best_idx)