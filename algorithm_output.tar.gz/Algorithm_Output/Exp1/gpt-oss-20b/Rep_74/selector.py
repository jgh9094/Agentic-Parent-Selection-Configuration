def selection(fitnesses):
    import numpy as np
    num_total_cases = len(fitnesses[0])
    pop_size = len(fitnesses)
    arr = np.array(fitnesses)
    sums = np.sum(arr, axis=1)
    tournament_size = min(3, pop_size)
    inds = np.random.randint(0, pop_size, size=tournament_size)
    best = inds[np.argmin(sums[inds])]
    return int(best)