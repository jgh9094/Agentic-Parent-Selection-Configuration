def selection(fitnesses):
    import numpy as np
    num_total_cases = len(fitnesses[0])
    pop_size = len(fitnesses)
    total_errors = np.array([sum(individual) for individual in fitnesses])
    if pop_size <= 3:
        tournament_indices = np.arange(pop_size)
    else:
        tournament_indices = np.random.choice(pop_size, size=3, replace=False)
    best_index = tournament_indices[np.argmin(total_errors[tournament_indices])]
    return int(best_index)