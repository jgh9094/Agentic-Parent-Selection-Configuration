def selection(fitnesses):
    import numpy as np
    num_total_cases = len(fitnesses[0])
    pop_size = len(fitnesses)
    errors = np.array([sum(ind) for ind in fitnesses], dtype=float)
    eps = 1e-12
    fitness = 1.0 / (errors + eps)
    probs = fitness / fitness.sum()
    idx = np.random.choice(pop_size, p=probs)
    return int(idx)