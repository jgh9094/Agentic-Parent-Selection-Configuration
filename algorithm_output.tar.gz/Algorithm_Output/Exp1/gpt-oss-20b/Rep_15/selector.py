def selection(fitnesses):
    import numpy as np
    num_total_cases = len(fitnesses[0])
    pop_size = len(fitnesses)
    total_errors = np.array([sum(ind) for ind in fitnesses])
    i1 = np.random.randint(pop_size)
    i2 = np.random.randint(pop_size)
    return i1 if total_errors[i1] < total_errors[i2] else i2