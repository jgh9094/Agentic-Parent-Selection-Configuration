def selection(fitnesses):
    import numpy as np
    num_total_cases = len(fitnesses[0])
    pop_size = len(fitnesses)
    if pop_size == 0:
        return None
    if pop_size == 1:
        return 0
    errors = np.array([sum(f) for f in fitnesses])
    i1 = np.random.randint(pop_size)
    i2 = np.random.randint(pop_size)
    return i1 if errors[i1] < errors[i2] else i2