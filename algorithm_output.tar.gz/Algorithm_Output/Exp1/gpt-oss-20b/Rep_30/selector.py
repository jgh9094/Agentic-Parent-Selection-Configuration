def selection(fitnesses):
    import numpy as np
    num_total_cases = len(fitnesses[0])
    pop_size = len(fitnesses)
    errors = np.array([sum(f) for f in fitnesses])
    k = 3
    if pop_size < k:
        k = pop_size
    idxs = np.random.randint(0, pop_size, size=k)
    best_idx = idxs[0]
    best_err = errors[best_idx]
    for idx in idxs[1:]:
        if errors[idx] < best_err:
            best_err = errors[idx]
            best_idx = idx
    return int(best_idx)