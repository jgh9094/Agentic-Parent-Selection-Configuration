def selection(fitnesses):
    import numpy as np
    num_total_cases = len(fitnesses[0])
    pop_size = len(fitnesses)
    total_errors = np.array([sum(ind) for ind in fitnesses], dtype=np.float64)
    epsilon = 1e-12
    fitness = 1.0 / (total_errors + epsilon)
    cum = np.cumsum(fitness)
    r = np.random.rand() * cum[-1]
    idx = np.searchsorted(cum, r)
    return int(idx)