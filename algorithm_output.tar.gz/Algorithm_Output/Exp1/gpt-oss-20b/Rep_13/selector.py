def selection(fitnesses):
    import numpy as np
    num_total_cases = len(fitnesses[0]) if fitnesses else 0
    pop_size = len(fitnesses)
    if pop_size == 0:
        return None
    total_errors = np.array([sum(f) for f in fitnesses])
    tournament_size = 3
    if pop_size < tournament_size:
        tournament_size = pop_size
    indices = np.random.randint(0, pop_size, size=tournament_size)
    best_idx = indices[np.argmin(total_errors[indices])]
    return int(best_idx)