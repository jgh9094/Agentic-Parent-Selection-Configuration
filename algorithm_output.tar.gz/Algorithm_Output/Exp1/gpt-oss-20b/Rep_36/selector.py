def selection(fitnesses):
    import numpy as np
    num_total_cases = len(fitnesses[0])
    pop_size = len(fitnesses)
    error_sums = np.array([sum(individual) for individual in fitnesses], dtype=float)
    fitness_values = 1.0 / (1.0 + error_sums)
    total_fitness = np.sum(fitness_values)
    if total_fitness == 0:
        probabilities = np.full(pop_size, 1.0 / pop_size)
    else:
        probabilities = fitness_values / total_fitness
    chosen_index = np.random.choice(pop_size, p=probabilities)
    return int(chosen_index)