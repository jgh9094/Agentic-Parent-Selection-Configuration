def selection(fitnesses):
    import numpy as np
    pop_size = len(fitnesses)
    total_errors = np.array([sum(f) for f in fitnesses])
    i1, i2 = np.random.randint(0, pop_size, size=2)
    return i1 if total_errors[i1] < total_errors[i2] else i2