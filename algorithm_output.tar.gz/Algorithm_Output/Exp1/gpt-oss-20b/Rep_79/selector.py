def selection(fitnesses):
    import numpy as np
    num_total_cases = len(fitnesses[0])
    pop_size = len(fitnesses)
    # Compute total error for each individual
    total_errors = np.array([sum(ind) for ind in fitnesses])
    # Tournament selection with k=3
    k = 3
    if pop_size <= k:
        # If population smaller than tournament size, pick best overall
        return int(np.argmin(total_errors))
    # Randomly pick k distinct indices
    indices = np.random.choice(pop_size, size=k, replace=False)
    # Find the index with the lowest error among the chosen
    best_idx = indices[np.argmin(total_errors[indices])]
    return int(best_idx)