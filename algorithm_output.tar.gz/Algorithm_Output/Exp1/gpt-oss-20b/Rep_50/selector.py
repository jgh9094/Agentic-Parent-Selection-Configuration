def selection(fitnesses):
    import numpy as np
    pop_size = len(fitnesses)
    num_total_cases = len(fitnesses[0]) if pop_size > 0 else 0
    total_errors = np.array([sum(ind) for ind in fitnesses])
    tsize = 3
    if pop_size < tsize:
        tsize = pop_size
    indices = np.random.randint(0, pop_size, size=tsize)
    best_idx = indices[np.argmin(total_errors[indices])]
    return int(best_idx)