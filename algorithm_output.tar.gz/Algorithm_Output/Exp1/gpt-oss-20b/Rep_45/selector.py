import numpy as np
def selection(fitnesses):
    import numpy as np
    num_total_cases = len(fitnesses[0])
    pop_size = len(fitnesses)
    total_errors = np.array([sum(f) for f in fitnesses])
    epsilon = 1e-8
    fitness = 1.0 / (total_errors + epsilon)
    probabilities = fitness / fitness.sum()
    parent_index = np.random.choice(pop_size, p=probabilities)
    return parent_index