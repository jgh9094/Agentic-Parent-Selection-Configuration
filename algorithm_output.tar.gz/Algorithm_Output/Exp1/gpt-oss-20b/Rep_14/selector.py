def selection(fitnesses):
    import numpy as np
    num_total_cases = len(fitnesses[0])
    pop_size = len(fitnesses)
    error_sums = [sum(fitnesses[i]) for i in range(pop_size)]
    k = min(3, pop_size)
    idxs = np.random.randint(0, pop_size, size=k)
    best = min(idxs, key=lambda i: error_sums[i])
    return best