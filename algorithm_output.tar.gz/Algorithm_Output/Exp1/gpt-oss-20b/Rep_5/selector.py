import numpy as np
def selection(fitnesses):
    num_total_cases = len(fitnesses[0])
    pop_size = len(fitnesses)
    total_errors = [sum(fitnesses[i]) for i in range(pop_size)]
    tournament_size = 3
    if pop_size <= tournament_size:
        return int(np.argmin(total_errors))
    indices = np.random.choice(pop_size, size=tournament_size, replace=False)
    best = min(indices, key=lambda idx: total_errors[idx])
    return int(best)