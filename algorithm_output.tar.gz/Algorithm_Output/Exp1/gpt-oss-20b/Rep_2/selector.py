def selection(fitnesses):
    import numpy as np
    num_total_cases = len(fitnesses[0])
    pop_size = len(fitnesses)
    errors = np.array(fitnesses)
    total_errors = np.sum(errors, axis=1)
    eps = 1e-8
    fitness = 1.0 / (total_errors + eps)
    probs = fitness / np.sum(fitness)
    return int(np.random.choice(pop_size, p=probs))