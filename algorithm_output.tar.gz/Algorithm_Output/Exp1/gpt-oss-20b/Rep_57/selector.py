def selection(fitnesses):
    import numpy as np
    num_total_cases = len(fitnesses[0])
    pop_size = len(fitnesses)
    errors = np.array(fitnesses, dtype=float)
    mean_errors = np.mean(errors, axis=1)
    fitness = 1.0 / (1.0 + mean_errors)
    probs = fitness / np.sum(fitness)
    selected = np.random.choice(pop_size, p=probs)
    return int(selected)