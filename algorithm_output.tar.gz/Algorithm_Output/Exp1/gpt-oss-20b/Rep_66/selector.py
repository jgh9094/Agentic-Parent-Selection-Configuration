def selection(fitnesses):
    import numpy as np
    num_total_cases = len(fitnesses[0])
    pop_size = len(fitnesses)
    # Aggregate error per individual (sum of absolute errors)
    aggregated_errors = np.array([sum(individual) for individual in fitnesses])
    # Tournament selection
    tournament_size = 3
    if pop_size <= tournament_size:
        tournament_indices = np.arange(pop_size)
    else:
        tournament_indices = np.random.choice(pop_size, size=tournament_size, replace=False)
    best_idx = tournament_indices[np.argmin(aggregated_errors[tournament_indices])]
    return int(best_idx)