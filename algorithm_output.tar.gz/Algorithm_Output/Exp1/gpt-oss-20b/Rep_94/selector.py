def selection(fitnesses):
    import numpy as np
    num_total_cases = len(fitnesses[0])
    pop_size = len(fitnesses)
    # Convert to numpy array for efficient computation
    errors = np.array(fitnesses, dtype=float)
    # Sum errors across all test cases for each individual
    total_errors = errors.sum(axis=1)
    # Tournament selection
    tournament_size = 3
    if pop_size <= tournament_size:
        # If population is too small, just pick the best
        return int(np.argmin(total_errors))
    # Randomly pick tournament participants
    participants = np.random.randint(0, pop_size, size=tournament_size)
    # Find the participant with the lowest total error
    best_idx_in_participants = np.argmin(total_errors[participants])
    return int(participants[best_idx_in_participants])