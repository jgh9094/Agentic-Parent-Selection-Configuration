def selection(fitnesses):
    import numpy as np
    num_total_cases = len(fitnesses[0])
    pop_size = len(fitnesses)
    total_errors = np.array([sum(f) for f in fitnesses])
    fitness = 1.0 / (1.0 + total_errors)
    probs = fitness / fitness.sum()
    return int(np.random.choice(pop_size, p=probs))