import numpy as np
def selection(fitnesses):
    import numpy as np
    num_total_cases = len(fitnesses[0])
    pop_size = len(fitnesses)
    errors = np.array(fitnesses, dtype=float)
    total_error = errors.sum(axis=1)
    fitness = 1.0 / (total_error + 1e-8)
    probs = fitness / fitness.sum()
    idx = np.random.choice(pop_size, p=probs)
    return int(idx)