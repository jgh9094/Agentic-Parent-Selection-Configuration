def selection(fitnesses):
    import numpy as np
    pop_size = len(fitnesses)
    if pop_size == 0:
        return 0
    num_total_cases = len(fitnesses[0]) if pop_size > 0 else 0
    errors = np.array([sum(ind) for ind in fitnesses])
    k = 3
    idxs = np.random.randint(0, pop_size, size=k)
    best_idx = idxs[0]
    best_err = errors[best_idx]
    for idx in idxs[1:]:
        if errors[idx] < best_err:
            best_err = errors[idx]
            best_idx = idx
    return int(best_idx)