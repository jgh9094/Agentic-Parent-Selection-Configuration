def selection(fitnesses):
    import numpy as np
    pop_size = len(fitnesses)
    num_total_cases = len(fitnesses[0])
    errors = np.array(fitnesses, dtype=float)
    total_errors = errors.sum(axis=1)
    tournament_size = 5
    if pop_size <= tournament_size:
        indices = np.arange(pop_size)
    else:
        indices = np.random.choice(pop_size, tournament_size, replace=False)
    best_idx = indices[np.argmin(total_errors[indices])]
    return int(best_idx)