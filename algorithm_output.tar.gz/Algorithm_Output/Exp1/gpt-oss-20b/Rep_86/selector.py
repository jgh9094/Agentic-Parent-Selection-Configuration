import numpy as np
def selection(fitnesses):
    import numpy as np
    num_total_cases = len(fitnesses[0])
    pop_size = len(fitnesses)
    errors = np.array(fitnesses)
    total_errors = np.sum(errors, axis=1)
    idx1, idx2 = np.random.randint(0, pop_size, size=2)
    return int(idx1 if total_errors[idx1] <= total_errors[idx2] else idx2)