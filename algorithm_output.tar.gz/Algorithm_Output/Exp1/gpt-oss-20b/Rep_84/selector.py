def selection(fitnesses):
    import numpy as np
    num_total_cases = len(fitnesses[0])
    pop_size = len(fitnesses)
    errors = np.array([sum(f) for f in fitnesses], dtype=float)
    eps = 1e-12
    inv = 1.0 / (errors + eps)
    if np.isfinite(inv).any():
        probs = inv / inv.sum()
    else:
        probs = np.full(pop_size, 1.0 / pop_size)
    idx = np.random.choice(pop_size, p=probs)
    return idx