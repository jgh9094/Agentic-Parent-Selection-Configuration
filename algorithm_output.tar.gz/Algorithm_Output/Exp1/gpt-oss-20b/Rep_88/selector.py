import numpy as np
def selection(fitnesses):
    num_total_cases = len(fitnesses[0])
    pop_size = len(fitnesses)
    errors = np.array([sum(ind) for ind in fitnesses])
    i1 = np.random.randint(pop_size)
    i2 = np.random.randint(pop_size)
    return i1 if errors[i1] < errors[i2] else i2