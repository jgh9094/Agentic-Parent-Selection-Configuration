import numpy as np
def selection(fitnesses):
    pop_size = len(fitnesses)
    num_total_cases = len(fitnesses[0])
    errors = np.array([sum(f) for f in fitnesses])
    k = 3
    best_idx = None
    best_err = np.inf
    for _ in range(k):
        idx = np.random.randint(pop_size)
        if errors[idx] < best_err:
            best_err = errors[idx]
            best_idx = idx
    return best_idx