def selection(fitnesses):
    import numpy as np
    num_total_cases = len(fitnesses[0])
    pop_size = len(fitnesses)
    total_errors = np.array([sum(ind) for ind in fitnesses], dtype=float)
    eps = 1e-8
    fitness = 1.0 / (total_errors + eps)
    total_fitness = np.sum(fitness)
    if total_fitness == 0:
        probs = np.full(pop_size, 1.0 / pop_size)
    else:
        probs = fitness / total_fitness
    idx = np.random.choice(pop_size, p=probs)
    return int(idx)