def selection(fitnesses):
    import numpy as np
    num_total_cases = len(fitnesses[0])
    pop_size = len(fitnesses)
    errors = np.array(fitnesses)
    total_error = np.sum(errors, axis=1)
    idx1, idx2 = np.random.randint(0, pop_size, size=2)
    return idx1 if total_error[idx1] <= total_error[idx2] else idx2