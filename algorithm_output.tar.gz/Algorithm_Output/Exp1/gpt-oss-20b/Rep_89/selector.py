def selection(fitnesses):
    import numpy as np
    num_total_cases = len(fitnesses[0])
    pop_size = len(fitnesses)
    total_errors = np.array([sum(ind) for ind in fitnesses], dtype=float)
    fitness = 1.0 / (1.0 + total_errors)
    fitness_sum = fitness.sum()
    if fitness_sum == 0:
        return np.random.randint(pop_size)
    probs = fitness / fitness_sum
    return int(np.random.choice(pop_size, p=probs))