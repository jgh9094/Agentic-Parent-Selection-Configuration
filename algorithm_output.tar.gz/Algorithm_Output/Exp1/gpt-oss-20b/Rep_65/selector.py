def selection(fitnesses):
    import numpy as np
    num_total_cases = len(fitnesses[0])
    pop_size = len(fitnesses)
    total_errors = np.array([sum(errors) for errors in fitnesses])
    fitness = 1.0 / (1.0 + total_errors)
    probs = fitness / fitness.sum()
    parent_index = np.random.choice(pop_size, p=probs)
    return parent_index