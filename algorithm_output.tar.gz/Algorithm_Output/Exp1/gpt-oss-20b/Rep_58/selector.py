def selection(fitnesses):
    import numpy as np
    num_total_cases = len(fitnesses[0])
    pop_size = len(fitnesses)
    # Tournament selection of size 2
    i1 = np.random.randint(pop_size)
    i2 = np.random.randint(pop_size)
    sum1 = sum(fitnesses[i1])
    sum2 = sum(fitnesses[i2])
    return i1 if sum1 < sum2 else i2