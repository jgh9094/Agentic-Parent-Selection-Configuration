def selection(fitnesses):
    import numpy as np
    num_total_cases = len(fitnesses[0])
    pop_size = len(fitnesses)
    total_errors = np.array([sum(f) for f in fitnesses])
    tsize = min(3, pop_size)
    indices = np.random.randint(0, pop_size, size=tsize)
    best = indices[0]
    best_error = total_errors[best]
    for idx in indices[1:]:
        if total_errors[idx] < best_error:
            best = idx
            best_error = total_errors[idx]
    return int(best)