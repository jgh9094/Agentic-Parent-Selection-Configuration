def selection(fitnesses):
    import numpy as np
    pop_size = len(fitnesses)
    num_total_cases = len(fitnesses[0])
    errors = np.sum(fitnesses, axis=1)
    tournament_size = 3
    if pop_size <= tournament_size:
        indices = np.arange(pop_size)
    else:
        indices = np.random.choice(pop_size, size=tournament_size, replace=False)
    best_index = indices[np.argmin(errors[indices])]
    return int(best_index)