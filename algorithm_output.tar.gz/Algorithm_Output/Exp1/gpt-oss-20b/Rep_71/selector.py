def selection(fitnesses):
    import numpy as np
    # Convert to numpy array for vectorized operations
    errors = np.array(fitnesses, dtype=float)
    # Compute total error per individual
    total_errors = np.sum(errors, axis=1)
    # Compute fitness values (higher fitness for lower error)
    fitness = 1.0 / (1.0 + total_errors)
    # Normalize to probabilities
    probs = fitness / np.sum(fitness)
    # Randomly select one parent index based on probabilities
    parent_index = np.random.choice(len(fitness), p=probs)
    return int(parent_index)