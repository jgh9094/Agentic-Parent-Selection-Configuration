def selection(fitnesses):
    import numpy as np
    num_total_cases = len(fitnesses[0])
    pop_size = len(fitnesses)
    idx1, idx2 = np.random.randint(0, pop_size, size=2)
    err1 = sum(fitnesses[idx1])
    err2 = sum(fitnesses[idx2])
    if err1 < err2:
        return idx1
    elif err2 < err1:
        return idx2
    else:
        return idx1 if np.random.rand() < 0.5 else idx2