def selection(fitnesses):
    import numpy as np
    num_total_cases = len(fitnesses[0])
    pop_size = len(fitnesses)
    errors = np.array(fitnesses)
    total_errors = errors.sum(axis=1)
    k = 3
    if pop_size < k:
        k = pop_size
    rng = np.random.default_rng()
    tournament_indices = rng.choice(pop_size, size=k, replace=False)
    best_idx_in_tournament = tournament_indices[np.argmin(total_errors[tournament_indices])]
    return int(best_idx_in_tournament)