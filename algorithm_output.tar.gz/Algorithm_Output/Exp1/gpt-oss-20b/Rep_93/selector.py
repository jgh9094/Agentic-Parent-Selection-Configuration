def selection(fitnesses):
    import numpy as np
    num_total_cases = len(fitnesses[0])
    pop_size = len(fitnesses)
    errors = np.array([sum(ind) for ind in fitnesses])
    i1, i2 = np.random.randint(0, pop_size, size=2)
    if errors[i1] < errors[i2]:
        return int(i1)
    else:
        return int(i2)