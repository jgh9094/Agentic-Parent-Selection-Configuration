def selection(fitnesses):
    import numpy as np
    pop_size = len(fitnesses)
    num_total_cases = len(fitnesses[0]) if pop_size > 0 else 0
    total_errors = np.array([sum(ind) for ind in fitnesses])
    tsize = 3 if pop_size >= 3 else pop_size
    indices = np.random.randint(0, pop_size, size=tsize)
    best = indices[0]
    best_error = total_errors[best]
    for idx in indices[1:]:
        if total_errors[idx] < best_error:
            best = idx
            best_error = total_errors[idx]
    return int(best)