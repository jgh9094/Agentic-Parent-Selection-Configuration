import numpy as np
def selection(fitnesses):
    import numpy as np
    num_total_cases = len(fitnesses[0])
    pop_size = len(fitnesses)
    # Compute total error for each individual (lower is better)
    total_errors = np.array([sum(ind) for ind in fitnesses])
    # Tournament selection of size 3
    tournament_size = 3
    if pop_size < tournament_size:
        tournament_size = pop_size
    # Randomly pick tournament_size indices
    candidates = np.random.randint(0, pop_size, size=tournament_size)
    # Find candidate with minimum error
    best_idx = candidates[np.argmin(total_errors[candidates])]
    return int(best_idx)