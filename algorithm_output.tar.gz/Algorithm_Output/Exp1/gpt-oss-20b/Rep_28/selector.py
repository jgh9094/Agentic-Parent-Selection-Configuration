import numpy as np

def selection(fitnesses):
    num_total_cases = len(fitnesses[0])
    pop_size = len(fitnesses)
    if pop_size == 0:
        raise ValueError("Empty population")
    # Compute mean error for each individual
    mean_errors = np.array([np.mean(f) for f in fitnesses])
    # Tournament selection
    k = 3
    if pop_size < k:
        k = pop_size
    indices = np.random.randint(0, pop_size, size=k)
    best_idx = indices[np.argmin(mean_errors[indices])]
    return int(best_idx)