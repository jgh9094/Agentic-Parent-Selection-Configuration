def selection(fitnesses):
    import numpy as np
    num_total_cases = len(fitnesses[0])
    pop_size = len(fitnesses)
    fitness_sum = [sum(individual) for individual in fitnesses]
    min_fitness = min(fitness_sum)
    if min_fitness <= 0:
        probabilities = [(1 / (x + 1)) if x != 0 else 1 for x in fitness_sum]
    else:
        probabilities = [(1 / x) if x != 0 else 1 for x in fitness_sum]
    probabilities = np.array(probabilities) / sum(probabilities)
    return np.random.choice(pop_size, p=probabilities)