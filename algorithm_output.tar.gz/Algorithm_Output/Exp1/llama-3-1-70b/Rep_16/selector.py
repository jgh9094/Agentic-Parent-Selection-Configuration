def selection(fitnesses):
    import numpy as np
    num_total_cases = len(fitnesses[0])
    pop_size = len(fitnesses)
    
    # Calculate the sum of errors for each individual
    total_errors = [sum(individual) for individual in fitnesses]
    
    # Calculate the probability of selection for each individual based on its total error
    probabilities = np.array([1 / (error + 1e-10) for error in total_errors])
    probabilities /= probabilities.sum()
    
    # Select one parent using roulette wheel selection
    selected_index = np.random.choice(range(pop_size), p=probabilities)
    
    return selected_index