def selection(fitnesses):
    import numpy as np
    num_total_cases = len(fitnesses[0])
    pop_size = len(fitnesses)
    
    # Calculate average error for each individual
    avg_errors = [np.mean(individual) for individual in fitnesses]
    
    # Select parent using tournament selection with a tournament size of 5
    tournament_size = 5
    selected_indices = np.random.choice(pop_size, size=tournament_size, replace=False)
    selected_avg_errors = [avg_errors[i] for i in selected_indices]
    winner_index = selected_indices[np.argmin(selected_avg_errors)]
    
    return winner_index