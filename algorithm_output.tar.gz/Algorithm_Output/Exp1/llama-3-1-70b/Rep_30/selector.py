import numpy as np
def selection(fitnesses):
    num_total_cases = len(fitnesses[0])
    pop_size = len(fitnesses)
    fitness_sum = [sum(individual) for individual in fitnesses]
    total_fitness = sum(fitness_sum)
    probabilities = [(total_fitness - fit) / (pop_size * total_fitness - sum(fitness_sum)) for fit in fitness_sum]
    selected_index = np.random.choice(range(pop_size), p=probabilities)
    return selected_index