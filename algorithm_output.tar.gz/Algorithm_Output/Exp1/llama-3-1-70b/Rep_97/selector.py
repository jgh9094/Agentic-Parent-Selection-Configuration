def selection(fitnesses):
    import numpy as np
    num_total_cases = len(fitnesses[0])
    pop_size = len(fitnesses)
    fitness_values = [np.sum(individual) for individual in fitnesses]
    min_fitness_value = min(fitness_values)
    if min_fitness_value < 0:
        raise ValueError("Fitness values should be non-negative")
    total_fitness = sum(fitness_values)
    probabilities = [(total_fitness - value) / total_fitness for value in fitness_values]
    selected_index = np.random.choice(pop_size, p=probabilities)
    return int(selected_index)