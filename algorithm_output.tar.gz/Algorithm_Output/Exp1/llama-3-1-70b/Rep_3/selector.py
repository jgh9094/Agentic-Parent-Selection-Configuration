def selection(fitnesses):
    import numpy as np
    num_total_cases = len(fitnesses[0])
    pop_size = len(fitnesses)
    total_errors = [sum(individual) for individual in fitnesses]
    min_error = min(total_errors)
    if min_error == 0:
        return np.argmin(total_errors)
    else:
        probabilities = [(1 / (error + 1e-10)) / sum(1 / (e + 1e-10) for e in total_errors) for error in total_errors]
        return np.random.choice(range(pop_size), p=probabilities)