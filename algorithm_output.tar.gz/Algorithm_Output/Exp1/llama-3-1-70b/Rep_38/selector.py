def selection(fitnesses):
    import numpy as np
    num_total_cases = len(fitnesses[0])
    pop_size = len(fitnesses)
    fitness = [np.mean(individual) for individual in fitnesses]
    probabilities = np.array([1 / (f + 1e-10) for f in fitness]) / sum(1 / (f + 1e-10) for f in fitness)
    return np.random.choice(pop_size, p=probabilities)