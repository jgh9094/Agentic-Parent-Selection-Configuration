def selection(fitnesses):
    import numpy as np
    num_total_cases = len(fitnesses[0])
    pop_size = len(fitnesses)
    fitness_sum = [sum(individual) for individual in fitnesses]
    probabilities = np.array([1.0 / (x + 1e-10) for x in fitness_sum]) / sum(1.0 / (x + 1e-10) for x in fitness_sum)
    selected_index = np.random.choice(range(pop_size), p=probabilities)
    return selected_index