def selection(fitnesses):
    import numpy as np
    num_total_cases = len(fitnesses[0])
    pop_size = len(fitnesses)
    total_errors = [sum(individual) for individual in fitnesses]
    min_error = min(total_errors)
    if min_error == 0:
        return np.argmin(total_errors)
    else:
        probabilities = [(1 / (total_error + 1e-10)) ** 2 for total_error in total_errors]
        probabilities = [prob / sum(probabilities) for prob in probabilities]
        selected_index = np.random.choice(pop_size, p=probabilities)
        return selected_index