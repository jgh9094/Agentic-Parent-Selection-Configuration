def selection(fitnesses):
    import numpy as np
    num_total_cases = len(fitnesses[0])
    pop_size = len(fitnesses)
    fitness_sum = [sum(individual) for individual in fitnesses]
    total_fitness = sum(fitness_sum)
    probabilities = [(total_fitness - f) / total_fitness for f in fitness_sum]
    probabilities = np.array(probabilities) / sum(probabilities)
    return np.random.choice(pop_size, p=probabilities)