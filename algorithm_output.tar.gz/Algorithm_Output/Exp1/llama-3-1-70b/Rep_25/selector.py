def selection(fitnesses):
    import numpy as np
    num_total_cases = len(fitnesses[0])
    pop_size = len(fitnesses)
    fitness = [sum(individual) / num_total_cases for individual in fitnesses]
    min_fitness_idx = np.argmin(fitness)
    return min_fitness_idx