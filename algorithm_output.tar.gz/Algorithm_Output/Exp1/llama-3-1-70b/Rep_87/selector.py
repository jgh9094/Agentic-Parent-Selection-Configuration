def selection(fitnesses):
    import numpy as np
    num_total_cases = len(fitnesses[0])
    pop_size = len(fitnesses)
    
    # Calculate average error for each individual
    avg_errors = [np.mean(individual) for individual in fitnesses]
    
    # Select parent using tournament selection with a tournament size of 5
    tournament_size = 5
    if pop_size < tournament_size:
        tournament_size = pop_size
    
    selected_indices = np.random.choice(pop_size, size=tournament_size, replace=False)
    selected_errors = [avg_errors[i] for i in selected_indices]
    
    # Return the index of the individual with the lowest average error in the tournament
    return selected_indices[np.argmin(selected_errors)]