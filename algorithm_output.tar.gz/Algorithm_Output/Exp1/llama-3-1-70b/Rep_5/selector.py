def selection(fitnesses):
    import numpy as np
    num_total_cases = len(fitnesses[0])
    pop_size = len(fitnesses)
    total_errors = [sum(individual) for individual in fitnesses]
    probabilities = np.array([1 / error if error != 0 else 1 for error in total_errors]) / sum(1 / error if error != 0 else 1 for error in total_errors)
    return np.random.choice(pop_size, p=probabilities)