def selection(fitnesses):
    import numpy as np
    num_total_cases = len(fitnesses[0])
    pop_size = len(fitnesses)
    fitness_values = [np.sum(individual) for individual in fitnesses]
    min_fitness_value = min(fitness_values)
    if min_fitness_value <= 0:
        return np.argmin(fitness_values)
    else:
        probabilities = [1 / value for value in fitness_values]
        probabilities /= np.sum(probabilities)
        return np.random.choice(pop_size, p=probabilities)