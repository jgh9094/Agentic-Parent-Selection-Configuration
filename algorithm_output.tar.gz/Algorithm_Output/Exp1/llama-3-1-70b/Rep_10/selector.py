def selection(fitnesses):
    import numpy as np
    num_total_cases = len(fitnesses[0])
    pop_size = len(fitnesses)
    fitness_sum = [sum(individual) for individual in fitnesses]
    probabilities = [(1 / (x + 1)) for x in fitness_sum] # avoid division by zero
    probabilities = np.array(probabilities) / sum(probabilities)
    selected_index = np.random.choice(pop_size, p=probabilities)
    return int(selected_index)