def selection(fitnesses):
    import numpy as np
    num_total_cases = len(fitnesses[0])
    pop_size = len(fitnesses)
    total_errors = [sum(individual) for individual in fitnesses]
    min_error = min(total_errors)
    if min_error == 0:
        best_individuals = [i for i, error in enumerate(total_errors) if error == min_error]
        return np.random.choice(best_individuals)
    else:
        probabilities = [(1 / (error + 1e-10)) ** 2 for error in total_errors]
        probabilities /= np.sum(probabilities)
        return np.random.choice(pop_size, p=probabilities)