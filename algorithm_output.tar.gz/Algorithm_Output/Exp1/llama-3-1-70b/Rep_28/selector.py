def selection(fitnesses):
    import numpy as np
    num_total_cases = len(fitnesses[0])
    pop_size = len(fitnesses)
    fitness_values = [np.sum(individual) for individual in fitnesses]
    probabilities = np.array([1 / (value + 1e-10) for value in fitness_values]) / sum(1 / (value + 1e-10) for value in fitness_values)
    selected_index = np.random.choice(pop_size, p=probabilities)
    return selected_index