def selection(fitnesses):
    import numpy as np
    num_total_cases = len(fitnesses[0])
    pop_size = len(fitnesses)
    fitness = [sum(individual) for individual in fitnesses]
    probs = np.array([1.0 / (f + 1e-10) for f in fitness]) / sum(1.0 / (np.array(fitness) + 1e-10))
    return np.random.choice(pop_size, p=probs)