def selection(fitnesses):
    import numpy as np
    num_total_cases = len(fitnesses[0])
    pop_size = len(fitnesses)
    fitnesses = np.array([np.sum(individual) for individual in fitnesses])
    probabilities = np.exp(-fitnesses) / np.sum(np.exp(-fitnesses))
    return np.random.choice(pop_size, p=probabilities)