def selection(fitnesses):
    import numpy as np
    num_total_cases = len(fitnesses[0])
    pop_size = len(fitnesses)
    total_errors = [sum(individual) for individual in fitnesses]
    probabilities = np.array([1.0 / (error + 1e-10) for error in total_errors]) / sum(1.0 / (np.array(total_errors) + 1e-10))
    selected_index = np.random.choice(range(pop_size), p=probabilities)
    return selected_index