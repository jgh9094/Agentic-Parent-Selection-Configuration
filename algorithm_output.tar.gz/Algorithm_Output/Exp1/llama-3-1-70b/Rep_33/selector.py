def selection(fitnesses):
    import numpy as np
    num_total_cases = len(fitnesses[0])
    pop_size = len(fitnesses)
    fitness_sum = [sum(individual) for individual in fitnesses]
    min_fitness = min(fitness_sum)
    if min_fitness < 0:
        fitness_sum = [x - min_fitness + 1e-10 for x in fitness_sum]
    probabilities = np.array([1 / x for x in fitness_sum])
    probabilities /= probabilities.sum()
    selected_index = np.random.choice(pop_size, p=probabilities)
    return selected_index