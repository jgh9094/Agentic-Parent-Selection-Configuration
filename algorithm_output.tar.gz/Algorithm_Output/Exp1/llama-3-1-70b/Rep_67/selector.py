def selection(fitnesses):
    import numpy as np
    num_total_cases = len(fitnesses[0])
    pop_size = len(fitnesses)
    fitness_sum = [sum(individual) for individual in fitnesses]
    probabilities = np.array([1 / sum_i if sum_i != 0 else 1 for sum_i in fitness_sum]) / sum(1 / sum_i if sum_i != 0 else 1 for sum_i in fitness_sum)
    selected_index = np.random.choice(pop_size, p=probabilities)
    return int(selected_index)