def selection(fitnesses):
    import numpy as np
    num_total_cases = len(fitnesses[0])
    pop_size = len(fitnesses)
    
    # Calculate the average error for each individual
    avg_errors = [np.mean(individual) for individual in fitnesses]
    
    # Use tournament selection with a tournament size of 5
    tournament_size = 5
    tournament_indices = np.random.choice(pop_size, size=tournament_size, replace=False)
    tournament_avg_errors = [avg_errors[i] for i in tournament_indices]
    winner_index = tournament_indices[np.argmin(tournament_avg_errors)]
    
    return winner_index