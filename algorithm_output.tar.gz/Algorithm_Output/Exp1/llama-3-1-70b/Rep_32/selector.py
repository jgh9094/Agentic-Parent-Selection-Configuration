def selection(fitnesses):
    import numpy as np
    num_total_cases = len(fitnesses[0])
    pop_size = len(fitnesses)
    
    # Calculate the mean error for each individual
    mean_errors = [np.mean(individual) for individual in fitnesses]
    
    # Use tournament selection with a tournament size of 5
    tournament_size = 5
    selected_indices = np.random.choice(pop_size, size=tournament_size, replace=False)
    selected_mean_errors = [mean_errors[i] for i in selected_indices]
    winner_index = selected_indices[np.argmin(selected_mean_errors)]
    
    return winner_index