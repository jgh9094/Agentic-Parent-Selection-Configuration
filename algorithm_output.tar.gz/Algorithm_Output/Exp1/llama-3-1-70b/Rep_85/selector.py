def selection(fitnesses):
    import numpy as np
    num_total_cases = len(fitnesses[0])
    pop_size = len(fitnesses)
    fitness_values = [sum(individual) for individual in fitnesses]
    probabilities = np.array([1.0 / (value + 1e-10) for value in fitness_values]) / sum(1.0 / (np.array(fitness_values) + 1e-10))
    selected_index = np.random.choice(pop_size, p=probabilities)
    return int(selected_index)