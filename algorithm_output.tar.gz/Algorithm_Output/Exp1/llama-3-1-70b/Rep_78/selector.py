def selection(fitnesses):
    import numpy as np
    num_total_cases = len(fitnesses[0])
    pop_size = len(fitnesses)
    fitness_sum = [sum(individual) for individual in fitnesses]
    probabilities = np.array([1 / (sum + 1e-10) for sum in fitness_sum]) / sum(1 / (s + 1e-10) for s in fitness_sum)
    return np.random.choice(pop_size, p=probabilities)