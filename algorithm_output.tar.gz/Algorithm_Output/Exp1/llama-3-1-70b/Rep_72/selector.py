def selection(fitnesses):
    import numpy as np
    num_total_cases = len(fitnesses[0])
    pop_size = len(fitnesses)
    fitness_values = [np.mean(individual) for individual in fitnesses]
    min_fitness = min(fitness_values)
    if min_fitness < 0:
        fitness_values = [value - min_fitness + 1e-10 for value in fitness_values]
    probabilities = np.array([1 / value for value in fitness_values])
    probabilities /= probabilities.sum()
    return np.random.choice(pop_size, p=probabilities)