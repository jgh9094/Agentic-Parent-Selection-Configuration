def selection(fitnesses):
    import numpy as np
    num_total_cases = len(fitnesses[0])
    pop_size = len(fitnesses)
    
    # Calculate the total error for each individual
    total_errors = [sum(individual) for individual in fitnesses]
    
    # Use tournament selection with a tournament size of 5
    tournament_size = 5
    if pop_size < tournament_size:
        tournament_size = pop_size
    
    selected_indices = np.random.choice(pop_size, size=tournament_size, replace=False)
    selected_total_errors = [total_errors[i] for i in selected_indices]
    
    # Select the index of the individual with the lowest total error from the tournament
    winner_index = selected_indices[np.argmin(selected_total_errors)]
    
    return winner_index