def selection(fitnesses):
    import numpy as np
    
    num_total_cases = len(fitnesses[0])
    pop_size = len(fitnesses)
    
    # Calculate the mean error for each individual
    mean_errors = [np.mean(individual) for individual in fitnesses]
    
    # Select a parent using tournament selection with a tournament size of 5
    tournament_size = min(5, pop_size)
    selected_indices = np.random.choice(pop_size, size=tournament_size, replace=False)
    selected_mean_errors = [mean_errors[i] for i in selected_indices]
    best_index_in_tournament = np.argmin(selected_mean_errors)
    
    # Return the index of the selected parent
    return selected_indices[best_index_in_tournament]