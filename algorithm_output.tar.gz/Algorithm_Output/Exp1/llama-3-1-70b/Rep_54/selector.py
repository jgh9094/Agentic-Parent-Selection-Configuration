def selection(fitnesses):
    import numpy as np
    num_total_cases = len(fitnesses[0])
    pop_size = len(fitnesses)
    fitness = [sum(individual) / num_total_cases for individual in fitnesses]
    probabilities = np.array([1.0 / (f + 1e-10) for f in fitness]) / sum(1.0 / (f + 1e-10) for f in fitness)
    selected_index = np.random.choice(pop_size, p=probabilities)
    return int(selected_index)