def selection(fitnesses):
    import numpy as np
    
    num_total_cases = len(fitnesses[0])
    pop_size = len(fitnesses)
    
    # Calculate mean fitness for each individual
    mean_errors = np.mean(fitnesses, axis=1)
    
    # Calculate selection probabilities inversely proportional to mean errors
    inverse_errors = 1 / (mean_errors + 1e-10)  # Add small value to avoid division by zero
    probabilities = inverse_errors / np.sum(inverse_errors)
    
    # Select one parent based on probabilities
    selected_index = np.random.choice(np.arange(pop_size), p=probabilities)
    
    return selected_index