def selection(fitnesses):
    import numpy as np
    
    num_total_cases = len(fitnesses[0])
    pop_size = len(fitnesses)
    
    # Calculate the mean error for each individual
    mean_errors = [np.mean(individual) for individual in fitnesses]
    
    # Convert mean errors to fitness values (lower error -> higher fitness)
    fitness_values = 1 / (np.array(mean_errors) + 1e-10)  # Add small value to avoid division by zero
    
    # Normalize fitness values to create a probability distribution
    probabilities = fitness_values / np.sum(fitness_values)
    
    # Select one individual based on probabilities
    selected_index = np.random.choice(pop_size, p=probabilities)
    
    return selected_index