def selection(fitnesses):
    import numpy as np
    
    num_total_cases = len(fitnesses[0])
    pop_size = len(fitnesses)
    
    # Calculate the total error for each individual
    total_errors = [sum(individual) for individual in fitnesses]
    
    # Convert errors to fitness values (lower error -> higher fitness)
    fitness_values = [1 / (error + 1e-10) for error in total_errors]
    
    # Normalize fitness values to create a probability distribution
    probabilities = np.array(fitness_values) / sum(fitness_values)
    
    # Perform roulette wheel selection
    selected_index = np.random.choice(pop_size, p=probabilities)
    
    return selected_index