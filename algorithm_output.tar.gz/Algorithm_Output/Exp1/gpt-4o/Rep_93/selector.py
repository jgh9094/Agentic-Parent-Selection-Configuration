def selection(fitnesses):
    import numpy as np
    
    num_total_cases = len(fitnesses[0])
    pop_size = len(fitnesses)
    
    # Calculate mean error for each individual
    mean_errors = [np.mean(individual_errors) for individual_errors in fitnesses]
    
    # Convert mean errors to fitness scores (lower error -> higher fitness)
    fitness_scores = [1 / (error + 1e-6) for error in mean_errors]
    
    # Normalize fitness scores to create a probability distribution
    total_fitness = sum(fitness_scores)
    probabilities = [score / total_fitness for score in fitness_scores]
    
    # Select one individual index based on probabilities
    selected_index = np.random.choice(range(pop_size), p=probabilities)
    
    return selected_index