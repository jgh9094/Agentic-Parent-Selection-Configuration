def selection(fitnesses):
    import numpy as np
    num_total_cases = len(fitnesses[0])
    pop_size = len(fitnesses)
    total_errors = np.array([sum(individual_errors) for individual_errors in fitnesses])
    probabilities = 1 / (total_errors + 1e-10)
    probabilities /= probabilities.sum()
    return np.random.choice(pop_size, p=probabilities)