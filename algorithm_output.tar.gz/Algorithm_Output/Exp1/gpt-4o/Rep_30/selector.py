def selection(fitnesses):
    import numpy as np
    num_total_cases = len(fitnesses[0])
    pop_size = len(fitnesses)
    fitness_scores = np.sum(fitnesses, axis=1) / num_total_cases
    probabilities = 1 / (fitness_scores + 1e-10)
    probabilities /= np.sum(probabilities)
    return np.random.choice(pop_size, p=probabilities)