def selection(fitnesses):
    import numpy as np
    
    num_total_cases = len(fitnesses[0])
    pop_size = len(fitnesses)
    
    fitness_scores = [np.mean(individual) for individual in fitnesses]
    probabilities = np.array(fitness_scores)
    probabilities = 1 / (probabilities + 1e-10)  # Inverse proportional to error, avoid division by zero
    probabilities /= np.sum(probabilities)  # Normalize to sum to 1
    
    selected_index = np.random.choice(pop_size, p=probabilities)
    return selected_index