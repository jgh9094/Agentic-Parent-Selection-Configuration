def selection(fitnesses):
    import numpy as np
    
    num_total_cases = len(fitnesses[0])
    pop_size = len(fitnesses)
    
    # Calculate mean fitness for each individual
    mean_fitnesses = [np.mean(individual) for individual in fitnesses]
    
    # Convert mean fitness to probabilities (lower mean fitness is better)
    total_fitness = sum(mean_fitnesses)
    probabilities = [(total_fitness - fitness) / (total_fitness * (pop_size - 1)) for fitness in mean_fitnesses]
    
    # Normalize probabilities to sum to 1
    probabilities = probabilities / np.sum(probabilities)
    
    # Select one parent based on probabilities
    selected_index = np.random.choice(range(pop_size), p=probabilities)
    
    return selected_index