def selection(fitnesses):
    import numpy as np
    num_total_cases = len(fitnesses[0])
    pop_size = len(fitnesses)
    mean_errors = np.mean(fitnesses, axis=1)
    probabilities = 1 / (mean_errors + 1e-10)
    probabilities /= np.sum(probabilities)
    selected_index = np.random.choice(np.arange(pop_size), p=probabilities)
    return selected_index