def selection(fitnesses):
    import numpy as np
    
    num_total_cases = len(fitnesses[0])
    pop_size = len(fitnesses)
    
    # Calculate mean error for each individual
    mean_errors = [np.mean(individual_errors) for individual_errors in fitnesses]
    
    # Convert mean errors to fitness values (lower error -> higher fitness)
    fitness_values = [1 / (mean_error + 1e-10) for mean_error in mean_errors]
    
    # Normalize fitness values to form a probability distribution
    total_fitness = sum(fitness_values)
    probabilities = [fitness / total_fitness for fitness in fitness_values]
    
    # Select one parent based on probabilities
    selected_index = np.random.choice(range(pop_size), p=probabilities)
    
    return selected_index