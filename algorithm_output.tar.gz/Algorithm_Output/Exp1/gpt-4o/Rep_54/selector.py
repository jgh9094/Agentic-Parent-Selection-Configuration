def selection(fitnesses):
    import numpy as np
    
    num_total_cases = len(fitnesses[0])
    pop_size = len(fitnesses)
    
    # Calculate mean fitness for each individual
    mean_fitness = [np.mean(individual) for individual in fitnesses]
    
    # Convert mean fitness to probabilities (lower mean fitness = higher probability)
    probabilities = np.max(mean_fitness) - mean_fitness
    probabilities /= np.sum(probabilities)
    
    # Select one individual based on probabilities
    selected_index = np.random.choice(pop_size, p=probabilities)
    
    return selected_index