def selection(fitnesses):
    import numpy as np
    
    num_total_cases = len(fitnesses[0])
    pop_size = len(fitnesses)
    
    # Calculate mean fitness for each individual
    mean_fitnesses = [np.mean(individual_fitness) for individual_fitness in fitnesses]
    
    # Convert mean fitnesses to probabilities (lower mean fitness is better)
    inverted_fitnesses = np.max(mean_fitnesses) - mean_fitnesses
    probabilities = inverted_fitnesses / np.sum(inverted_fitnesses)
    
    # Select one parent based on probabilities
    selected_index = np.random.choice(pop_size, p=probabilities)
    
    return selected_index