def selection(fitnesses):
    import numpy as np
    num_total_cases = len(fitnesses[0])
    pop_size = len(fitnesses)
    fitness_scores = [np.mean(individual) for individual in fitnesses]
    probabilities = 1 / (np.array(fitness_scores) + 1e-10)
    probabilities /= probabilities.sum()
    return np.random.choice(pop_size, p=probabilities)