def selection(fitnesses):
    import numpy as np
    num_total_cases = len(fitnesses[0])
    pop_size = len(fitnesses)
    avg_errors = [np.mean(individual_errors) for individual_errors in fitnesses]
    probabilities = [1 / (error + 1e-10) for error in avg_errors]
    probabilities = probabilities / np.sum(probabilities)
    return np.random.choice(pop_size, p=probabilities)