def selection(fitnesses):
    import numpy as np
    
    num_total_cases = len(fitnesses[0])
    pop_size = len(fitnesses)
    
    # Calculate mean fitness for each individual
    mean_fitnesses = np.mean(fitnesses, axis=1)
    
    # Convert mean fitnesses to probabilities (lower error = higher probability)
    probabilities = 1 / (mean_fitnesses + 1e-10)  # Add small value to avoid division by zero
    probabilities /= np.sum(probabilities)
    
    # Select one parent based on probabilities
    selected_index = np.random.choice(pop_size, p=probabilities)
    
    return selected_index