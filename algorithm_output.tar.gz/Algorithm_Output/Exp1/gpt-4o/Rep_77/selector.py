def selection(fitnesses):
    import numpy as np
    
    num_total_cases = len(fitnesses[0])
    pop_size = len(fitnesses)
    
    # Calculate mean error for each individual
    mean_errors = np.mean(fitnesses, axis=1)
    
    # Convert mean errors to fitness values (lower error -> higher fitness)
    fitness_values = 1 / (mean_errors + 1e-10)
    
    # Normalize fitness values to create a probability distribution
    probabilities = fitness_values / np.sum(fitness_values)
    
    # Select one individual based on the probabilities
    selected_index = np.random.choice(pop_size, p=probabilities)
    
    return selected_index