def selection(fitnesses):
    import numpy as np
    num_total_cases = len(fitnesses[0])
    pop_size = len(fitnesses)
    mean_errors = [np.mean(individual_errors) for individual_errors in fitnesses]
    probabilities = np.array(mean_errors)
    probabilities = 1 / (probabilities + 1e-10)
    probabilities /= probabilities.sum()
    return np.random.choice(pop_size, p=probabilities)