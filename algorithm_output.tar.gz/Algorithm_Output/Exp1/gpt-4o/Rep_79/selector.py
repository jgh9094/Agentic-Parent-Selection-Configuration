def selection(fitnesses):
    import numpy as np
    num_total_cases = len(fitnesses[0])
    pop_size = len(fitnesses)
    aggregated_errors = [np.mean(individual_errors) for individual_errors in fitnesses]
    probabilities = np.array(aggregated_errors)
    probabilities = np.max(probabilities) - probabilities
    probabilities /= np.sum(probabilities)
    selected_index = np.random.choice(pop_size, p=probabilities)
    return selected_index