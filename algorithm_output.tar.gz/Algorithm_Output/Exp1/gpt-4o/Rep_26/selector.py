def selection(fitnesses):
    import numpy as np
    num_total_cases = len(fitnesses[0])
    pop_size = len(fitnesses)
    fitness_scores = [np.mean(individual) for individual in fitnesses]
    probabilities = [1 / score for score in fitness_scores]
    probabilities = probabilities / np.sum(probabilities)
    return np.random.choice(pop_size, p=probabilities)