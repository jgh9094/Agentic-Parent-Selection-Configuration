def selection(fitnesses):
    import numpy as np
    num_total_cases = len(fitnesses[0])
    pop_size = len(fitnesses)
    fitness_scores = [np.mean(individual) for individual in fitnesses]
    probabilities = np.array(fitness_scores)
    probabilities = probabilities.max() - probabilities
    probabilities /= probabilities.sum()
    return np.random.choice(pop_size, p=probabilities)