def selection(fitnesses):
    import numpy as np
    
    num_total_cases = len(fitnesses[0])
    pop_size = len(fitnesses)
    
    fitness_scores = [np.mean(individual_errors) for individual_errors in fitnesses]
    probabilities = np.array(fitness_scores)
    probabilities = 1 / (probabilities + 1e-10)  # Convert errors to fitness values
    probabilities /= probabilities.sum()  # Normalize probabilities
    
    return np.random.choice(pop_size, p=probabilities)