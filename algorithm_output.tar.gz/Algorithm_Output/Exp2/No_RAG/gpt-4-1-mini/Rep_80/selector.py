def selection(fitnesses):
    import numpy as np
    num_total_cases = len(fitnesses[0])
    pop_size = len(fitnesses)
    tournament_size = 7
    # Randomly select tournament_size individuals
    candidates = np.random.choice(pop_size, tournament_size, replace=False)
    # Compute mean error for each candidate
    mean_errors = [np.mean(fitnesses[i]) for i in candidates]
    # Select the candidate with the lowest mean error
    winner_index = candidates[np.argmin(mean_errors)]
    return int(winner_index)