def selection(fitnesses):
    import numpy as np
    num_total_cases = len(fitnesses[0])
    pop_size = len(fitnesses)
    tournament_size = 7
    # Randomly select tournament_size individuals
    participants = np.random.choice(pop_size, tournament_size, replace=False)
    # Compute total error (sum of absolute errors) for each participant
    total_errors = [np.sum(fitnesses[i]) for i in participants]
    # Select the individual with the lowest total error
    winner_index = participants[np.argmin(total_errors)]
    return winner_index