def selection(fitnesses):
    import numpy as np
    num_total_cases = len(fitnesses[0])
    pop_size = len(fitnesses)
    tournament_size = 7
    selected_indices = np.random.choice(pop_size, tournament_size, replace=False)
    best_index = None
    best_fitness = np.inf
    for idx in selected_indices:
        total_error = np.sum(fitnesses[idx])
        if total_error < best_fitness:
            best_fitness = total_error
            best_index = idx
    return best_index