def selection(fitnesses):
    import numpy as np
    num_total_cases = len(fitnesses[0])
    pop_size = len(fitnesses)
    tournament_size = 7
    # Randomly select tournament_size individuals
    participants = np.random.choice(pop_size, tournament_size, replace=False)
    # Compute total error (sum of errors) for each participant
    total_errors = [np.sum(fitnesses[i]) for i in participants]
    # Select the individual with the minimum total error
    winner_index = participants[np.argmin(total_errors)]
    return int(winner_index)