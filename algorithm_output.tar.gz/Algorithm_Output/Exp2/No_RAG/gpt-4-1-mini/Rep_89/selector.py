def selection(fitnesses):
    import numpy as np
    num_total_cases = len(fitnesses[0])
    pop_size = len(fitnesses)
    tournament_size = 7
    # Randomly select tournament_size individuals
    candidates = np.random.choice(pop_size, tournament_size, replace=False)
    # Compute aggregated fitness as mean error (lower is better)
    candidate_fitness = [np.mean(fitnesses[i]) for i in candidates]
    # Select the individual with the lowest mean error
    winner_index = candidates[np.argmin(candidate_fitness)]
    return winner_index