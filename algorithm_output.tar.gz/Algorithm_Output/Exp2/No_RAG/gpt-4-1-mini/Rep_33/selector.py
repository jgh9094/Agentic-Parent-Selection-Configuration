def selection(fitnesses):
    import numpy as np
    num_total_cases = len(fitnesses[0])
    pop_size = len(fitnesses)
    tournament_size = 7
    # Randomly select tournament_size individuals
    candidates = np.random.choice(pop_size, tournament_size, replace=False)
    # Calculate total error for each candidate (sum of absolute errors)
    total_errors = [np.sum(fitnesses[i]) for i in candidates]
    # Select the candidate with the minimum total error
    winner_index = candidates[np.argmin(total_errors)]
    return winner_index