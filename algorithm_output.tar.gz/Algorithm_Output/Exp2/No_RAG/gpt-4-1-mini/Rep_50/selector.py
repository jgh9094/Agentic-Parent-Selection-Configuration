def selection(fitnesses):
    import numpy as np
    num_total_cases = len(fitnesses[0])
    pop_size = len(fitnesses)
    tournament_size = 7
    candidates = np.random.choice(pop_size, tournament_size, replace=False)
    candidate_errors = [np.sum(fitnesses[i]) for i in candidates]
    winner_index = candidates[np.argmin(candidate_errors)]
    return int(winner_index)