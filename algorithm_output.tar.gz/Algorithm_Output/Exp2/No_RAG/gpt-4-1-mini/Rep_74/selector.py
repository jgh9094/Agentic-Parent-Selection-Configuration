def selection(fitnesses):
    import numpy as np
    num_total_cases = len(fitnesses[0])
    pop_size = len(fitnesses)
    tournament_size = 7
    # Randomly select tournament_size individuals
    participants = np.random.choice(pop_size, tournament_size, replace=False)
    # Compute mean error for each participant
    mean_errors = [np.mean(fitnesses[i]) for i in participants]
    # Select the individual with minimal mean error
    winner_index = participants[np.argmin(mean_errors)]
    return winner_index