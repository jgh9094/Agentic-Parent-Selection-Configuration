def selection(fitnesses):
    import numpy as np
    num_total_cases = len(fitnesses[0])
    pop_size = len(fitnesses)
    tournament_size = 7
    participants = np.random.choice(pop_size, tournament_size, replace=False)
    # Calculate mean error per individual (lower is better)
    mean_errors = [np.mean(fitnesses[i]) for i in participants]
    winner_index = participants[np.argmin(mean_errors)]
    return int(winner_index)