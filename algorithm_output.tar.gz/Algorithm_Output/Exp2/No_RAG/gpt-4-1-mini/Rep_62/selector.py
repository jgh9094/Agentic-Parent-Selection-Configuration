def selection(fitnesses):
    import numpy as np
    num_total_cases = len(fitnesses[0])
    pop_size = len(fitnesses)
    tournament_size = 7
    selected_indices = np.random.choice(pop_size, tournament_size, replace=False)
    # Calculate total error for each selected individual
    total_errors = [np.sum(fitnesses[i]) for i in selected_indices]
    # Select the individual with minimum total error
    winner_index = selected_indices[np.argmin(total_errors)]
    return winner_index