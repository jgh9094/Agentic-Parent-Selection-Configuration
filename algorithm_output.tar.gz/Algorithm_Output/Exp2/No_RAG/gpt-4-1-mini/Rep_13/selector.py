def selection(fitnesses):
    import numpy as np
    tournament_size = 7
    pop_size = len(fitnesses)
    selected_indices = np.random.choice(pop_size, tournament_size, replace=False)
    # Compute sum of errors for each selected individual
    errors = [np.sum(fitnesses[i]) for i in selected_indices]
    # Select the individual with minimum total error
    winner_index = selected_indices[np.argmin(errors)]
    return winner_index