def selection(fitnesses):
    import numpy as np
    tournament_size = 7
    num_total_cases = len(fitnesses[0])
    pop_size = len(fitnesses)
    # Compute total error per individual (sum of absolute errors)
    total_errors = np.array([np.sum(ind) for ind in fitnesses])
    # Randomly select tournament_size individuals
    participants = np.random.choice(pop_size, tournament_size, replace=False)
    # Select the individual with minimum total error
    best = participants[np.argmin(total_errors[participants])]
    return int(best)