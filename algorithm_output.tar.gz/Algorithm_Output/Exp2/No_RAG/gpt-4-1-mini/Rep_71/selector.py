def selection(fitnesses):
    import numpy as np
    num_total_cases = len(fitnesses[0])
    pop_size = len(fitnesses)
    tournament_size = 7
    candidates = np.random.choice(pop_size, tournament_size, replace=False)
    # Calculate total error (sum of absolute errors) for each candidate
    total_errors = [np.sum(fitnesses[i]) for i in candidates]
    # Select candidate with minimal total error
    winner_index = candidates[np.argmin(total_errors)]
    return winner_index