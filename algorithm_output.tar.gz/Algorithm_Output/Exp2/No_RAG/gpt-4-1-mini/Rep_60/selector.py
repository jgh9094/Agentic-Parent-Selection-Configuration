def selection(fitnesses):
    import numpy as np
    num_total_cases = len(fitnesses[0])
    pop_size = len(fitnesses)
    tournament_size = 5
    candidates = np.random.choice(pop_size, tournament_size, replace=False)
    # Calculate total error per candidate (sum of errors)
    total_errors = [np.sum(fitnesses[i]) for i in candidates]
    # Select candidate with minimum total error
    winner_index = candidates[np.argmin(total_errors)]
    return int(winner_index)