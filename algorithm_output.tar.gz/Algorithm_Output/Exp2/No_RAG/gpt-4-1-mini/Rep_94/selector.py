def selection(fitnesses):
    import numpy as np
    num_total_cases = len(fitnesses[0])
    pop_size = len(fitnesses)
    tournament_size = 7
    selected_indices = np.random.choice(pop_size, tournament_size, replace=False)
    # Compute mean error for each selected individual
    mean_errors = [np.mean(fitnesses[i]) for i in selected_indices]
    # Select the individual with the lowest mean error
    winner_index = selected_indices[np.argmin(mean_errors)]
    return winner_index