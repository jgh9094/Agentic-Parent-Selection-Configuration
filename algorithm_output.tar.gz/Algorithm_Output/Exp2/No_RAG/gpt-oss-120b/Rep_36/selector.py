def selection(fitnesses):
    import numpy as np
    pop_size = len(fitnesses)
    if pop_size == 0:
        raise ValueError("Empty population")
    # Compute average error for each individual (lower is better)
    avg_errors = np.array([np.mean(ind) for ind in fitnesses])
    tournament_size = min(7, pop_size)
    # Randomly select participants without replacement
    participants = np.random.choice(pop_size, tournament_size, replace=False)
    # Choose the participant with the smallest average error
    best_idx = participants[np.argmin(avg_errors[participants])]
    return int(best_idx)