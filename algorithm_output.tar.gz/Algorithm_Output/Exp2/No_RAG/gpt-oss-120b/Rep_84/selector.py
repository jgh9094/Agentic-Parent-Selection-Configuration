def selection(fitnesses):
    import numpy as np
    num_total_cases = len(fitnesses[0])
    pop_size = len(fitnesses)
    tournament_size = 3
    participants = np.random.choice(pop_size, tournament_size, replace=False)
    errors = [np.mean(fitnesses[i]) for i in participants]
    winner = participants[np.argmin(errors)]
    return int(winner)