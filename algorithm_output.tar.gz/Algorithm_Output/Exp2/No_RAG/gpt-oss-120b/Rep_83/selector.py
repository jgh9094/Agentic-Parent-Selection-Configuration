def selection(fitnesses):
    import numpy as np
    num_cases = len(fitnesses[0])
    pop_size = len(fitnesses)
    candidates = list(range(pop_size))
    case_order = np.random.permutation(num_cases)
    for case_idx in case_order:
        if len(candidates) == 1:
            break
        errors = [fitnesses[i][case_idx] for i in candidates]
        min_err = min(errors)
        tol = 1e-12
        candidates = [c for c, e in zip(candidates, errors) if e <= min_err + tol]
    return int(np.random.choice(candidates))