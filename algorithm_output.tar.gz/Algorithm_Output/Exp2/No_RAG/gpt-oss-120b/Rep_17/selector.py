def selection(fitnesses):
    import numpy as np
    fitnesses = np.array(fitnesses)
    pop_size, num_cases = fitnesses.shape
    candidates = np.arange(pop_size)
    case_order = np.random.permutation(num_cases)
    for c in case_order:
        if candidates.size == 1:
            break
        errors = fitnesses[candidates, c]
        min_err = errors.min()
        candidates = candidates[errors == min_err]
    return int(np.random.choice(candidates))