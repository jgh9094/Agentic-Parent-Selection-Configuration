def selection(fitnesses):
    import numpy as np
    num_total_cases = len(fitnesses[0])
    pop_size = len(fitnesses)
    total_errors = np.array([np.sum(ind) for ind in fitnesses])
    k = 3
    participants = np.random.choice(pop_size, size=k, replace=False)
    best = participants[np.argmin(total_errors[participants])]
    return int(best)