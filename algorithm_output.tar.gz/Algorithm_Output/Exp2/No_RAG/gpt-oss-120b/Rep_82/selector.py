def selection(fitnesses):
    import numpy as np
    num_total_cases = len(fitnesses[0])
    pop_size = len(fitnesses)
    # Start with all candidate indices
    candidates = np.arange(pop_size)
    # Random order of test cases
    case_order = np.random.permutation(num_total_cases)
    for case_idx in case_order:
        # Extract errors for the current case among candidates
        errors = np.array([fitnesses[i][case_idx] for i in candidates])
        min_error = errors.min()
        # Keep only candidates with minimal error on this case
        candidates = candidates[errors == min_error]
        if len(candidates) == 1:
            break
    # If multiple remain, pick one uniformly at random
    return int(np.random.choice(candidates))