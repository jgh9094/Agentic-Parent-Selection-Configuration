def selection(fitnesses):
    import numpy as np
    num_total_cases = len(fitnesses[0])
    pop_size = len(fitnesses)
    candidates = np.arange(pop_size)
    case_order = np.random.permutation(num_total_cases)
    for case_idx in case_order:
        errors = np.array([fitnesses[i][case_idx] for i in candidates])
        min_error = errors.min()
        candidates = candidates[errors <= min_error]
        if len(candidates) == 1:
            break
    selected = np.random.choice(candidates)
    return int(selected)