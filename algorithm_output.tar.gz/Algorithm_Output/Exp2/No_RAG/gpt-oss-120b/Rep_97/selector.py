def selection(fitnesses):
    import numpy as np
    num_total_cases = len(fitnesses[0])
    pop_size = len(fitnesses)
    # Compute total error for each individual (lower is better)
    total_errors = np.sum(fitnesses, axis=1)
    tournament_size = min(7, pop_size)
    participants = np.random.choice(pop_size, tournament_size, replace=False)
    # Choose the participant with the smallest total error
    best = participants[np.argmin(total_errors[participants])]
    return int(best)