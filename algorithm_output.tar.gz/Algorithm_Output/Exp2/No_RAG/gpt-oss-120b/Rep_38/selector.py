def selection(fitnesses):
    import numpy as np
    # Number of test cases per individual
    num_total_cases = len(fitnesses[0])
    # Population size
    pop_size = len(fitnesses)
    # Determine tournament size (e.g., sqrt of population, at least 2)
    tournament_size = max(2, int(np.sqrt(pop_size)))
    # Randomly pick participants without replacement
    participants = np.random.choice(pop_size, tournament_size, replace=False)
    # Compute total error for each participant (lower is better)
    total_errors = [np.sum(fitnesses[i]) for i in participants]
    # Select the participant with the smallest total error
    winner_index = participants[np.argmin(total_errors)]
    return int(winner_index)