def selection(fitnesses):
    import numpy as np
    num_total_cases = len(fitnesses[0])
    pop_size = len(fitnesses)
    k = 7 if pop_size >= 7 else pop_size
    participants = np.random.choice(pop_size, size=k, replace=False)
    errors = np.array([np.sum(fitnesses[i]) for i in participants])
    winner_idx = participants[np.argmin(errors)]
    return int(winner_idx)