def selection(fitnesses):
    import numpy as np
    pop_size = len(fitnesses)
    num_total_cases = len(fitnesses[0])
    # tournament size (e.g., 5% of population, at least 2 individuals)
    tournament_size = max(2, int(0.05 * pop_size))
    participants = np.random.choice(pop_size, tournament_size, replace=False)
    # compute mean error for each participant (lower is better)
    errors = [np.mean(fitnesses[i]) for i in participants]
    winner_idx = participants[np.argmin(errors)]
    return int(winner_idx)