def selection(fitnesses):
    import numpy as np
    num_total_cases = len(fitnesses[0])
    pop_size = len(fitnesses)
    tournament_size = 7
    k = tournament_size if tournament_size < pop_size else pop_size
    participants = np.random.choice(pop_size, k, replace=False)
    total_errors = [np.sum(fitnesses[i]) for i in participants]
    winner = participants[np.argmin(total_errors)]
    return int(winner)