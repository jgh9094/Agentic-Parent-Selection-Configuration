def selection(fitnesses):
    import numpy as np
    # Number of test cases per individual (not directly used here)
    num_total_cases = len(fitnesses[0]) if fitnesses else 0
    pop_size = len(fitnesses)
    if pop_size == 0:
        raise ValueError("Empty population")
    # Tournament size (chosen as 7 or the whole population if smaller)
    tournament_size = min(7, pop_size)
    # Randomly select distinct individuals for the tournament
    candidates = np.random.choice(pop_size, tournament_size, replace=False)
    # Evaluate total error for each candidate (lower is better)
    best_idx = candidates[0]
    best_error = np.sum(fitnesses[best_idx])
    for idx in candidates[1:]:
        err = np.sum(fitnesses[idx])
        if err < best_error:
            best_error = err
            best_idx = idx
    return int(best_idx)