def selection(fitnesses):
    import numpy as np
    num_total_cases = len(fitnesses[0])
    pop_size = len(fitnesses)
    # Compute total error for each individual
    total_errors = np.sum(fitnesses, axis=1)
    # Tournament size (use 3 or the whole population if smaller)
    tournament_size = 3 if pop_size >= 3 else pop_size
    # Randomly select participants without replacement
    participants = np.random.choice(pop_size, size=tournament_size, replace=False)
    # Select the participant with the lowest total error
    best = participants[np.argmin(total_errors[participants])]
    return int(best)