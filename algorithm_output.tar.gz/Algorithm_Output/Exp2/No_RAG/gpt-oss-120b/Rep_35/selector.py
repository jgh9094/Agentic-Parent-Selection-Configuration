def selection(fitnesses):
    import numpy as np
    num_total_cases = len(fitnesses[0])
    pop_size = len(fitnesses)
    # Compute total error for each individual (lower is better)
    total_errors = np.sum(fitnesses, axis=1)
    tournament_size = 3
    # Randomly choose participants
    participants = np.random.choice(pop_size, size=tournament_size, replace=False)
    # Select the participant with the lowest total error
    best = participants[np.argmin(total_errors[participants])]
    return int(best)