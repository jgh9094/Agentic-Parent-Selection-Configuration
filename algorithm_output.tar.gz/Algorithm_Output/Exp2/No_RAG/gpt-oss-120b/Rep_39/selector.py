def selection(fitnesses):
    import numpy as np
    num_total_cases = len(fitnesses[0])
    pop_size = len(fitnesses)
    tournament_size = 7
    if tournament_size > pop_size:
        tournament_size = pop_size
    indices = np.random.choice(pop_size, size=tournament_size, replace=False)
    best = indices[0]
    best_error = np.sum(fitnesses[best])
    for idx in indices[1:]:
        err = np.sum(fitnesses[idx])
        if err < best_error:
            best = idx
            best_error = err
    return int(best)