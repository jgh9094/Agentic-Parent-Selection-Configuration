def selection(fitnesses):
    import numpy as np
    num_total_cases = len(fitnesses[0])
    pop_size = len(fitnesses)
    errors = np.array(fitnesses)
    candidates = np.arange(pop_size)
    case_order = np.random.permutation(num_total_cases)
    for case_idx in case_order:
        if len(candidates) == 1:
            break
        case_errors = errors[candidates, case_idx]
        min_err = np.min(case_errors)
        candidates = candidates[case_errors == min_err]
    selected = np.random.choice(candidates)
    return int(selected)