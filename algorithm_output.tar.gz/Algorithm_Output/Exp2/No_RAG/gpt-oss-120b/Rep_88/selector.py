def selection(fitnesses):
    import numpy as np
    num_total_cases = len(fitnesses[0])
    pop_size = len(fitnesses)
    # Compute average error for each individual (lower is better)
    errors = np.array([np.mean(ind) for ind in fitnesses])
    k = 3 if pop_size >= 3 else pop_size
    participants = np.random.choice(pop_size, size=k, replace=False)
    best = participants[0]
    best_error = errors[best]
    for idx in participants[1:]:
        if errors[idx] < best_error:
            best = idx
            best_error = errors[idx]
    return int(best)