def selection(fitnesses):
    import numpy as np
    num_total_cases = len(fitnesses[0])
    pop_size = len(fitnesses)
    # Sum errors across all test cases for each individual
    total_errors = np.sum(np.array(fitnesses), axis=1)
    tournament_size = 3 if pop_size >= 3 else pop_size
    participants = np.random.choice(pop_size, size=tournament_size, replace=False)
    best_idx = participants[np.argmin(total_errors[participants])]
    return int(best_idx)