def selection(fitnesses):
    import numpy as np
    num_total_cases = len(fitnesses[0])
    pop_size = len(fitnesses)
    candidates = list(range(pop_size))
    case_order = np.random.permutation(num_total_cases)
    for case in case_order:
        min_err = min(fitnesses[i][case] for i in candidates)
        candidates = [i for i in candidates if fitnesses[i][case] == min_err]
        if len(candidates) == 1:
            break
    return np.random.choice(candidates)