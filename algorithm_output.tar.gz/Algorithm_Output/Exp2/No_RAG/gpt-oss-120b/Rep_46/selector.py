def selection(fitnesses):
    import numpy as np
    num_total_cases = len(fitnesses[0])
    pop_size = len(fitnesses)
    total_errors = np.array([np.sum(ind) for ind in fitnesses])
    tournament_size = 5
    if pop_size < tournament_size:
        tournament_size = pop_size
    participants = np.random.choice(pop_size, size=tournament_size, replace=False)
    best = participants[np.argmin(total_errors[participants])]
    return int(best)