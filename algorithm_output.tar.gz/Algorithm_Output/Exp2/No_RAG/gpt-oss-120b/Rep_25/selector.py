def selection(fitnesses):
    import numpy as np
    num_cases = len(fitnesses[0])
    pop_size = len(fitnesses)
    # Random order of test cases
    case_order = np.random.permutation(num_cases)
    candidates = np.arange(pop_size)
    for case in case_order:
        # Errors of current candidates on this case
        errors = np.array([fitnesses[i][case] for i in candidates])
        min_err = errors.min()
        candidates = candidates[errors == min_err]
        if len(candidates) == 1:
            break
    # If multiple remain, pick one at random
    if len(candidates) > 1:
        selected = np.random.choice(candidates)
    else:
        selected = candidates[0]
    return int(selected)