def selection(fitnesses):
    import numpy as np
    num_total_cases = len(fitnesses[0])
    pop_size = len(fitnesses)
    # tournament size (adjustable)
    tournament_size = 7 if pop_size >= 7 else pop_size
    # randomly select participants without replacement
    participants = np.random.choice(pop_size, tournament_size, replace=False)
    # compute total error for each participant (lower is better)
    errors = [np.sum(fitnesses[i]) for i in participants]
    # select the participant with minimal error
    winner = participants[np.argmin(errors)]
    return int(winner)