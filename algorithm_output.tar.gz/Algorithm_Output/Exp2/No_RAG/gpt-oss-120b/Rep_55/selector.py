def selection(fitnesses):
    import numpy as np
    # Number of test cases per individual (not directly used here)
    num_total_cases = len(fitnesses[0])
    # Population size
    pop_size = len(fitnesses)
    # Compute total error for each individual (lower is better)
    total_errors = np.sum(fitnesses, axis=1)
    # Tournament size (e.g., 3)
    tournament_size = 3 if pop_size >= 3 else pop_size
    # Randomly select participants
    participants = np.random.choice(pop_size, size=tournament_size, replace=False)
    # Choose the participant with the smallest total error
    best_index = participants[np.argmin(total_errors[participants])]
    return int(best_index)