def selection(fitnesses):
    import numpy as np
    num_total_cases = len(fitnesses[0])
    pop_size = len(fitnesses)
    # tournament size (use 3 or the whole population if smaller)
    k = 3 if pop_size >= 3 else pop_size
    participants = np.random.choice(pop_size, size=k, replace=False)
    errors = [np.sum(fitnesses[i]) for i in participants]
    winner_idx = participants[np.argmin(errors)]
    return int(winner_idx)