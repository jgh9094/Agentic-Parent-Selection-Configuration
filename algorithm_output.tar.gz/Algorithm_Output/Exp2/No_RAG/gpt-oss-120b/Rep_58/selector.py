def selection(fitnesses):
    import numpy as np
    num_total_cases = len(fitnesses[0])
    pop_size = len(fitnesses)
    # tournament size (sqrt of population size, at least 2)
    k = max(2, int(np.sqrt(pop_size)))
    # randomly select k individuals without replacement
    participants = np.random.choice(pop_size, size=k, replace=False)
    # choose the individual with lowest total error (sum of case errors)
    best = participants[0]
    best_error = np.sum(fitnesses[best])
    for idx in participants[1:]:
        err = np.sum(fitnesses[idx])
        if err < best_error:
            best = idx
            best_error = err
    return int(best)