def selection(fitnesses):
    import numpy as np
    num_total_cases = len(fitnesses[0])
    pop_size = len(fitnesses)
    # Compute total error for each individual (lower is better)
    total_errors = np.array([np.sum(ind) for ind in fitnesses])
    # Tournament size (use 3 or the whole population if smaller)
    k = 3 if pop_size >= 3 else pop_size
    participants = np.random.choice(pop_size, size=k, replace=False)
    # Choose the participant with the smallest total error
    best = participants[np.argmin(total_errors[participants])]
    return int(best)