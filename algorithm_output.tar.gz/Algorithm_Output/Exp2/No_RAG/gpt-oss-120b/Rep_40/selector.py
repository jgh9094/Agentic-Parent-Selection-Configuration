def selection(fitnesses):
    import numpy as np
    pop_size = len(fitnesses)
    if pop_size == 0:
        raise ValueError("Empty population")
    tournament_size = 7 if pop_size >= 7 else pop_size
    participants = np.random.choice(pop_size, tournament_size, replace=False)
    best_idx = participants[0]
    best_error = sum(fitnesses[best_idx])
    for idx in participants[1:]:
        err = sum(fitnesses[idx])
        if err < best_error:
            best_error = err
            best_idx = idx
    return int(best_idx)