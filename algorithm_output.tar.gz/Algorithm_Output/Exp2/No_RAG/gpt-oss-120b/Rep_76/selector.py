def selection(fitnesses):
    import numpy as np
    num_total_cases = len(fitnesses[0])
    pop_size = len(fitnesses)
    # aggregate error per individual (sum over cases)
    total_errors = np.sum(fitnesses, axis=1)
    tournament_size = 3 if pop_size >= 3 else pop_size
    participants = np.random.choice(pop_size, size=tournament_size, replace=False)
    best = participants[0]
    best_error = total_errors[best]
    for idx in participants[1:]:
        if total_errors[idx] < best_error:
            best = idx
            best_error = total_errors[idx]
    return int(best)