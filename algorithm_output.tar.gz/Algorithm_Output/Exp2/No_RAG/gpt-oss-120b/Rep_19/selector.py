def selection(fitnesses):
    import numpy as np
    num_total_cases = len(fitnesses[0])
    pop_size = len(fitnesses)
    # Compute total error for each individual (lower is better)
    total_errors = np.array([np.sum(ind) for ind in fitnesses])
    # Binary tournament selection
    if pop_size < 2:
        return 0
    candidates = np.random.choice(pop_size, size=2, replace=False)
    if total_errors[candidates[0]] <= total_errors[candidates[1]]:
        return int(candidates[0])
    else:
        return int(candidates[1])