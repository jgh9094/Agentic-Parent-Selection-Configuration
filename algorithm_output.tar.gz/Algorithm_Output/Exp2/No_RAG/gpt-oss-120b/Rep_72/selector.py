def selection(fitnesses):
    import numpy as np
    num_total_cases = len(fitnesses[0])
    pop_size = len(fitnesses)
    candidates = np.arange(pop_size)
    case_order = np.random.permutation(num_total_cases)
    for case in case_order:
        errors = np.array([fitnesses[i][case] for i in candidates])
        min_err = errors.min()
        candidates = candidates[errors == min_err]
        if len(candidates) == 1:
            break
    return int(np.random.choice(candidates))