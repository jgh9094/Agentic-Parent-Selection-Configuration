def selection(fitnesses):
    import numpy as np
    num_total_cases = len(fitnesses[0])
    pop_size = len(fitnesses)
    total_errors = [float(np.sum(ind_errors)) for ind_errors in fitnesses]
    tournament_size = 7 if pop_size >= 7 else pop_size
    participants = np.random.choice(pop_size, size=tournament_size, replace=False)
    best_idx = participants[np.argmin([total_errors[i] for i in participants])]
    return int(best_idx)