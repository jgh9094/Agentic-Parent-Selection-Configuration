def selection(fitnesses):
    import numpy as np
    num_total_cases = len(fitnesses[0])
    pop_size = len(fitnesses)
    # Compute total error (sum) for each individual
    total_errors = np.array([np.sum(ind) for ind in fitnesses])
    # Tournament size (choose 7 or smaller if population is small)
    k = min(7, pop_size)
    participants = np.random.choice(pop_size, size=k, replace=False)
    # Select the participant with the lowest total error (best fitness)
    best_idx = participants[np.argmin(total_errors[participants])]
    return int(best_idx)