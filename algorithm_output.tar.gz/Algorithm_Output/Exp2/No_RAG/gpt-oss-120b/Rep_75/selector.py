def selection(fitnesses):
    import numpy as np
    pop_size = len(fitnesses)
    if pop_size == 0:
        raise ValueError("Empty population")
    # Compute total error for each individual (lower is better)
    total_errors = np.sum(fitnesses, axis=1)
    tournament_size = 7  # typical moderate size
    # Randomly choose participants
    participants = np.random.choice(pop_size, size=min(tournament_size, pop_size), replace=False)
    # Select the participant with the lowest total error
    best_idx = participants[np.argmin(total_errors[participants])]
    return int(best_idx)