def selection(fitnesses):
    import numpy as np
    num_total_cases = len(fitnesses[0])
    pop_size = len(fitnesses)
    candidates = list(range(pop_size))
    case_order = np.random.permutation(num_total_cases)
    for case_idx in case_order:
        errors = [fitnesses[i][case_idx] for i in candidates]
        min_error = np.min(errors)
        candidates = [c for c, e in zip(candidates, errors) if np.isclose(e, min_error)]
        if len(candidates) == 1:
            break
    selected = np.random.choice(candidates)
    return int(selected)