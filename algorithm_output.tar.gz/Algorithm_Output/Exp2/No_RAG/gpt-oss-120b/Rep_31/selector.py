def selection(fitnesses):
    import numpy as np
    num_total_cases = len(fitnesses[0])
    pop_size = len(fitnesses)
    # Compute total error for each individual (lower is better)
    total_errors = np.sum(fitnesses, axis=1)
    # Tournament size (e.g., 3)
    k = 3 if pop_size >= 3 else pop_size
    # Randomly select k distinct individuals
    participants = np.random.choice(pop_size, k, replace=False)
    # Choose the participant with the smallest total error
    best = participants[np.argmin(total_errors[participants])]
    return int(best)