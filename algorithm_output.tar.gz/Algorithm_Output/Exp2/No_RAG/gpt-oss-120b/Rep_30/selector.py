def selection(fitnesses):
    import numpy as np
    num_total_cases = len(fitnesses[0])
    pop_size = len(fitnesses)
    # Compute mean error for each individual
    means = np.mean(fitnesses, axis=1)
    # Tournament size (use 7 or the whole population if smaller)
    k = 7 if pop_size >= 7 else pop_size
    participants = np.random.choice(pop_size, size=k, replace=False)
    best = participants[np.argmin(means[participants])]
    return int(best)