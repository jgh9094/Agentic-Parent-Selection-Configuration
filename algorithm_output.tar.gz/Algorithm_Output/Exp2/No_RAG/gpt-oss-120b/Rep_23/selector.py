def selection(fitnesses):
    import numpy as np
    num_total_cases = len(fitnesses[0])
    pop_size = len(fitnesses)
    # tournament size (choose 7 or smaller if population is small)
    k = 7 if pop_size >= 7 else pop_size
    participants = np.random.choice(pop_size, size=k, replace=False)
    # compute total error for each participant (lower is better)
    errors = [np.sum(fitnesses[i]) for i in participants]
    best_idx = participants[np.argmin(errors)]
    return int(best_idx)