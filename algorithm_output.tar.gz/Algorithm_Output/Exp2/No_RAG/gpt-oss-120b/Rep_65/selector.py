def selection(fitnesses):
    import numpy as np
    num_total_cases = len(fitnesses[0])
    pop_size = len(fitnesses)
    # Compute total error for each individual
    total_errors = np.array([np.sum(ind) for ind in fitnesses])
    # Binary tournament: randomly select two distinct individuals
    i1, i2 = np.random.choice(pop_size, size=2, replace=False)
    # Return the index of the individual with lower error (since we minimize)
    return int(i1) if total_errors[i1] <= total_errors[i2] else int(i2)