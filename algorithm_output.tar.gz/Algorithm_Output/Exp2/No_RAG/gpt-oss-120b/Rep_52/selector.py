def selection(fitnesses):
    import numpy as np
    num_total_cases = len(fitnesses[0])
    pop_size = len(fitnesses)
    tournament_size = 7 if pop_size >= 7 else pop_size
    candidates = np.random.choice(pop_size, tournament_size, replace=False)
    total_errors = [np.sum(fitnesses[i]) for i in candidates]
    best_candidate = candidates[np.argmin(total_errors)]
    return int(best_candidate)