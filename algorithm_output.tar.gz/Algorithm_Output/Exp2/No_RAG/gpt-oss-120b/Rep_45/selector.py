def selection(fitnesses):
    import numpy as np
    num_total_cases = len(fitnesses[0])
    pop_size = len(fitnesses)
    k = 7 if pop_size >= 7 else pop_size
    indices = np.random.choice(pop_size, k, replace=False)
    total_errors = [np.sum(fitnesses[i]) for i in indices]
    best_idx = indices[np.argmin(total_errors)]
    return int(best_idx)