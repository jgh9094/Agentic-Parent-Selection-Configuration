def selection(fitnesses):
    import numpy as np
    num_total_cases = len(fitnesses[0])
    pop_size = len(fitnesses)
    # Compute total error for each individual (lower is better)
    total_errors = np.sum(fitnesses, axis=1)
    # Tournament size (e.g., sqrt of population size, at least 2)
    tournament_size = max(2, int(np.sqrt(pop_size)))
    # Randomly select participants
    participants = np.random.choice(pop_size, size=tournament_size, replace=False)
    # Choose the participant with the smallest total error
    best_idx = participants[np.argmin(total_errors[participants])]
    return int(best_idx)