def selection(fitnesses):
    import numpy as np
    num_total_cases = len(fitnesses[0])
    pop_size = len(fitnesses)
    candidates = np.arange(pop_size)
    case_order = np.random.permutation(num_total_cases)
    for case in case_order:
        errors = np.array([fitnesses[i][case] for i in candidates])
        min_err = errors.min()
        candidates = candidates[errors == min_err]
        if candidates.size == 1:
            break
    if candidates.size > 1:
        chosen = np.random.choice(candidates)
    else:
        chosen = candidates[0]
    return int(chosen)