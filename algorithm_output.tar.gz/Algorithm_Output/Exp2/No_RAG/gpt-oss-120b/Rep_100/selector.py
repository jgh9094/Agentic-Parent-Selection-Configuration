def selection(fitnesses):
    import numpy as np
    num_total_cases = len(fitnesses[0])
    pop_size = len(fitnesses)
    # Tournament size (commonly 3)
    tournament_size = 3 if pop_size >= 3 else pop_size
    # Randomly select participants
    participants = np.random.choice(pop_size, size=tournament_size, replace=False)
    # Compute total error for each participant
    total_errors = [np.sum(fitnesses[i]) for i in participants]
    # Select the participant with the lowest total error (best fitness)
    winner_index = participants[np.argmin(total_errors)]
    return int(winner_index)