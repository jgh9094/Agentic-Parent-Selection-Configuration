def selection(fitnesses):
    import numpy as np
    num_total_cases = len(fitnesses[0])
    pop_size = len(fitnesses)
    fitness_arr = np.array(fitnesses)
    case_order = np.random.permutation(num_total_cases)
    candidates = np.arange(pop_size)
    for c in case_order:
        errors = fitness_arr[candidates, c]
        min_err = np.min(errors)
        candidates = candidates[errors == min_err]
        if len(candidates) == 1:
            break
    selected = np.random.choice(candidates)
    return int(selected)