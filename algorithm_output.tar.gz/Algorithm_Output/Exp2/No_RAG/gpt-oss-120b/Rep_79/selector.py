def selection(fitnesses):
    import numpy as np
    num_total_cases = len(fitnesses[0])
    pop_size = len(fitnesses)
    tournament_size = 3
    participants = np.random.choice(pop_size, size=min(tournament_size, pop_size), replace=False)
    total_errors = [np.sum(fitnesses[i]) for i in participants]
    winner_idx = participants[np.argmin(total_errors)]
    return int(winner_idx)