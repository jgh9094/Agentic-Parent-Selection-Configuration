def selection(fitnesses):
    import numpy as np
    num_total_cases = len(fitnesses[0])
    pop_size = len(fitnesses)
    k = 3 if pop_size >= 3 else pop_size
    participants = np.random.choice(pop_size, size=k, replace=False)
    best = participants[0]
    best_error = np.sum(fitnesses[best])
    for idx in participants[1:]:
        err = np.sum(fitnesses[idx])
        if err < best_error:
            best = idx
            best_error = err
    return int(best)