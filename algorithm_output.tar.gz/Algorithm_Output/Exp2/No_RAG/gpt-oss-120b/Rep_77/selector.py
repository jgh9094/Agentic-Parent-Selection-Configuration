def selection(fitnesses):
    import numpy as np
    num_total_cases = len(fitnesses[0])
    pop_size = len(fitnesses)
    # tournament size
    k = 3 if pop_size >= 3 else pop_size
    # randomly select k distinct individuals
    candidates = np.random.choice(pop_size, size=k, replace=False)
    # compute total error for each candidate
    total_errors = [np.sum(fitnesses[i]) for i in candidates]
    # select candidate with minimal error
    winner_idx = candidates[np.argmin(total_errors)]
    return int(winner_idx)