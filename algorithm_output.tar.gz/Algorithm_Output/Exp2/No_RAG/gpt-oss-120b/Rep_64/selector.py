def selection(fitnesses):
    import numpy as np
    num_total_cases = len(fitnesses[0])
    pop_size = len(fitnesses)
    tournament_size = 7 if pop_size >= 7 else pop_size
    participants = np.random.choice(pop_size, tournament_size, replace=False)
    best = participants[0]
    best_error = np.sum(fitnesses[best])
    for idx in participants[1:]:
        err = np.sum(fitnesses[idx])
        if err < best_error:
            best = idx
            best_error = err
    return int(best)