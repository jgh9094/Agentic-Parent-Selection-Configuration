def selection(fitnesses):
    import numpy as np
    num_total_cases = len(fitnesses[0])
    pop_size = len(fitnesses)
    tournament_size = 3
    # Randomly select participants for the tournament
    participants = np.random.choice(pop_size, tournament_size, replace=False)
    # Compute total error for each participant (lower is better)
    errors = [np.sum(fitnesses[i]) for i in participants]
    # Choose the participant with the smallest error
    winner = participants[np.argmin(errors)]
    return int(winner)