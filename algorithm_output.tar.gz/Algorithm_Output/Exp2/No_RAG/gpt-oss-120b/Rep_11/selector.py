def selection(fitnesses):
    import numpy as np
    num_total_cases = len(fitnesses[0])
    pop_size = len(fitnesses)
    # Compute total error for each individual (lower is better)
    total_errors = np.array([np.sum(ind) for ind in fitnesses])
    # Tournament size (choose 7 or the whole population if smaller)
    tournament_size = min(7, pop_size)
    participants = np.random.choice(pop_size, size=tournament_size, replace=False)
    best_idx = participants[np.argmin(total_errors[participants])]
    return int(best_idx)