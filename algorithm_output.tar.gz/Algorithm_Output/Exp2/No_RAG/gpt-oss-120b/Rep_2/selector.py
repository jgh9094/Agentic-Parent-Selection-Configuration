def selection(fitnesses):
    import numpy as np
    num_total_cases = len(fitnesses[0])
    pop_size = len(fitnesses)
    tournament_size = min(7, pop_size)
    participants = np.random.choice(pop_size, tournament_size, replace=False)
    total_errors = [np.sum(fitnesses[i]) for i in participants]
    best_participant = participants[np.argmin(total_errors)]
    return int(best_participant)