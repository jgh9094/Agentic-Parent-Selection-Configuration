def selection(fitnesses):
    import numpy as np
    num_cases = len(fitnesses[0])
    pop_size = len(fitnesses)
    candidates = list(range(pop_size))
    case_order = np.random.permutation(num_cases)
    for c in case_order:
        errors = [fitnesses[i][c] for i in candidates]
        min_err = min(errors)
        candidates = [candidates[i] for i, e in enumerate(errors) if e == min_err]
        if len(candidates) == 1:
            break
    return int(np.random.choice(candidates))