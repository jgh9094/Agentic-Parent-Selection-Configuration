def selection(fitnesses):
    import numpy as np
    num_total_cases = len(fitnesses[0])
    pop_size = len(fitnesses)
    # tournament size (e.g., 5% of population, at least 2)
    tournament_size = max(2, int(0.05 * pop_size))
    # randomly pick participants
    participants = np.random.choice(pop_size, tournament_size, replace=False)
    # compute total error for each participant
    total_errors = [np.sum(fitnesses[i]) for i in participants]
    # select the individual with minimal error
    winner = participants[np.argmin(total_errors)]
    return int(winner)