def selection(fitnesses):
    import numpy as np
    num_total_cases = len(fitnesses[0])
    pop_size = len(fitnesses)
    # Compute total error for each individual
    total_errors = np.sum(fitnesses, axis=1)
    # Define tournament size (use 7 or the full population if smaller)
    k = 7 if pop_size >= 7 else pop_size
    participants = np.random.choice(pop_size, size=k, replace=False)
    best_idx = participants[np.argmin(total_errors[participants])]
    return int(best_idx)