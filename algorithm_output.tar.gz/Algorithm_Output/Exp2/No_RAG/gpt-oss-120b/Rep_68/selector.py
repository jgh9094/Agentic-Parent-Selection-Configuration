def selection(fitnesses):
    import numpy as np
    num_total_cases = len(fitnesses[0])
    pop_size = len(fitnesses)
    k = 7 if pop_size >= 7 else pop_size
    participants = np.random.choice(pop_size, k, replace=False)
    errors = np.mean(np.array(fitnesses)[participants], axis=1)
    winner = participants[np.argmin(errors)]
    return int(winner)