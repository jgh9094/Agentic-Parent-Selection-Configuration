def selection(fitnesses):
    import numpy as np
    num_total_cases = len(fitnesses[0])
    pop_size = len(fitnesses)
    tournament_size = 5
    selected_indices = np.random.choice(pop_size, tournament_size, replace=False)
    tournament_errors = [np.mean(fitnesses[i]) for i in selected_indices]
    best_index = selected_indices[np.argmin(tournament_errors)]
    return best_index