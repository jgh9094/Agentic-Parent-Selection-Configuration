def selection(fitnesses):
    import numpy as np
    num_total_cases = len(fitnesses[0])
    pop_size = len(fitnesses)
    tournament_size = max(2, int(0.1 * pop_size))
    tournament_indices = np.random.choice(pop_size, tournament_size, replace=False)
    tournament_errors = [np.mean(fitnesses[i]) for i in tournament_indices]
    best_index = tournament_indices[np.argmin(tournament_errors)]
    return best_index