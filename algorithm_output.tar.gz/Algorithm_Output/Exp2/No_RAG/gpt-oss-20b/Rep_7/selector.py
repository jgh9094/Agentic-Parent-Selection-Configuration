def selection(fitnesses):
    import numpy as np
    num_total_cases = len(fitnesses[0])
    pop_size = len(fitnesses)
    errors = np.array([sum(ind) for ind in fitnesses])
    i1 = np.random.randint(pop_size)
    i2 = np.random.randint(pop_size)
    if errors[i1] < errors[i2]:
        return i1
    else:
        return i2