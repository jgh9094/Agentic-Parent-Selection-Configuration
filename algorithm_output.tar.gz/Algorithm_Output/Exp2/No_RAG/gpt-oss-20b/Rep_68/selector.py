def selection(fitnesses):
    import numpy as np
    num_total_cases = len(fitnesses[0])
    pop_size = len(fitnesses)
    mean_errors = np.array([np.mean(f) for f in fitnesses])
    tsize = 3
    candidates = np.random.choice(pop_size, tsize, replace=False)
    best_idx = candidates[np.argmin(mean_errors[candidates])]
    return int(best_idx)