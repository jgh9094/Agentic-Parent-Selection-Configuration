def selection(fitnesses):
    import numpy as np
    num_total_cases = len(fitnesses[0])
    pop_size = len(fitnesses)
    errors = np.sum(fitnesses, axis=1)
    tournament_size = 3
    indices = np.random.randint(0, pop_size, size=tournament_size)
    best_idx = indices[0]
    best_error = errors[best_idx]
    for idx in indices[1:]:
        if errors[idx] < best_error:
            best_error = errors[idx]
            best_idx = idx
    return best_idx