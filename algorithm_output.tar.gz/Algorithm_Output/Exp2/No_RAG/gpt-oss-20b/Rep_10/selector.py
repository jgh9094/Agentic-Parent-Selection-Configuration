def selection(fitnesses):
    import numpy as np
    num_total_cases = len(fitnesses[0])
    pop_size = len(fitnesses)
    errors = np.array([sum(ind) for ind in fitnesses])
    i, j = np.random.randint(0, pop_size, size=2)
    return i if errors[i] < errors[j] else j