def selection(fitnesses):
    import numpy as np
    pop_size = len(fitnesses)
    num_total_cases = len(fitnesses[0])
    total_errors = np.array([sum(f) for f in fitnesses])
    tournament_size = 3
    participants = np.random.choice(pop_size, size=tournament_size, replace=False)
    best = participants[np.argmin(total_errors[participants])]
    return int(best)