import numpy as np

def selection(fitnesses):
    num_total_cases = len(fitnesses[0])
    pop_size = len(fitnesses)
    total_errors = np.array([sum(errors) for errors in fitnesses])
    tournament_size = 3
    candidates = np.random.randint(0, pop_size, size=tournament_size)
    best = candidates[0]
    best_error = total_errors[best]
    for idx in candidates[1:]:
        if total_errors[idx] < best_error:
            best = idx
            best_error = total_errors[idx]
    return best