def selection(fitnesses):
    import numpy as np
    num_total_cases = len(fitnesses[0])
    pop_size = len(fitnesses)
    mean_errors = np.array([np.mean(f) for f in fitnesses])
    k = 3
    candidates = np.random.randint(0, pop_size, size=k)
    best = candidates[0]
    best_error = mean_errors[best]
    for idx in candidates[1:]:
        if mean_errors[idx] < best_error:
            best = idx
            best_error = mean_errors[idx]
    return best