def selection(fitnesses):
    import numpy as np
    num_total_cases = len(fitnesses[0])
    pop_size = len(fitnesses)
    errors = np.sum(np.array(fitnesses), axis=1)
    tournament_size = 3
    indices = np.random.randint(0, pop_size, size=tournament_size)
    best_idx = indices[np.argmin(errors[indices])]
    return int(best_idx)