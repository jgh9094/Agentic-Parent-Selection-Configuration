def selection(fitnesses):
    import numpy as np
    num_total_cases = len(fitnesses[0])
    pop_size = len(fitnesses)
    total_errors = np.sum(fitnesses, axis=1)
    candidates = np.random.randint(0, pop_size, size=2)
    if total_errors[candidates[0]] <= total_errors[candidates[1]]:
        return int(candidates[0])
    else:
        return int(candidates[1])