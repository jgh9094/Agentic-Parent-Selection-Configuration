def selection(fitnesses):
    import numpy as np
    num_total_cases = len(fitnesses[0])
    pop_size = len(fitnesses)
    # Compute total error per individual (lower is better)
    errors = np.array([sum(individual) for individual in fitnesses])
    tournament_size = min(3, pop_size)
    # Randomly pick tournament participants
    indices = np.random.choice(pop_size, size=tournament_size, replace=False)
    # Select the index with the lowest error
    best_idx = indices[np.argmin(errors[indices])]
    return int(best_idx)