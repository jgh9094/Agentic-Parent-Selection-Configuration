def selection(fitnesses):
    import numpy as np
    num_total_cases = len(fitnesses[0])
    pop_size = len(fitnesses)
    fitness = np.array([sum(ind) for ind in fitnesses])
    tournament_size = 5
    if pop_size < tournament_size:
        tournament_size = pop_size
    indices = np.random.choice(pop_size, size=tournament_size, replace=False)
    best_idx = indices[np.argmin(fitness[indices])]
    return int(best_idx)