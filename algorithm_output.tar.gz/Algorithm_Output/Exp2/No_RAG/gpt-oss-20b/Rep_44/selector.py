def selection(fitnesses):
    import numpy as np
    num_total_cases = len(fitnesses[0])
    pop_size = len(fitnesses)
    errors = np.array(fitnesses)
    mean_errors = errors.mean(axis=1)
    fitness = 1.0 / (1.0 + mean_errors)
    k = 3
    indices = np.random.randint(0, pop_size, size=k)
    best_idx = indices[np.argmax(fitness[indices])]
    return int(best_idx)