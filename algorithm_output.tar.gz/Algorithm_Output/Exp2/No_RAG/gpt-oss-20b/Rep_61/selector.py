def selection(fitnesses):
    import numpy as np
    num_total_cases = len(fitnesses[0])
    pop_size = len(fitnesses)
    fitness = np.array([ -sum(ind) for ind in fitnesses ])
    tournament_size = 3
    indices = np.random.randint(0, pop_size, size=tournament_size)
    best = indices[0]
    best_fit = fitness[best]
    for idx in indices[1:]:
        if fitness[idx] > best_fit:
            best = idx
            best_fit = fitness[idx]
    return best