def selection(fitnesses):
    import numpy as np
    num_total_cases = len(fitnesses[0])
    pop_size = len(fitnesses)
    fitness = np.array([sum(f) for f in fitnesses])
    k = 3
    indices = np.random.randint(0, pop_size, size=k)
    best_idx = indices[np.argmin(fitness[indices])]
    return int(best_idx)