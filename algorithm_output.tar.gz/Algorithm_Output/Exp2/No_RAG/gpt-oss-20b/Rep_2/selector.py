def selection(fitnesses):
    import numpy as np
    num_total_cases = len(fitnesses[0])
    pop_size = len(fitnesses)
    errors = np.array(fitnesses)
    total_error = np.sum(errors, axis=1)
    k = min(3, pop_size)
    candidates = np.random.choice(pop_size, size=k, replace=False)
    best_idx = candidates[np.argmin(total_error[candidates])]
    return int(best_idx)