def selection(fitnesses):
    import numpy as np
    num_total_cases = len(fitnesses[0])
    pop_size = len(fitnesses)
    errors = np.array(fitnesses)
    fitness = 1.0 / (1.0 + errors.sum(axis=1))
    tournament_size = 3
    if pop_size < tournament_size:
        tournament_size = pop_size
    candidates = np.random.choice(pop_size, size=tournament_size, replace=False)
    best = candidates[0]
    best_fit = fitness[best]
    for idx in candidates[1:]:
        if fitness[idx] > best_fit:
            best = idx
            best_fit = fitness[idx]
    return int(best)