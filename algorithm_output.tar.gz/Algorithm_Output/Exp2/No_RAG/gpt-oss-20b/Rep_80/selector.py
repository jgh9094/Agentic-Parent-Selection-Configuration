def selection(fitnesses):
    import numpy as np
    num_total_cases = len(fitnesses[0])
    pop_size = len(fitnesses)
    # Convert errors to fitness (higher is better)
    fitness = np.array([ -sum(f) for f in fitnesses ])
    # Tournament selection
    tournament_size = 3
    indices = np.random.randint(0, pop_size, size=tournament_size)
    best_idx = indices[0]
    best_fit = fitness[best_idx]
    for idx in indices[1:]:
        if fitness[idx] > best_fit:
            best_fit = fitness[idx]
            best_idx = idx
    return int(best_idx)