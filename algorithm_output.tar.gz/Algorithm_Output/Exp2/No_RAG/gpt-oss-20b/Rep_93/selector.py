def selection(fitnesses):
    import numpy as np
    num_total_cases = len(fitnesses[0])
    pop_size = len(fitnesses)
    errors = np.sum(np.array(fitnesses), axis=1)
    k = 3
    if pop_size < k:
        k = pop_size
    tournament_indices = np.random.choice(pop_size, size=k, replace=False)
    best_index = tournament_indices[np.argmin(errors[tournament_indices])]
    return int(best_index)