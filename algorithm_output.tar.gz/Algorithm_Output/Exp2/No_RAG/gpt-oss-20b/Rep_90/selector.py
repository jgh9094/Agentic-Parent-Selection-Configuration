def selection(fitnesses):
    import numpy as np
    num_total_cases = len(fitnesses[0])
    pop_size = len(fitnesses)
    errors = np.array([sum(ind) for ind in fitnesses])
    fitness = 1.0 / (1.0 + errors)
    rng = np.random.default_rng()
    tournament_size = 3
    indices = rng.choice(pop_size, size=tournament_size, replace=False)
    best_idx = indices[np.argmax(fitness[indices])]
    return int(best_idx)