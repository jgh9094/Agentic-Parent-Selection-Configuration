def selection(fitnesses):
    import numpy as np
    num_total_cases = len(fitnesses[0])
    pop_size = len(fitnesses)
    if pop_size == 0:
        return None
    aggregate = np.array([np.sum(ind) for ind in fitnesses])
    k = 3
    if pop_size < k:
        k = pop_size
    indices = np.random.choice(pop_size, k, replace=False)
    best_idx = indices[0]
    best_fitness = aggregate[best_idx]
    for idx in indices[1:]:
        if aggregate[idx] < best_fitness:
            best_fitness = aggregate[idx]
            best_idx = idx
    return int(best_idx)