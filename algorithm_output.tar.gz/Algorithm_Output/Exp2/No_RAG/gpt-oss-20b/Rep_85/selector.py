def selection(fitnesses):
    import numpy as np
    pop_size = len(fitnesses)
    num_total_cases = len(fitnesses[0])
    fitness = np.array([sum(ind) for ind in fitnesses])
    tournament_size = 3
    indices = np.random.choice(pop_size, tournament_size, replace=False)
    best_idx = indices[np.argmin(fitness[indices])]
    return int(best_idx)