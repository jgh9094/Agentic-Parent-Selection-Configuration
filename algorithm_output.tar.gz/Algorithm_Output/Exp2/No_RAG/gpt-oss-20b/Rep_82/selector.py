def selection(fitnesses):
    import numpy as np
    num_total_cases = len(fitnesses[0])
    pop_size = len(fitnesses)
    errors = np.array([sum(ind) for ind in fitnesses])
    a = np.random.randint(pop_size)
    b = np.random.randint(pop_size)
    return a if errors[a] < errors[b] else b