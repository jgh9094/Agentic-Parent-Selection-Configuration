def selection(fitnesses):
    import numpy as np
    num_total_cases = len(fitnesses[0])
    pop_size = len(fitnesses)
    mean_errors = np.mean(fitnesses, axis=1)
    idx1, idx2 = np.random.randint(0, pop_size, size=2)
    if mean_errors[idx1] < mean_errors[idx2]:
        return idx1
    else:
        return idx2