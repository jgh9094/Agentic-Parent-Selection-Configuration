def selection(fitnesses):
    import numpy as np
    num_total_cases = len(fitnesses[0])
    pop_size = len(fitnesses)
    errors = [sum(f) for f in fitnesses]
    if pop_size <= 1:
        return 0
    k = 3 if pop_size >= 3 else pop_size
    indices = np.random.choice(pop_size, k, replace=False)
    best_idx = indices[0]
    best_err = errors[best_idx]
    for idx in indices[1:]:
        if errors[idx] < best_err:
            best_err = errors[idx]
            best_idx = idx
    return best_idx