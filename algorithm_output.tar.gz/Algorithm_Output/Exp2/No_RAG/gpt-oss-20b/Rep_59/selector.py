def selection(fitnesses):
    import numpy as np
    num_total_cases = len(fitnesses[0])
    pop_size = len(fitnesses)
    errors = np.array([sum(ind) for ind in fitnesses])
    k = 3
    indices = np.random.choice(pop_size, k, replace=False)
    best_idx = indices[np.argmin(errors[indices])]
    return int(best_idx)