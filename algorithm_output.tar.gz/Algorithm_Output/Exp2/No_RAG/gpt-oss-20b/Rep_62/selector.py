def selection(fitnesses):
    import numpy as np
    num_total_cases = len(fitnesses[0])
    pop_size = len(fitnesses)
    # compute fitness as sum of errors (lower is better)
    fitness = np.array([sum(ind) for ind in fitnesses])
    tournament_size = 3
    if pop_size < tournament_size:
        tournament_size = pop_size
    # randomly select tournament_size indices
    indices = np.random.randint(0, pop_size, size=tournament_size)
    # find index with minimum fitness
    best_idx = indices[np.argmin(fitness[indices])]
    return best_idx