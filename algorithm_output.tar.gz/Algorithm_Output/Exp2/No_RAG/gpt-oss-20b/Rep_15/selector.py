def selection(fitnesses):
    import numpy as np
    num_total_cases = len(fitnesses[0])
    pop_size = len(fitnesses)
    total_errors = np.array([sum(errors) for errors in fitnesses])
    k = 3
    best_idx = None
    best_error = np.inf
    for _ in range(k):
        idx = np.random.randint(pop_size)
        if total_errors[idx] < best_error:
            best_error = total_errors[idx]
            best_idx = idx
    return best_idx