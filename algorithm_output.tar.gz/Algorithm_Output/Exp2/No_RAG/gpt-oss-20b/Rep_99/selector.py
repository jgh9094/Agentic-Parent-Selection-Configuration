def selection(fitnesses):
    import numpy as np
    num_total_cases = len(fitnesses[0])
    pop_size = len(fitnesses)
    errors = np.array([sum(ind) for ind in fitnesses])
    tsize = 3
    if pop_size < tsize:
        tsize = pop_size
    candidates = np.random.randint(0, pop_size, size=tsize)
    best = candidates[0]
    best_err = errors[best]
    for idx in candidates[1:]:
        if errors[idx] < best_err:
            best = idx
            best_err = errors[idx]
    return best