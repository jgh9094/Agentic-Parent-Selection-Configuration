def selection(fitnesses):
    import numpy as np
    pop_size = len(fitnesses)
    # Convert errors to fitness (lower error => higher fitness)
    fitness = np.array([-sum(f) for f in fitnesses])
    # Tournament size
    k = 3
    # Randomly pick k candidates
    candidates = np.random.randint(0, pop_size, size=k)
    # Select the candidate with the highest fitness
    best = candidates[np.argmax(fitness[candidates])]
    return int(best)