def selection(fitnesses):
    import numpy as np
    num_total_cases = len(fitnesses[0])
    pop_size = len(fitnesses)
    total_errors = np.array([sum(f) for f in fitnesses])
    k = min(3, pop_size)
    indices = np.random.choice(pop_size, size=k, replace=False)
    best_idx = indices[np.argmin(total_errors[indices])]
    return int(best_idx)