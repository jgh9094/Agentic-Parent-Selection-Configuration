def selection(fitnesses):
    import numpy as np
    num_total_cases = len(fitnesses[0])
    pop_size = len(fitnesses)
    if pop_size == 0:
        return None
    total_errors = np.sum(fitnesses, axis=1)
    if pop_size == 1:
        return 0
    i1 = np.random.randint(pop_size)
    i2 = np.random.randint(pop_size)
    if total_errors[i1] <= total_errors[i2]:
        return i1
    else:
        return i2