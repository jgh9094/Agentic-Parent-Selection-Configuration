def selection(fitnesses):
    import numpy as np
    num_total_cases = len(fitnesses[0])
    pop_size = len(fitnesses)
    errors = np.array([np.mean(f) for f in fitnesses])
    tsize = 3
    inds = np.random.randint(0, pop_size, size=tsize)
    best = inds[0]
    best_err = errors[best]
    for i in inds[1:]:
        if errors[i] < best_err:
            best = i
            best_err = errors[i]
    return best