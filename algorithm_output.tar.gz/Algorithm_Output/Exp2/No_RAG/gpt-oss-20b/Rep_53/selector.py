def selection(fitnesses):
    import numpy as np
    num_total_cases = len(fitnesses[0])
    pop_size = len(fitnesses)
    # compute fitness as sum of errors (lower is better)
    fitness_values = np.array([sum(ind) for ind in fitnesses])
    # tournament selection
    k = 3
    best_idx = None
    best_fit = np.inf
    for _ in range(k):
        idx = np.random.randint(0, pop_size)
        if fitness_values[idx] < best_fit:
            best_fit = fitness_values[idx]
            best_idx = idx
    return best_idx