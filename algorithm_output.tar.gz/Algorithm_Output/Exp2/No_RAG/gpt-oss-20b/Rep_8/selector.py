def selection(fitnesses):
    import numpy as np
    num_total_cases = len(fitnesses[0])
    pop_size = len(fitnesses)
    fitness = -np.sum(np.array(fitnesses), axis=1)
    k = 3
    if pop_size < k:
        k = pop_size
    indices = np.random.choice(pop_size, size=k, replace=False)
    best_idx = indices[np.argmax(fitness[indices])]
    return int(best_idx)