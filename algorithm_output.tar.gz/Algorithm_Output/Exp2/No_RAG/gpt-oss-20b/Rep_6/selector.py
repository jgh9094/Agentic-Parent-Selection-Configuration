def selection(fitnesses):
    import numpy as np
    num_total_cases = len(fitnesses[0])
    pop_size = len(fitnesses)
    errors = np.sum(np.array(fitnesses), axis=1)
    tournament_size = 3
    indices = np.random.choice(pop_size, size=tournament_size, replace=False)
    best_idx = np.argmin(errors[indices])
    return int(indices[best_idx])