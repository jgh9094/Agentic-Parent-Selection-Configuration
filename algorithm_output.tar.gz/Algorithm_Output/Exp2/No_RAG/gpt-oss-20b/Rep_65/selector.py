def selection(fitnesses):
    import numpy as np
    num_total_cases = len(fitnesses[0])
    pop_size = len(fitnesses)
    errors = np.array([sum(f) for f in fitnesses])
    tournament_size = 3
    indices = np.random.randint(0, pop_size, size=tournament_size)
    best = indices[0]
    for idx in indices[1:]:
        if errors[idx] < errors[best]:
            best = idx
    return int(best)