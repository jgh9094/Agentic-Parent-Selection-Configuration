def selection(fitnesses):
    import numpy as np
    pop_size = len(fitnesses)
    # Compute total error for each individual (lower is better)
    errors = np.array([np.sum(individual) for individual in fitnesses])
    # Tournament size
    k = 3
    # Randomly select k distinct individuals
    candidates = np.random.choice(pop_size, size=k, replace=False)
    # Choose the candidate with the lowest error
    best = candidates[np.argmin(errors[candidates])]
    return int(best)