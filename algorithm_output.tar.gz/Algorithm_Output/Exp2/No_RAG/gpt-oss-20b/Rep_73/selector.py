import numpy as np

def selection(fitnesses):
    num_total_cases = len(fitnesses[0])
    pop_size = len(fitnesses)
    total_errors = np.array([sum(f) for f in fitnesses])
    k = 3
    indices = np.random.randint(0, pop_size, size=k)
    best_idx = indices[0]
    best_error = total_errors[best_idx]
    for idx in indices[1:]:
        if total_errors[idx] < best_error:
            best_error = total_errors[idx]
            best_idx = idx
    return int(best_idx)