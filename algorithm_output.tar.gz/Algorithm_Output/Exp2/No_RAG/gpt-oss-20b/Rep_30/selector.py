def selection(fitnesses):
    import numpy as np
    num_total_cases = len(fitnesses[0])
    pop_size = len(fitnesses)
    fitness = np.array([np.mean(errors) for errors in fitnesses])
    idx1 = np.random.randint(0, pop_size)
    idx2 = np.random.randint(0, pop_size)
    if fitness[idx1] < fitness[idx2]:
        return idx1
    else:
        return idx2