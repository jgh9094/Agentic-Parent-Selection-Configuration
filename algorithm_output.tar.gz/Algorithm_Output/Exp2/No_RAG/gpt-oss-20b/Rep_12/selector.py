def selection(fitnesses):
    import numpy as np
    num_total_cases = len(fitnesses[0])
    pop_size = len(fitnesses)
    total_errors = np.sum(fitnesses, axis=1)
    tournament_size = 3
    if pop_size < tournament_size:
        tournament_size = pop_size
    indices = np.random.randint(0, pop_size, size=tournament_size)
    best_idx = indices[np.argmin(total_errors[indices])]
    return int(best_idx)