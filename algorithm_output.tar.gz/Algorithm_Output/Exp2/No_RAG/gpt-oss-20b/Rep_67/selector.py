def selection(fitnesses):
    import numpy as np
    num_total_cases = len(fitnesses[0])
    pop_size = len(fitnesses)
    fitness = np.array([-sum(f) for f in fitnesses])
    k = 3
    if pop_size < k:
        k = pop_size
    candidates = np.random.randint(0, pop_size, size=k)
    best_idx = candidates[np.argmax(fitness[candidates])]
    return int(best_idx)