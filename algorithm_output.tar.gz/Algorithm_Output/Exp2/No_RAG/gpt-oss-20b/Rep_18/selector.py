def selection(fitnesses):
    import numpy as np
    num_total_cases = len(fitnesses[0])
    pop_size = len(fitnesses)
    # Compute overall fitness as sum of errors (lower is better)
    fitness = np.sum(np.array(fitnesses), axis=1)
    tournament_size = 3
    # Randomly pick tournament_size individuals
    selected_indices = np.random.randint(0, pop_size, size=tournament_size)
    selected_fitnesses = fitness[selected_indices]
    # Choose the index with minimal fitness among the selected
    best_local = np.argmin(selected_fitnesses)
    return int(selected_indices[best_local])