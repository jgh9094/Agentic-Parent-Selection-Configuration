def selection(fitnesses):
    import numpy as np
    num_total_cases = len(fitnesses[0])
    pop_size = len(fitnesses)
    errors = np.array(fitnesses)
    sums = np.sum(errors, axis=1)
    tournament_size = 3
    indices = np.random.randint(0, pop_size, size=tournament_size)
    best_idx = indices[0]
    best_sum = sums[best_idx]
    for idx in indices[1:]:
        if sums[idx] < best_sum:
            best_sum = sums[idx]
            best_idx = idx
    return best_idx