import numpy as np

def selection(fitnesses):
    num_total_cases = len(fitnesses[0])
    pop_size = len(fitnesses)
    # Compute mean error per individual
    mean_errors = np.array([np.mean(errors) for errors in fitnesses])
    # Convert to fitness (higher is better)
    fitness = 1.0 / (1.0 + mean_errors)
    # Tournament size
    k = 3
    # Randomly select k distinct indices
    indices = np.random.choice(pop_size, size=k, replace=False)
    # Choose the index with highest fitness
    best_idx = indices[np.argmax(fitness[indices])]
    return int(best_idx)