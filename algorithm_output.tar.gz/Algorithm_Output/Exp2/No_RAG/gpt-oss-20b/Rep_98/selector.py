def selection(fitnesses):
    import numpy as np
    num_total_cases = len(fitnesses[0])
    pop_size = len(fitnesses)
    total_errors = np.sum(fitnesses, axis=1)
    k = 3
    if pop_size < k:
        k = pop_size
    indices = np.random.randint(0, pop_size, size=k)
    best = indices[0]
    for idx in indices[1:]:
        if total_errors[idx] < total_errors[best]:
            best = idx
    return int(best)