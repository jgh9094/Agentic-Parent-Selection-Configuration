def selection(fitnesses):
    import numpy as np
    num_total_cases = len(fitnesses[0])
    pop_size = len(fitnesses)
    errors = np.sum(fitnesses, axis=1)
    k = 3
    if pop_size < k:
        k = pop_size
    candidates = np.random.choice(pop_size, size=k, replace=False)
    best_idx = candidates[np.argmin(errors[candidates])]
    return int(best_idx)