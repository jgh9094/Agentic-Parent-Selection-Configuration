def selection(fitnesses):
    import numpy as np
    num_total_cases = len(fitnesses[0])
    pop_size = len(fitnesses)
    errors = np.array([sum(ind) for ind in fitnesses])
    tournament_size = 3
    participants = np.random.choice(pop_size, size=tournament_size, replace=False)
    best = participants[0]
    best_error = errors[best]
    for idx in participants[1:]:
        if errors[idx] < best_error:
            best = idx
            best_error = errors[idx]
    return best