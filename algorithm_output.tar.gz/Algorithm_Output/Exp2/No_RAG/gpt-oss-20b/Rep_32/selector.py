def selection(fitnesses):
    import numpy as np
    num_total_cases = len(fitnesses[0])
    pop_size = len(fitnesses)
    errors = np.array([sum(ind) for ind in fitnesses])
    tsize = 3
    idxs = np.random.randint(0, pop_size, size=tsize)
    best_idx = idxs[np.argmin(errors[idxs])]
    return int(best_idx)