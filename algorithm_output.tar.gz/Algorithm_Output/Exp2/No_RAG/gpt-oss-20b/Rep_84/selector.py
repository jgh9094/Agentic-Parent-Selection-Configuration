def selection(fitnesses):
    import numpy as np
    num_total_cases = len(fitnesses[0])
    pop_size = len(fitnesses)
    fitness = np.array([ -sum(ind) for ind in fitnesses ])
    tsize = 3
    candidates = np.random.choice(pop_size, tsize, replace=False)
    best = candidates[np.argmax(fitness[candidates])]
    return int(best)