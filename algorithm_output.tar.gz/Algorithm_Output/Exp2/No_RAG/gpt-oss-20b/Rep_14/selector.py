import numpy as np

def selection(fitnesses):
    num_total_cases = len(fitnesses[0])
    pop_size = len(fitnesses)
    errors = np.array([sum(ind) for ind in fitnesses])
    fitness = 1.0 / (1.0 + errors)
    tournament_size = 3
    indices = np.random.randint(0, pop_size, size=tournament_size)
    best_idx = indices[0]
    best_fit = fitness[best_idx]
    for idx in indices[1:]:
        if fitness[idx] > best_fit:
            best_fit = fitness[idx]
            best_idx = idx
    return int(best_idx)