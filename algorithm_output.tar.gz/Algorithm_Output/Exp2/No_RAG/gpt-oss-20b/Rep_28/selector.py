def selection(fitnesses):
    import numpy as np
    num_total_cases = len(fitnesses[0])
    pop_size = len(fitnesses)
    tournament_size = 3
    indices = np.random.choice(pop_size, size=tournament_size, replace=False)
    best_idx = indices[0]
    best_error = sum(fitnesses[best_idx])
    for idx in indices[1:]:
        err = sum(fitnesses[idx])
        if err < best_error:
            best_error = err
            best_idx = idx
    return int(best_idx)