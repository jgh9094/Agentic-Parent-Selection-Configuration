import numpy as np

def selection(fitnesses):
    num_total_cases = len(fitnesses[0])
    pop_size = len(fitnesses)
    fitness_sums = np.sum(fitnesses, axis=1)
    tournament_size = min(3, pop_size)
    indices = np.random.choice(pop_size, size=tournament_size, replace=(tournament_size>pop_size))
    best_idx = indices[np.argmin(fitness_sums[indices])]
    return int(best_idx)