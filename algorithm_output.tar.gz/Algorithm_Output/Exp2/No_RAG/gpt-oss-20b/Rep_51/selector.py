def selection(fitnesses):
    import numpy as np
    num_total_cases = len(fitnesses[0])
    pop_size = len(fitnesses)
    errors = np.array([sum(f) for f in fitnesses])
    k = 3
    if pop_size < k:
        k = pop_size
    indices = np.random.randint(0, pop_size, size=k)
    best_idx = indices[np.argmin(errors[indices])]
    return int(best_idx)