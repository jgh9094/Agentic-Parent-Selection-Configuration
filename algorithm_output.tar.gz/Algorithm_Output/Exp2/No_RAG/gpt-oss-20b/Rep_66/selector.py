def selection(fitnesses):
    import numpy as np
    num_total_cases = len(fitnesses[0])
    pop_size = len(fitnesses)
    errors = np.array([sum(f) for f in fitnesses])
    tsize = 3
    idxs = np.random.randint(0, pop_size, size=tsize)
    best = idxs[0]
    best_err = errors[best]
    for i in idxs[1:]:
        if errors[i] < best_err:
            best = i
            best_err = errors[i]
    return int(best)