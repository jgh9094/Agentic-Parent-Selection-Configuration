def selection(fitnesses):
    import numpy as np
    num_total_cases = len(fitnesses[0])
    pop_size = len(fitnesses)
    epsilon = 1e-6  # Small threshold for epsilon lexicase

    # Randomize the order of test cases
    test_case_indices = np.random.permutation(num_total_cases)

    # Filter population based on lexicase criteria
    candidates = list(range(pop_size))
    for case_idx in test_case_indices:
        min_error = min(fitnesses[i][case_idx] for i in candidates)
        candidates = [i for i in candidates if fitnesses[i][case_idx] <= min_error + epsilon]
        if len(candidates) == 1:
            break

    # If multiple candidates remain, pick one randomly
    return np.random.choice(candidates)