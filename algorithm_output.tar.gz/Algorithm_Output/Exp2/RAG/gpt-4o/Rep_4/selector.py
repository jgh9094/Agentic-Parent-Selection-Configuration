def selection(fitnesses):
    import numpy as np
    num_total_cases = len(fitnesses[0])
    pop_size = len(fitnesses)
    epsilon = 1e-6
    candidates = list(range(pop_size))
    for case_idx in np.random.permutation(num_total_cases):
        min_error = min(fitnesses[i][case_idx] for i in candidates)
        threshold = min_error + epsilon
        candidates = [i for i in candidates if fitnesses[i][case_idx] <= threshold]
        if len(candidates) == 1:
            break
    return np.random.choice(candidates)