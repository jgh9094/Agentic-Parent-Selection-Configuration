def selection(fitnesses):
    import numpy as np
    num_total_cases = len(fitnesses[0])
    pop_size = len(fitnesses)

    candidates = np.arange(pop_size)
    test_case_order = np.random.permutation(num_total_cases)

    for test_case in test_case_order:
        errors = np.array([fitnesses[i][test_case] for i in candidates])
        min_error = np.min(errors)
        candidates = candidates[errors == min_error]

        if len(candidates) == 1:
            return candidates[0]

    return np.random.choice(candidates)