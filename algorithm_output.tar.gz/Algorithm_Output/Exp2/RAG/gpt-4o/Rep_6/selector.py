def selection(fitnesses):
    import numpy as np
    num_total_cases = len(fitnesses[0])
    pop_size = len(fitnesses)
    indices = np.arange(pop_size)
    np.random.shuffle(indices)
    for case in range(num_total_cases):
        min_error = np.min([fitnesses[i][case] for i in indices])
        indices = [i for i in indices if fitnesses[i][case] == min_error]
        if len(indices) == 1:
            break
    return indices[0]