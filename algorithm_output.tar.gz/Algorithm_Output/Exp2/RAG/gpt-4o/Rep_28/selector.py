def selection(fitnesses):
    import numpy as np
    num_total_cases = len(fitnesses[0])
    pop_size = len(fitnesses)
    indices = np.arange(pop_size)
    np.random.shuffle(indices)
    for case in range(num_total_cases):
        min_error = min(fitnesses[i][case] for i in indices)
        epsilon = np.random.uniform(0, 0.1)  # Small threshold for ε
        indices = [i for i in indices if fitnesses[i][case] <= min_error + epsilon]
        if len(indices) == 1:
            return indices[0]
    return np.random.choice(indices)