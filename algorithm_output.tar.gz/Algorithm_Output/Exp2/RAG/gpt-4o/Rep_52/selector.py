def selection(fitnesses):
    import numpy as np
    num_total_cases = len(fitnesses[0])
    pop_size = len(fitnesses)
    epsilon = np.std(fitnesses, axis=0) * 0.1
    candidates = list(range(pop_size))

    for case_idx in range(num_total_cases):
        min_error = min(fitnesses[i][case_idx] for i in candidates)
        threshold = min_error + epsilon[case_idx]
        candidates = [i for i in candidates if fitnesses[i][case_idx] <= threshold]
        if len(candidates) == 1:
            break

    return np.random.choice(candidates)