def selection(fitnesses):
    import numpy as np

    num_total_cases = len(fitnesses[0])
    pop_size = len(fitnesses)

    epsilon = 1e-6  # Small threshold to define acceptable error margin
    remaining_indices = list(range(pop_size))

    for case_idx in np.random.permutation(num_total_cases):
        min_error = min(fitnesses[i][case_idx] for i in remaining_indices)
        remaining_indices = [i for i in remaining_indices if fitnesses[i][case_idx] <= min_error + epsilon]

        if len(remaining_indices) == 1:
            break

    return np.random.choice(remaining_indices)