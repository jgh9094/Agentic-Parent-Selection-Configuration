def selection(fitnesses):
    import numpy as np
    num_total_cases = len(fitnesses[0])
    pop_size = len(fitnesses)

    # Randomize the order of test cases
    test_case_order = np.random.permutation(num_total_cases)

    # Iterate through individuals to find a parent
    candidates = list(range(pop_size))
    for test_case in test_case_order:
        # Find the minimum error for the current test case
        min_error = min(fitnesses[i][test_case] for i in candidates)

        # Filter candidates with the minimum error
        candidates = [i for i in candidates if fitnesses[i][test_case] == min_error]

        # If only one candidate remains, return it
        if len(candidates) == 1:
            return candidates[0]

    # If multiple candidates remain, select one randomly
    return np.random.choice(candidates)