def selection(fitnesses):
    import numpy as np
    
    num_total_cases = len(fitnesses[0])
    pop_size = len(fitnesses)
    
    epsilon = [np.std([fitnesses[i][j] for i in range(pop_size)]) * 0.1 for j in range(num_total_cases)]
    
    candidates = list(range(pop_size))
    for case_index in range(num_total_cases):
        if len(candidates) == 1:
            break
        
        min_error = min(fitnesses[i][case_index] for i in candidates)
        threshold = min_error + epsilon[case_index]
        candidates = [i for i in candidates if fitnesses[i][case_index] <= threshold]
    
    return np.random.choice(candidates)