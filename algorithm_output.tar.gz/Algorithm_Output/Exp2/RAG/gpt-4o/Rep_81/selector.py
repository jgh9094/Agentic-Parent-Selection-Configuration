def selection(fitnesses):
    import numpy as np

    num_total_cases = len(fitnesses[0])
    pop_size = len(fitnesses)

    remaining = list(range(pop_size))
    for case_index in np.random.permutation(num_total_cases):
        min_error = min(fitnesses[i][case_index] for i in remaining)
        remaining = [i for i in remaining if fitnesses[i][case_index] == min_error]
        if len(remaining) == 1:
            return remaining[0]

    return np.random.choice(remaining)