def selection(fitnesses):
    import numpy as np
    num_total_cases = len(fitnesses[0])
    pop_size = len(fitnesses)

    # Randomize the order of test cases
    test_case_order = np.random.permutation(num_total_cases)

    # Iterate through individuals in randomized order
    for case in test_case_order:
        min_error = min(fitness[case] for fitness in fitnesses)
        threshold = min_error + np.random.uniform(0, 0.1)  # ε value

        # Filter individuals meeting the threshold
        candidates = [i for i in range(pop_size) if fitnesses[i][case] <= threshold]

        if len(candidates) == 1:
            return candidates[0]
        elif len(candidates) > 1:
            fitnesses = [fitnesses[i] for i in candidates]
            pop_size = len(fitnesses)

    # If no unique candidate, return a random individual
    return np.random.randint(pop_size)