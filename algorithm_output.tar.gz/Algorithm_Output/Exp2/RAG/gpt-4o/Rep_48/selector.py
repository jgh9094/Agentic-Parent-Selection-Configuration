def selection(fitnesses):
    import numpy as np
    num_total_cases = len(fitnesses[0])
    pop_size = len(fitnesses)
    indices = np.arange(pop_size)
    np.random.shuffle(indices)
    for case in range(num_total_cases):
        errors = [fitnesses[i][case] for i in indices]
        min_error = min(errors)
        indices = [i for i in indices if fitnesses[i][case] == min_error]
        if len(indices) == 1:
            return indices[0]
    return indices[0]