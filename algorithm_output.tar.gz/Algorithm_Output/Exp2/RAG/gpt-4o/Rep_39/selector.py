def selection(fitnesses):
    import numpy as np
    num_total_cases = len(fitnesses[0])
    pop_size = len(fitnesses)

    def passes_threshold(individual_errors, thresholds):
        return all(err <= thr for err, thr in zip(individual_errors, thresholds))

    thresholds = [np.percentile([fitnesses[i][j] for i in range(pop_size)], 10) for j in range(num_total_cases)]
    candidates = [i for i in range(pop_size) if passes_threshold(fitnesses[i], thresholds)]

    if candidates:
        return np.random.choice(candidates)
    else:
        return np.random.randint(0, pop_size)