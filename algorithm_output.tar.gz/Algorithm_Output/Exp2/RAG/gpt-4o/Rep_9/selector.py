def selection(fitnesses):
    import numpy as np
    num_total_cases = len(fitnesses[0])
    pop_size = len(fitnesses)
    candidates = list(range(pop_size))
    np.random.shuffle(candidates)

    for case_idx in range(num_total_cases):
        min_error = min(fitnesses[candidate][case_idx] for candidate in candidates)
        epsilon = 0.01 * min_error
        candidates = [candidate for candidate in candidates if fitnesses[candidate][case_idx] <= min_error + epsilon]
        if len(candidates) == 1:
            return candidates[0]

    return np.random.choice(candidates)