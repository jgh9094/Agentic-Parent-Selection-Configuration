def selection(fitnesses):
    import numpy as np
    num_total_cases = len(fitnesses[0])
    pop_size = len(fitnesses)
    epsilon = 1e-6  # Small threshold for epsilon lexicase

    # Randomize the order of test cases
    test_case_order = np.random.permutation(num_total_cases)

    # Filter individuals iteratively based on test case errors
    remaining_indices = np.arange(pop_size)
    for test_case in test_case_order:
        if len(remaining_indices) == 1:
            break

        # Get errors for the current test case
        errors = np.array([fitnesses[i][test_case] for i in remaining_indices])
        min_error = np.min(errors)

        # Apply epsilon threshold to filter individuals
        remaining_indices = remaining_indices[errors <= min_error + epsilon]

    # If multiple individuals remain, select one randomly
    if len(remaining_indices) > 1:
        return np.random.choice(remaining_indices)

    return remaining_indices[0]