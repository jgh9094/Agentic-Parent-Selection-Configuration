def selection(fitnesses):
    import numpy as np
    num_total_cases = len(fitnesses[0])
    pop_size = len(fitnesses)
    indices = np.arange(pop_size)
    np.random.shuffle(indices)
    for case_idx in range(num_total_cases):
        errors = np.array([fitnesses[i][case_idx] for i in indices])
        min_error = np.min(errors)
        indices = indices[errors == min_error]
        if len(indices) == 1:
            return indices[0]
    return indices[0]