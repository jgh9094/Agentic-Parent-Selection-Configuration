def selection(fitnesses):
    import numpy as np
    num_total_cases = len(fitnesses[0])
    pop_size = len(fitnesses)

    # Shuffle the test cases randomly
    test_case_order = np.random.permutation(num_total_cases)

    # Iterate through individuals to find a parent
    remaining_indices = list(range(pop_size))
    for test_case in test_case_order:
        # Get errors for the current test case
        errors = [fitnesses[i][test_case] for i in remaining_indices]
        min_error = min(errors)

        # Filter individuals with the minimum error for this test case
        remaining_indices = [remaining_indices[i] for i in range(len(errors)) if errors[i] == min_error]

        # If only one individual remains, select it
        if len(remaining_indices) == 1:
            return remaining_indices[0]

    # If multiple individuals remain, select one randomly
    return np.random.choice(remaining_indices)