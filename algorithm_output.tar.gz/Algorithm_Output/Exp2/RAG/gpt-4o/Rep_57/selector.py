def selection(fitnesses):
    import numpy as np
    num_total_cases = len(fitnesses[0])
    pop_size = len(fitnesses)
    epsilon = 1e-6  # Small threshold for epsilon lexicase selection

    candidates = list(range(pop_size))
    for case_index in np.random.permutation(num_total_cases):
        min_error = min(fitnesses[candidate][case_index] for candidate in candidates)
        candidates = [candidate for candidate in candidates if fitnesses[candidate][case_index] <= min_error + epsilon]
        if len(candidates) == 1:
            break

    return np.random.choice(candidates)