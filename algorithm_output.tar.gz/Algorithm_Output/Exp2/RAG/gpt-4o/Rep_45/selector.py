def selection(fitnesses):
    import numpy as np
    num_total_cases = len(fitnesses[0])
    pop_size = len(fitnesses)
    tournament_size = 3
    selected_indices = np.random.choice(pop_size, tournament_size, replace=False)
    tournament_fitnesses = [np.mean(fitnesses[i]) for i in selected_indices]
    best_index = selected_indices[np.argmin(tournament_fitnesses)]
    return best_index