def selection(fitnesses):
    import numpy as np
    num_total_cases = len(fitnesses[0])
    pop_size = len(fitnesses)
    epsilon = [np.percentile([fitnesses[i][j] for i in range(pop_size)], 10) for j in range(num_total_cases)]
    candidates = list(range(pop_size))
    for case_index in np.random.permutation(num_total_cases):
        min_error = min([fitnesses[i][case_index] for i in candidates])
        candidates = [i for i in candidates if fitnesses[i][case_index] <= min_error + epsilon[case_index]]
        if len(candidates) == 1:
            break
    return np.random.choice(candidates)