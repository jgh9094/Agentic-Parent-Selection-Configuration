def selection(fitnesses):
    import numpy as np
    num_total_cases = len(fitnesses[0])
    pop_size = len(fitnesses)
    candidates = list(range(pop_size))
    np.random.shuffle(candidates)

    for case in range(num_total_cases):
        min_error = min(fitnesses[i][case] for i in candidates)
        candidates = [i for i in candidates if fitnesses[i][case] == min_error]
        if len(candidates) == 1:
            return candidates[0]

    return np.random.choice(candidates)