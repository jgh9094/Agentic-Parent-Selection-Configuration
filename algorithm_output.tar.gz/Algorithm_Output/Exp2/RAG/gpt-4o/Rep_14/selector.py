def selection(fitnesses):
    import numpy as np
    num_total_cases = len(fitnesses[0])
    pop_size = len(fitnesses)
    remaining_indices = list(range(pop_size))
    test_case_order = np.random.permutation(num_total_cases)

    for test_case in test_case_order:
        min_error = min(fitnesses[i][test_case] for i in remaining_indices)
        remaining_indices = [i for i in remaining_indices if fitnesses[i][test_case] == min_error]
        if len(remaining_indices) == 1:
            break

    return remaining_indices[0] if remaining_indices else np.random.randint(pop_size)