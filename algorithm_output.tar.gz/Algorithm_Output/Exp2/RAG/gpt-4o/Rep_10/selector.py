def selection(fitnesses):
    import numpy as np
    num_total_cases = len(fitnesses[0])
    pop_size = len(fitnesses)
    candidates = list(range(pop_size))
    np.random.shuffle(candidates)
    for case_index in range(num_total_cases):
        min_error = min(fitnesses[candidate][case_index] for candidate in candidates)
        candidates = [candidate for candidate in candidates if fitnesses[candidate][case_index] == min_error]
        if len(candidates) == 1:
            break
    return candidates[0]