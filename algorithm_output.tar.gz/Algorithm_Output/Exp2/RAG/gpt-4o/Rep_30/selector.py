def selection(fitnesses):
    import numpy as np
    num_total_cases = len(fitnesses[0])
    pop_size = len(fitnesses)
    indices = np.arange(pop_size)
    for case in np.random.permutation(num_total_cases):
        errors = np.array([fitnesses[i][case] for i in indices])
        min_error = np.min(errors)
        indices = indices[errors == min_error]
        if len(indices) == 1:
            return indices[0]
    return np.random.choice(indices)