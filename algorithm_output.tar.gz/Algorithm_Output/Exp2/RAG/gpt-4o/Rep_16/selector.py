def selection(fitnesses):
    import numpy as np
    num_total_cases = len(fitnesses[0])
    pop_size = len(fitnesses)
    tournament_size = 5  # Example tournament size
    
    # Randomly select tournament participants
    tournament_indices = np.random.choice(pop_size, tournament_size, replace=False)
    
    # Calculate total errors for each participant
    total_errors = [sum(fitnesses[i]) for i in tournament_indices]
    
    # Select the index of the individual with the minimum total error
    winner_index = tournament_indices[np.argmin(total_errors)]
    
    return winner_index