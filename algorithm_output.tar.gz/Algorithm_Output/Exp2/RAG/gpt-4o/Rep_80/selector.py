def selection(fitnesses):
    import numpy as np
    num_total_cases = len(fitnesses[0])
    pop_size = len(fitnesses)

    # Shuffle the test cases
    test_case_order = np.random.permutation(num_total_cases)

    # Iterate through individuals in random order
    candidates = list(range(pop_size))
    for case in test_case_order:
        # Find the minimum error for the current test case
        min_error = min(fitnesses[i][case] for i in candidates)

        # Filter candidates with error close to the minimum (ε threshold)
        epsilon = 1e-6  # Small threshold for numerical stability
        candidates = [i for i in candidates if fitnesses[i][case] <= min_error + epsilon]

        # If only one candidate remains, return it
        if len(candidates) == 1:
            return candidates[0]

    # If multiple candidates remain, select one randomly
    return np.random.choice(candidates)