def selection(fitnesses):
    import numpy as np
    num_total_cases = len(fitnesses[0])
    pop_size = len(fitnesses)
    candidates = list(range(pop_size))
    for case_index in np.random.permutation(num_total_cases):
        case_errors = np.array([fitnesses[i][case_index] for i in candidates])
        min_error = np.min(case_errors)
        candidates = [candidates[i] for i in range(len(candidates)) if case_errors[i] == min_error]
        if len(candidates) == 1:
            break
    return candidates[0]