def selection(fitnesses):
    import numpy as np
    num_total_cases = len(fitnesses[0])
    pop_size = len(fitnesses)

    candidates = list(range(pop_size))
    test_case_order = np.random.permutation(num_total_cases)

    for test_case in test_case_order:
        min_error = min(fitnesses[ind][test_case] for ind in candidates)
        candidates = [ind for ind in candidates if fitnesses[ind][test_case] == min_error]
        if len(candidates) == 1:
            break

    return np.random.choice(candidates)