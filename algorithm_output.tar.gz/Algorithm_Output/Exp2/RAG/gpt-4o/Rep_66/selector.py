def selection(fitnesses):
    import numpy as np

    num_total_cases = len(fitnesses[0])
    pop_size = len(fitnesses)

    candidates = list(range(pop_size))
    test_case_order = np.random.permutation(num_total_cases)

    for test_case in test_case_order:
        min_error = min(fitnesses[i][test_case] for i in candidates)
        candidates = [i for i in candidates if fitnesses[i][test_case] == min_error]
        if len(candidates) == 1:
            break

    return np.random.choice(candidates)