def selection(fitnesses):
    import numpy as np
    num_total_cases = len(fitnesses[0])
    pop_size = len(fitnesses)
    epsilon = 1e-6  # Small threshold for ε-lexicase selection

    # Shuffle test case indices
    test_case_indices = np.random.permutation(num_total_cases)

    # Initialize candidate pool with all individuals
    candidates = list(range(pop_size))

    for case_idx in test_case_indices:
        # Find the minimum error for the current test case among candidates
        min_error = min(fitnesses[c][case_idx] for c in candidates)

        # Filter candidates within ε of the minimum error
        candidates = [c for c in candidates if fitnesses[c][case_idx] <= min_error + epsilon]

        # If only one candidate remains, return it
        if len(candidates) == 1:
            return candidates[0]

    # If multiple candidates remain, select one randomly
    return np.random.choice(candidates)