def selection(fitnesses):
    import numpy as np
    num_total_cases = len(fitnesses[0])
    pop_size = len(fitnesses)
    candidates = list(range(pop_size))
    np.random.shuffle(candidates)
    for case_idx in np.random.permutation(num_total_cases):
        min_error = min(fitnesses[c][case_idx] for c in candidates)
        candidates = [c for c in candidates if fitnesses[c][case_idx] == min_error]
        if len(candidates) == 1:
            break
    return candidates[0]