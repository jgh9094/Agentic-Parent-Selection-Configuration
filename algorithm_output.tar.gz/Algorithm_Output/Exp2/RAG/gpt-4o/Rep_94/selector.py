def selection(fitnesses):
    import numpy as np
    num_total_cases = len(fitnesses[0])
    pop_size = len(fitnesses)

    # Calculate epsilon for each test case
    epsilon = np.percentile(fitnesses, 10, axis=0)

    # Shuffle the test cases
    test_case_order = np.random.permutation(num_total_cases)

    # Filter individuals based on epsilon thresholds
    candidates = list(range(pop_size))
    for test_case in test_case_order:
        if len(candidates) == 1:
            break
        min_error = min(fitnesses[i][test_case] for i in candidates)
        threshold = min_error + epsilon[test_case]
        candidates = [i for i in candidates if fitnesses[i][test_case] <= threshold]

    # Return a single selected parent
    return np.random.choice(candidates)