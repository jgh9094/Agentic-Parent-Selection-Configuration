import numpy as np
def selection(fitnesses):
    num_total_cases = len(fitnesses[0])
    pop_size = len(fitnesses)
    total_errors = np.array([sum(f) for f in fitnesses])
    idx1, idx2 = np.random.choice(pop_size, 2, replace=False)
    return idx1 if total_errors[idx1] < total_errors[idx2] else idx2