def selection(fitnesses):
    import numpy as np
    num_total_cases = len(fitnesses[0])
    pop_size = len(fitnesses)
    errors = np.array(fitnesses)
    case_order = np.random.permutation(num_total_cases)
    candidates = np.arange(pop_size)
    for case in case_order:
        case_errors = errors[candidates, case]
        best = np.min(case_errors)
        eps = 0.01 * (np.max(case_errors) - best)
        mask = case_errors <= best + eps
        candidates = candidates[mask]
        if len(candidates) == 1:
            return int(candidates[0])
        if len(candidates) == 0:
            return int(np.random.choice(pop_size))
    return int(np.random.choice(candidates))